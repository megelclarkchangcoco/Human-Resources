package EmployeeFrame;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import javax.swing.border.LineBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JList;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import com.toedter.calendar.JCalendar;
import com.toedter.calendar.JDateChooser;
import javax.swing.UIManager;
import javax.swing.JTextPane;


public class attendancePanel extends JPanel {

    private static final long serialVersionUID = 1L;
    private static boolean isVisible =false; 
    private JPanel attendancepanel;
    private JTable table;
    private Connection connection;
    private JTextField textField; 
    private JTextField txtLastName;
    private JTextField txtFirstname;
    private JDateChooser dateChooser;
    private JDateChooser dateChooser_1;
    private JTextPane textpane;
    private RoundedJPanel submitbtnpanel;
    private JPanel leaverequestdetailspanel;
    
    private Date date;
    private long milliseconds; // Convert Date to milliseconds 
    private long seconds = milliseconds /1000;// Convert milliseconds to seconds
    private int dateInt = (int) seconds; // Convert seconds to an integerm
    private JTable tabledisplay;
    public attendancePanel() {

    
        setBorder(new MatteBorder(0, 0, 2, 2, new Color(41, 75, 141)));
        setBackground(Color.WHITE); 
        setLayout(null);
        setBounds(74, 51, 1191, 752);
        setVisible(false);
 
        // Establish database connection
        String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
        try {
            connection = DriverManager.getConnection(url);
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle connection error
        } 

        // Create the body panel to hold the scroll pane
        JPanel bodyPanel = new JPanel();
        bodyPanel.setBorder(new LineBorder(new Color(41, 75, 141), 2));
        bodyPanel.setBounds(0, 0, 1191, 752); // Adjusted the size to fit within the bounds of TablePanel
        add(bodyPanel);
        bodyPanel.setLayout(null);
        
        // Create the scroll pane and set its bounds
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(0, 0, 1191, 752); // Adjusted the size to fit within the bounds of bodyPanel
        bodyPanel.add(scrollPane);
        
        // Create the panel to hold the content to be scrolled
        JPanel scrollContent = new JPanel();
        scrollContent.setBackground(Color.WHITE);
        scrollContent.setLayout(null);
        scrollContent.setPreferredSize(new Dimension(1000, 800)); // Set a preferred size for scrolling
        scrollPane.setViewportView(scrollContent);
        
        attendancepanel = new JPanel();
        attendancepanel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(192, 192, 192)));
        attendancepanel.setOpaque(false);
        attendancepanel.setBounds(47, 42, 1099, 60);
        scrollContent.add(attendancepanel);
        attendancepanel.setLayout(null);
        
        JPanel headpanel = new JPanel();
        headpanel.addMouseListener(new PanelButtonMouseAdapter2(headpanel) {	
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		if(attendancepanel.getHeight()== 60){
        			attendancepanel.setSize(new Dimension(1099, 219));
        		}else {
        			attendancepanel.setSize(new Dimension(1099, 60));
        		}
        		
        		
        	}
        });
        headpanel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(192, 192, 192)));
        headpanel.setBounds(0, 0, 1099, 59);
        attendancepanel.add(headpanel);
        headpanel.setLayout(null);
        
        JLabel lblNewLabel = new JLabel("Daily Attendance");
        lblNewLabel.setForeground(new Color(41, 75, 141));
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 21));
        lblNewLabel.setBounds(455, 11, 207, 37);
        headpanel.add(lblNewLabel);
        
        table = new JTable();
        table.setShowVerticalLines(false);
        table.setBorder(new LineBorder(new Color(192, 192, 192)));
        table.setBounds(46, 81, 1010, 62);
        attendancepanel.add(table);
        table.setRowHeight(30);
        table.setOpaque(false);
        table.setModel(new DefaultTableModel(
        	    new Object[][]{{"Date ", "Time in", "Break in", "Break out", "Check out","Total Work Hour", "Overtime", "Undertime", "Absent", "Firstname", "Lastname"}},
        	    new String[]{
        	        "Date", "Time In", "Break In", "Break Out", "Check Out", "Check Out Time", "Overtime", "Undertime","Absent", "Firstname", "Lastname"
        	    }
        	));
        table.setFont(new Font("Inter Medium", Font.BOLD, 12));
        
        JPanel tablepanel_1 = new JPanel();
        tablepanel_1.setBounds(46, 70, 1010, 86);
        attendancepanel.add(tablepanel_1);
        tablepanel_1.setOpaque(false);
        
        JPanel timeinbtnpanel = new JPanel();
        timeinbtnpanel.addMouseListener(new PanelButtonMouseAdapter(timeinbtnpanel) {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		addTimeInRow();
        	}
        });
        timeinbtnpanel.setBounds(247, 167, 122, 39);
        attendancepanel.add(timeinbtnpanel);
        timeinbtnpanel.setLayout(null);
        timeinbtnpanel.setBorder(new LineBorder(new Color(41, 75, 141)));
        timeinbtnpanel.setBackground(Color.WHITE);
        
        JLabel timeinlbl = new JLabel("Time in");
        timeinlbl.setFont(new Font("Inter Medium", Font.BOLD, 14));
        timeinlbl.setBounds(35, 11, 81, 14);
        timeinbtnpanel.add(timeinlbl);
        
        JPanel breakinbtnpanel = new JPanel();
        breakinbtnpanel.addMouseListener(new PanelButtonMouseAdapter(breakinbtnpanel) {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		addBreakInTime();
        	}
        });
        breakinbtnpanel.setBounds(403, 167, 122, 39);
        attendancepanel.add(breakinbtnpanel);
        breakinbtnpanel.setLayout(null);
        breakinbtnpanel.setBorder(new LineBorder(new Color(41, 75, 141)));
        breakinbtnpanel.setBackground(Color.WHITE);
        
        JLabel lblBreakIn = new JLabel("Break in");
        lblBreakIn.setFont(new Font("Inter Medium", Font.BOLD, 14));
        lblBreakIn.setBounds(34, 11, 78, 14);
        breakinbtnpanel.add(lblBreakIn);
        
        JPanel breakoutbtnpanel = new JPanel();
        breakoutbtnpanel.addMouseListener(new PanelButtonMouseAdapter(breakoutbtnpanel) {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		addBreakOutTime();
        	}
        });
        breakoutbtnpanel.setBounds(559, 167, 122, 39);
        attendancepanel.add(breakoutbtnpanel);
        breakoutbtnpanel.setLayout(null);
        breakoutbtnpanel.setBorder(new LineBorder(new Color(41, 75, 141)));
        breakoutbtnpanel.setBackground(Color.WHITE);
        
        JLabel lblBreakoUt = new JLabel("Break out");
        lblBreakoUt.setFont(new Font("Inter Medium", Font.BOLD, 14));
        lblBreakoUt.setBounds(26, 11, 86, 14);
        breakoutbtnpanel.add(lblBreakoUt);
        
        JPanel checkoutbtnpanel = new JPanel();
        checkoutbtnpanel.addMouseListener(new PanelButtonMouseAdapter(checkoutbtnpanel) {
        	@Override
        	public void mouseClicked(MouseEvent e) {   
        		addCheckOutTime();
        	}
        });
        checkoutbtnpanel.setBounds(708, 167, 122, 39);
        attendancepanel.add(checkoutbtnpanel);
        checkoutbtnpanel.setLayout(null);
        checkoutbtnpanel.setBorder(new LineBorder(new Color(41, 75, 141)));
        checkoutbtnpanel.setBackground(Color.WHITE);
        
        JLabel lblCheckOut = new JLabel("Check out");
        lblCheckOut.setFont(new Font("Inter Medium", Font.BOLD, 14));
        lblCheckOut.setBounds(23, 11, 89, 14);
        checkoutbtnpanel.add(lblCheckOut);
        
        JPanel leaverequestpanel = new JPanel();
        leaverequestpanel.setBorder(new LineBorder(new Color(192, 192, 192)));
        leaverequestpanel.setBackground(new Color(255, 255, 255));
        leaverequestpanel.setBounds(47, 309, 439, 60);
        scrollContent.add(leaverequestpanel);
        leaverequestpanel.setLayout(null);
        
        JPanel headpanel2 = new JPanel();
        headpanel2.addMouseListener(new PanelButtonMouseAdapter2(headpanel2) {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		if(leaverequestpanel.getHeight()== 60){
        			leaverequestpanel.setSize(new Dimension(439, 455));
        		}else {
        			leaverequestpanel.setSize(new Dimension(439, 60));
        		}
        	}
        });
        headpanel2.setLayout(null);
        headpanel2.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(192, 192, 192)));
        headpanel2.setBounds(0, 0, 438, 59);
        leaverequestpanel.add(headpanel2);
        
        JLabel lblLeaveRequest = new JLabel("Leave Request");
        lblLeaveRequest.setForeground(new Color(41, 75, 141));
        lblLeaveRequest.setFont(new Font("Inter Medium", Font.BOLD, 21));
        lblLeaveRequest.setBounds(122, 11, 190, 37);
        headpanel2.add(lblLeaveRequest);
        
        txtLastName = new JTextField();
        txtLastName.setText("Lastname");
        txtLastName.setForeground(new Color(96, 96, 96));
        txtLastName.setFont(new Font("Inter Medium", Font.BOLD, 16));
        txtLastName.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				if (txtLastName.getText().equals("")) {
					txtLastName.setForeground(new Color(96, 96, 96));
					txtLastName.setText("Lastname");
				}
			}

			@Override
			public void focusGained(FocusEvent e) {
				if (txtLastName.getText().equals("Lastname")) {
					txtLastName.setForeground(Color.BLACK);
					txtLastName.setText("");
				}
			}
		});
        txtLastName.setColumns(10);
        txtLastName.setBounds(48, 91, 163, 59);
        leaverequestpanel.add(txtLastName);
        
        txtFirstname = new JTextField();
        txtFirstname.setText("Firstname");
        txtFirstname.setForeground(new Color(96, 96, 96));
        txtFirstname.setFont(new Font("Tahoma", Font.BOLD, 16));
        txtFirstname.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				if (txtFirstname.getText().equals("")) {
					txtFirstname.setForeground(new Color(96, 96, 96));
					txtFirstname.setText("Firstname");
				}
			}

			@Override
			public void focusGained(FocusEvent e) {
				if (txtFirstname.getText().equals("Firstname")) {
					txtFirstname.setForeground(Color.BLACK);
					txtFirstname.setText("");
				}
			}
		});
        txtFirstname.setColumns(10);
        txtFirstname.setBounds(232, 91, 163, 59);
        leaverequestpanel.add(txtFirstname);
        
        dateChooser = new CustomDateChooser();
        dateChooser.setForeground(new Color(0, 0, 0));
        dateChooser.setBounds(48, 174, 347, 43);
        leaverequestpanel.add(dateChooser);
        
        dateChooser_1 = new CustomDateChooser();
        dateChooser_1.setForeground(new Color(0, 0, 0));
        dateChooser_1.setBounds(48, 233, 347, 43);
        leaverequestpanel.add(dateChooser_1);
        
        JPanel textPanel = new JPanel();
        textPanel.setBorder(new LineBorder(new Color(192, 192, 192)));
        textPanel.setBackground(new Color(255, 255, 255));
        textPanel.setBounds(48, 304, 347, 59);
        leaverequestpanel.add(textPanel);
        textPanel.setLayout(null);
        

        
        textpane = new JTextPane();
        textpane.setFont(new Font("Inter Medium", Font.BOLD, 15));
        textpane.setForeground(new Color(96,96,96));
        textpane.setText("Reason");
        textpane.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (textpane.getText().equals("Reason")) {
                    textpane.setText("");
                    textpane.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (textpane.getText().isEmpty()) {
                    textpane.setText("Reason");
                    textpane.setForeground(new Color(96, 96, 96));
                }
            }
        });
        textpane.setBounds(10, 11, 327, 31);
        textPanel.add(textpane);


        
        submitbtnpanel = new RoundedJPanel();
        submitbtnpanel.setBorder(new LineBorder(new Color(41, 75, 141)));
        submitbtnpanel.setOpaque(false);
        submitbtnpanel.addMouseListener(new PanelButtonMouseAdapter(submitbtnpanel) {
        	@Override
        	public void mouseClicked(MouseEvent e) {   
        		submitLeaveRequest();
        	}
       });
        submitbtnpanel.setBounds(127, 386, 163 , 43);
        leaverequestpanel.add(submitbtnpanel);
        submitbtnpanel.setLayout(null);
        
        JLabel submitlbls = new JLabel("Submit");
        submitlbls.setForeground(new Color(41, 75, 141));
        submitlbls.setFont(new Font("Inter Medium", Font.BOLD, 15));
        submitlbls.setBounds(55, 11, 79, 21);
        submitbtnpanel.add(submitlbls);
        
        

        leaverequestdetailspanel = new JPanel();
        leaverequestdetailspanel.setBorder(new LineBorder(new Color(192, 192, 192)));
        leaverequestdetailspanel.setBackground(Color.WHITE);
        leaverequestdetailspanel.setBounds(496, 309, 650, 60);
        scrollContent.add(leaverequestdetailspanel);
        leaverequestdetailspanel.setLayout(null);
        
        JPanel displayheadlpanel = new JPanel();
        displayheadlpanel.setBounds(0, 0, 650, 59);
        // Add MouseListener to headpanel2_1
        displayheadlpanel.addMouseListener(new PanelButtonMouseAdapter(displayheadlpanel) {
            @Override
                	public void mouseClicked(MouseEvent e) {
                		if(leaverequestdetailspanel.getHeight()== 60){
                			leaverequestdetailspanel.setSize(new Dimension(650, 456));
                			 displayLeaveRequestHistory();
                		}else {
                			leaverequestdetailspanel.setSize(new Dimension(650, 60));
                		}
                	}
                });

        displayheadlpanel.setLayout(null);
        displayheadlpanel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(192, 192, 192)));
        leaverequestdetailspanel.add(displayheadlpanel);

        JLabel lblLeaveRequest_1 = new JLabel("Request History");
        lblLeaveRequest_1.setForeground(new Color(41, 75, 141));
        lblLeaveRequest_1.setFont(new Font("Inter Medium", Font.BOLD, 21));
        lblLeaveRequest_1.setBounds(254, 11, 361, 37);
        displayheadlpanel.add(lblLeaveRequest_1);

        RoundedJPanel displaypanel = new RoundedJPanel();
        displaypanel.setBackground(new Color(255, 255, 255));
        displaypanel.setBounds(10, 70, 630, 374);
        leaverequestdetailspanel.add(displaypanel);
        displaypanel.setLayout(null);

        tabledisplay = new JTable();
        tabledisplay.setShowVerticalLines(false);
        tabledisplay.setBounds(10, 11, 620, 363);
        tabledisplay.setRowHeight(30);
        tabledisplay.setOpaque(false);
        tabledisplay.setFont(new Font("Inter Medium", Font.BOLD, 15));

        // Create a table model with column names
        String[] columnNames = {"From Date", "To Date", "Update"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 1);
        tabledisplay.setModel(new DefaultTableModel(
        	new Object[][] {
        		{"   From Date", "   To Date", "   Update"},
        	},
        	new String[] {
        		"   From Date", "   To Date", "   Update"
        	}
        )); // Set the table model to the tabledisplay JTable

        displaypanel.add(tabledisplay);

        
        // Adjust the preferred size of the scroll pane
        scrollPane.setPreferredSize(new Dimension(1181, 752));

    }
    private void addTimeInRow() {
        // Get the table model
        DefaultTableModel model = (DefaultTableModel) table.getModel();

        // Check if a row already exists
        if (model.getRowCount() > 1) {
            JOptionPane.showMessageDialog(this, "Time in already recorded.");
            return; // Exit the method without adding a new row
        }

        // Prompt user for first name and last name
        String firstName = JOptionPane.showInputDialog(this, "Enter First Name:");
        String lastName = JOptionPane.showInputDialog(this, "Enter Last Name:");

        if (firstName != null && !firstName.isEmpty() && lastName != null && !lastName.isEmpty()) {
            // Validate the entered firstName and lastName against the Employee table
            if (isValidEmployee(firstName, lastName)) {
                // Get current date and time
                Date currentDate = new Date();

                // Format date component
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String currentDateFormatted = dateFormat.format(currentDate);

                // Format time component
                SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
                String currentTimeFormatted = timeFormat.format(currentDate);

                // Add a new row to the table with the current date and time as Time In
                model.addRow(new Object[]{currentDateFormatted, currentTimeFormatted, "", "", "", "", "", "", "", firstName, lastName});
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Account.");
            }
        }
    }

    // Method to validate the entered firstName and lastName against the Employee table
    private boolean isValidEmployee(String firstName, String lastName) {
        try {
            String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
            Connection conn = DriverManager.getConnection(url);

            String query = "SELECT * FROM Employee WHERE e_fname = ? AND e_lname = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                pstmt.setString(1, firstName);
                pstmt.setString(2, lastName);

                ResultSet resultSet = pstmt.executeQuery();

                // If resultSet.next() returns true, it means a matching user was found
                return resultSet.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }



    //method for add break in time 
    private void addBreakInTime() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            // Get current date and time
            Date currentDate = new Date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
            String currentBreakInTime = dateFormat.format(currentDate);

            // Set break in time in the selected row
            table.setValueAt(currentBreakInTime, selectedRow, 2);
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row in the table.");
        }
    }
   
    // method for add break out time 
   private void addBreakOutTime() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            // Get current date and time
            Date currentDate = new Date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
            String currentBreakOutTime = dateFormat.format(currentDate);

            // Set break out time in the selected row
            table.setValueAt(currentBreakOutTime, selectedRow, 3);
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row in the table.");
        }
    }
  
   private void addCheckOutTime() {
	    int selectedRow = table.getSelectedRow();
	    if (selectedRow != -1) {
	        // Prompt user for work hours
	        String input = JOptionPane.showInputDialog(this, "Enter work hours:");
	        if (input != null && !input.isEmpty()) {
	            int workHours = Integer.parseInt(input);

	            // Check if work hours exceed the maximum allowable hours
	            int maxWorkHours = 8;
	            int overtimeHours = 0;
	            int undertimeHours = 0;
	            int absent = 0;
	            String firstName = (String) table.getValueAt(selectedRow, 9); // Index 9 for Firstname
	            String lastName = (String) table.getValueAt(selectedRow, 10); // Index 10 for Lastname
	            if (workHours > maxWorkHours) {
	                overtimeHours = workHours - maxWorkHours;
	                workHours = maxWorkHours;
	            } else if (workHours < maxWorkHours) {
	                undertimeHours = maxWorkHours - workHours;
	            }

	            // Calculate check out time based on work hours
	            Date currentDate = new Date();
	            SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
	            String currentCheckOutTime = dateFormat.format(new Date(currentDate.getTime() + workHours * 60 * 60 * 1000));

	            // Update table with check out time, work hours, overtime, and undertime
	            table.setValueAt(currentCheckOutTime, selectedRow, 4);
	            table.setValueAt(input, selectedRow, 5);
	            table.setValueAt(overtimeHours, selectedRow, 6);
	            table.setValueAt(undertimeHours, selectedRow, 7);

	            // Perform database insertion if needed
	            insertDataToDatabase((String) table.getValueAt(selectedRow, 0), (String) table.getValueAt(selectedRow, 1),
	                    (String) table.getValueAt(selectedRow, 2), (String) table.getValueAt(selectedRow, 3),
	                    (String) table.getValueAt(selectedRow, 4), workHours, overtimeHours, undertimeHours, absent, firstName, lastName);
	        }
	    } else {
	        JOptionPane.showMessageDialog(this, "Please select a row in the table.");
	    }
	}

  
    // method for inserting data to database
    private void insertDataToDatabase(String date, String timeIn, String breakIn, String breakOut, String checkOut,
            int workHours, int overtimeHours, int undertimeHours, int absent, String firstName, String lastName) {
        try {
            String sql = "INSERT INTO Work (w_date, w_timein, w_breakin, w_breakout, w_timeout, overtime, undertime, hoursdone, w_absent, w_fname, w_lname) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, date);
            statement.setString(2, timeIn);
            statement.setString(3, breakIn);
            statement.setString(4, breakOut);
            statement.setString(5, checkOut);
            statement.setInt(6, overtimeHours);
            statement.setInt(7, undertimeHours);
            statement.setInt(8, workHours);
            statement.setInt(9, absent);
            statement.setString(10, firstName);
            statement.setString(11, lastName);

            int rowsAffected = statement.executeUpdate();

            if (rowsAffected > 0) {
                ResultSet generatedKeys = statement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int generatedId = generatedKeys.getInt(1);
                    System.out.println("Inserted row ID: " + generatedId);
                }
            } else {
                System.out.println("No rows affected");
            }

            statement.close();

            JOptionPane.showMessageDialog(this, "Data inserted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error occurred while inserting data to the database.", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

   
 // method for submit btn to get all data from user input
    private void submitLeaveRequest() {
        String lname = txtLastName.getText();
        String fname = txtFirstname.getText();
        Date fromDate = dateChooser.getDate();
        Date toDate = dateChooser_1.getDate();
        String reason = textpane.getText();

        if (lname.equals("Lastname") || lname.isEmpty() || fname.equals("Firstname") || fname.isEmpty() ||
                fromDate == null || toDate == null || reason.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill out all fields.", "Incomplete Information",
                    JOptionPane.WARNING_MESSAGE);
        } else {
            // Calculate total leave days
            long diffInMillies = Math.abs(toDate.getTime() - fromDate.getTime());
            long totalLeaveDays = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);

            // Convert Date objects to strings in the desired format
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String fromDateStr = dateFormat.format(fromDate);
            String toDateStr = dateFormat.format(toDate);

            // All fields are filled out, proceed with saving to database
            insertLeaveRequestToDatabase(lname, fname, fromDateStr, toDateStr, reason, totalLeaveDays);
        }
    }

    // method for inserting data to database
    private void insertLeaveRequestToDatabase(String lname, String fname, String fromDate, String toDate, String reason, long totalLeaveDays) {    
        // Implement database insertion logic here using JDBC
        try {   
            String sql =  "INSERT INTO Leave (leave_lname, leave_fname, leave_fromDate, leave_toDate, leave_reason, leave_totalleaveday) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, lname);
            statement.setString(2, fname);
            statement.setString(3, fromDate);
            statement.setString(4, toDate); 
            statement.setString(5, reason);
            statement.setLong(6, totalLeaveDays);
            
            // Execute the SQL INSERT query
            int rowsAffected = statement.executeUpdate();

            // Check if the query affected any rows
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Leave Request Sent Successfully");
            } else {
                JOptionPane.showMessageDialog(this, "Error: Leave Request Failed.", "Error",
                        JOptionPane.ERROR_MESSAGE);
            }

            // Close the statement
            statement.close();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: Leave Request Failed.", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }


    // Method to display the SQL table data in the panel
 // Method to display the SQL table data in the panel
    private void displayLeaveRequestHistory() {
        try {
            String sql = "SELECT * FROM Leave"; // Adjust SQL query according to your table name
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            // Clear existing rows in the table model
            DefaultTableModel tableModel = (DefaultTableModel) tabledisplay.getModel();
            tableModel.setRowCount(1);

            // Populate table model with data from result set
            while (resultSet.next()) {
                String fromDate = resultSet.getString("leave_fromDate");
                String toDate = resultSet.getString("leave_toDate");
                String details = resultSet.getString("leave_status");
                Object[] rowData = {fromDate, toDate, details};
                tableModel.addRow(rowData);
            }
 
            // Close the result set and statement
            resultSet.close();
            statement.close();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: Failed to retrieve leave request history.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // affect for panel btn 
    private class PanelButtonMouseAdapter extends MouseAdapter{
		JPanel panel;
		
		public PanelButtonMouseAdapter(JPanel panel) {
			this.panel = panel;
		}
		
		public void mouseEntered(MouseEvent e) {
			panel.setBackground(new Color(191, 191, 191));
		}
		
		public void mouseExited(MouseEvent e) {
			panel.setBackground(new Color(255, 255, 255));
		}
		
		public void mousePressed(MouseEvent e) {
			panel.setBackground(new Color(191, 191, 191));
		}
		
		public void mouseReleased(MouseEvent e) {
			panel.setBackground(new Color(191, 191, 191));
		}
	}
  
    // effect for panel btn
    private class PanelButtonMouseAdapter2 extends MouseAdapter{
		JPanel panel;
		
		public PanelButtonMouseAdapter2(JPanel panel) {
			this.panel = panel;
		}
		
		public void mouseEntered(MouseEvent e) {
			panel.setBackground(new Color(190, 190, 190));
		}
		
		public void mouseExited(MouseEvent e) {
			panel.setBackground(new Color(240, 240, 240));
		}
		
		public void mousePressed(MouseEvent e) {
			panel.setBackground(new Color(190, 190, 190));
		}
		
		public void mouseReleased(MouseEvent e) {
			panel.setBackground(new Color(190, 190, 190));
		}
	}
}
