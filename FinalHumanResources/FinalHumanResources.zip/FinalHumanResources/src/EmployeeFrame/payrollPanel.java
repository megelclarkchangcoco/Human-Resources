package EmployeeFrame;

import java.awt.Color;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class payrollPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTextField salaryfield;
	private JTextField absentfield;
	private JTextField leavefield;

	/**
	 * Create the panel.
	 */
	public payrollPanel() {
		setBackground(Color.WHITE); 		
		setBounds(10, 244, 918, 287);
		setLayout(null);
		setOpaque(false);
		
		JPanel bodypanel = new JPanel();
		bodypanel.setBackground(new Color(255, 255, 255));
		bodypanel.setBounds(0, 0, 918, 250);
		add(bodypanel);
		bodypanel.setLayout(null);
		
		JPanel payoffpanel = new JPanel();
		payoffpanel.setBorder(new LineBorder(new Color(192, 192, 192)));
		payoffpanel.setBackground(new Color(255, 255, 255));
		payoffpanel.setBounds(10, 11, 898, 93);
		bodypanel.add(payoffpanel);
		payoffpanel.setLayout(null);
		
		JLabel payoffinformationlbl = new JLabel("Payoff Information");
		payoffinformationlbl.setFont(new Font("Inter Medium", Font.BOLD, 14));
		payoffinformationlbl.setBounds(10, 11, 164, 27);
		payoffpanel.add(payoffinformationlbl); 
		
		JLabel salarylbl = new JLabel("Salary :");
		salarylbl.setFont(new Font("Inter Medium", Font.PLAIN, 12));
		salarylbl.setBounds(10, 49, 72, 21);
		payoffpanel.add(salarylbl);
		
		salaryfield = new JTextField();
		salaryfield.setBackground(new Color(255, 255, 255));
		salaryfield.setEditable(false);
		salaryfield.setBounds(63, 44, 173, 38);
		salaryfield.setFont(new Font("Inter Medium", Font.BOLD, 17));
		payoffpanel.add(salaryfield);
		salaryfield.setColumns(10);
		
		JPanel leavebalancepanel = new JPanel();
		leavebalancepanel.setBorder(new LineBorder(new Color(192, 192, 192)));
		leavebalancepanel.setBackground(new Color(255, 255, 255));
		leavebalancepanel.setBounds(10, 115, 898, 124);
		bodypanel.add(leavebalancepanel);
		leavebalancepanel.setLayout(null);
		
		JLabel lblLeaveBalanceAs = new JLabel("Leave balance as date");
		lblLeaveBalanceAs.setBounds(10, 11, 164, 27);
		lblLeaveBalanceAs.setFont(new Font("Inter Medium", Font.BOLD, 14));
		leavebalancepanel.add(lblLeaveBalanceAs);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(192, 192, 192)));
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(74, 42, 178, 71);
		leavebalancepanel.add(panel);
		panel.setLayout(null);
		
		JLabel lblAbsentDay = new JLabel("Absent in Day");
		lblAbsentDay.setFont(new Font("Inter Medium", Font.PLAIN, 12));
		lblAbsentDay.setBounds(10, 0, 125, 21);
		panel.add(lblAbsentDay);
		
		JLabel lblNewLabel = new JLabel("Day.");
		lblNewLabel.setFont(new Font("Inter Light BETA", Font.PLAIN, 16));
		lblNewLabel.setBounds(20, 25, 62, 35);
		panel.add(lblNewLabel);
		
		absentfield = new JTextField();
		absentfield.setBackground(new Color(255, 255, 255));
		absentfield.setEditable(false);
		absentfield.setBounds(60, 25, 108, 35);
		absentfield.setFont(new Font("Inter Medium", Font.BOLD, 17));
		panel.add(absentfield);
		absentfield.setColumns(10);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(192, 192, 192)));
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(346, 42, 178, 71);
		leavebalancepanel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblSickLeaveIn = new JLabel("sick leave in Day");
		lblSickLeaveIn.setFont(new Font("Inter Medium", Font.PLAIN, 12));
		lblSickLeaveIn.setBounds(10, 0, 127, 21);
		panel_1.add(lblSickLeaveIn);
		
		JLabel lblNewLabel_1 = new JLabel("Day.");
		lblNewLabel_1.setFont(new Font("Inter Light BETA", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(10, 25, 62, 35);
		panel_1.add(lblNewLabel_1);
		
		leavefield = new JTextField();
		leavefield.setBackground(new Color(255, 255, 255));
		leavefield.setEditable(false);
		leavefield.setFont(new Font("Inter Medium", Font.BOLD, 17));
		leavefield.setColumns(10);
		leavefield.setBounds(46, 25, 108, 35);
		panel_1.add(leavefield);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setLayout(null);
		panel_1_1.setBorder(new LineBorder(new Color(192, 192, 192)));
		panel_1_1.setBackground(Color.WHITE);
		panel_1_1.setBounds(628, 42, 178, 71);
		leavebalancepanel.add(panel_1_1);
		
		fetchDataUpdateLabels();
	}
	// method for displaying sql data in labels
	private void fetchDataUpdateLabels() {
	    try {
	        // Establish database connection
	        String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
	        Connection conn = DriverManager.getConnection(url);

	        // Query to count absent days in the Work table
	        String workQuery = "SELECT COUNT(w_absent) AS absent_count FROM Work;";
	        PreparedStatement workStatement = conn.prepareStatement(workQuery);
	        ResultSet workResult = workStatement.executeQuery();
	        int w_absent = 0;
	        if (workResult.next()) {
	            w_absent = workResult.getInt("absent_count");
	        }

	        // Query to count total approved leave days in the Leave table
	        String leaveQuery = "SELECT SUM(leave_totalleaveday) AS total_leave_days FROM Leave WHERE leave_status = 'Approved';";
	        PreparedStatement leaveStatement = conn.prepareStatement(leaveQuery);
	        ResultSet leaveResult = leaveStatement.executeQuery();
	        int leave_totalleaveday = 0;
	        if (leaveResult.next()) {
	            leave_totalleaveday = leaveResult.getInt("total_leave_days");
	        }
	        
	     // Query to count total approved leave days in the Leave table
	        String salaryQuery = "SELECT * FROM Employee";
	        PreparedStatement salaryStatement = conn.prepareStatement(salaryQuery);
	        ResultSet salaryResult = salaryStatement.executeQuery();
	        int salarytotal = 0;
	        if (salaryResult.next()) {
	        	salarytotal = salaryResult.getInt("e_salary"); 
	        }

	        // Display the counts on the absentfield and leavefield
	        absentfield.setText(String.valueOf(w_absent));
	        leavefield.setText(String.valueOf(leave_totalleaveday));
	        salaryfield.setText(String.valueOf(salarytotal));

	        // Close resources
	        workResult.close();
	        workStatement.close();
	        leaveResult.close();
	        leaveStatement.close(); 
	        conn.close();
	    } catch (SQLException e) {
	        e.printStackTrace(); 
	        // Handle SQL exceptions
	        System.out.println("Failed Read Database file");
	    }
	}
}