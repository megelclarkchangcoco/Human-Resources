package EmployeeFrame;
 
import java.awt.EventQueue;    
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import javax.swing.border.MatteBorder;
import javax.swing.border.BevelBorder;
import java.awt.Font;
import javax.swing.border.TitledBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.border.LineBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.SoftBevelBorder;

public class EmployeeFrame extends JFrame { 
	
	private ImageIcon logo = new ImageIcon
			(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\loginframeicon\\\\metrologo.png")
			.getImage().getScaledInstance(183, 31, Image.SCALE_DEFAULT));
	private ImageIcon profile = new ImageIcon
			(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\loginframeicon\\\\lecprofile.png")
			.getImage().getScaledInstance(39, 31, Image.SCALE_DEFAULT));
	private ImageIcon profile2 = new ImageIcon
			(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\loginframeicon\\\\lecprofile.png")
			.getImage().getScaledInstance(63, 44, Image.SCALE_DEFAULT));
	private ImageIcon manageaccount = new ImageIcon 
			(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\loginframeicon\\\\user-pen.png")
			.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon signout = new ImageIcon
			(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\loginframeicon\\\\sign-in-alt.png") 
			.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon work = new ImageIcon
			(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\loginframeicon\\\\edit (2).png")
			.getImage().getScaledInstance(28, 27, Image.SCALE_DEFAULT));
	private ImageIcon attendance = new ImageIcon
			(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\loginframeicon\\\\calendar-clock (1).png")
			.getImage().getScaledInstance(28, 27, Image.SCALE_DEFAULT));
	private ImageIcon exit = new ImageIcon
			(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\loginframeicon\\\\cross-small.png")
			.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon mini = new ImageIcon
			(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\employeeframeicon\\\\minus.png")
			.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon home = new ImageIcon
			(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\employeeframeicon\\\\home.png")
			.getImage().getScaledInstance(28, 27, Image.SCALE_DEFAULT));
	private ImageIcon work2 = new ImageIcon
			(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\loginframeicon\\\\edit (2).png")
			.getImage().getScaledInstance(82, 75, Image.SCALE_DEFAULT));
	private ImageIcon attendance2 = new ImageIcon
			(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\loginframeicon\\\\calendar-clock (1).png")
			.getImage().getScaledInstance(82, 75, Image.SCALE_DEFAULT));
	private ImageIcon dots = new ImageIcon
			(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\loginframeicon\\\\circle.png")
			.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon profiles = new ImageIcon
			(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\employeeframeicon\\\\user-gear.png")
			.getImage().getScaledInstance(28, 27, Image.SCALE_DEFAULT));
	
	private static final long serialVersionUID = 1L;
	private static boolean isVisible = false;
	
	private JPanel manageaccountPanel;
	private JPanel contentPane;
	private RoundedTextField searchField;
	private JPanel profilemenuPanel;
	private JPanel bodyPanel; 
	private JLabel worklblt;
	public static employeebodyPanel ebp;
	public static ProfileEmployeeFrame pef;
	public static workPanel workpanel;
	public static attendancePanel attendancepanel;
//	public static manageprofilePanel mppanel;
	public static JPanel selectedPanel;
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EmployeeFrame frame = new EmployeeFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EmployeeFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1265, 803);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		setLocationRelativeTo(null);
		setUndecorated(true);
		contentPane.setBorder(new LineBorder(new Color(41, 75, 141), 4));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		// create an instance panel class
		ebp = new employeebodyPanel();
		workpanel = new workPanel(); 
		attendancepanel = new attendancePanel();
//		mppanel = new manageprofilePanel();
		
		// set thr bounds of the panel
		ebp.setBounds(74, 51, 1191, 752);
		workpanel.setBounds(74, 51, 1191, 752);
		attendancepanel.setBounds(74, 51, 1191, 752);
//		mppanel.setBounds(74, 51, 1191, 752);
		// add the All Panel instance to the content pane of the EmployeeFrame
		contentPane.add(workpanel);
		contentPane.add(attendancepanel);
//		contentPane.add(mppanel);
		// Call revalidate() and repaint to update the frame
		contentPane.revalidate();
		contentPane.repaint();
		
		JPanel headpanel = new JPanel();
		headpanel.setBorder(new MatteBorder(2, 2, 3, 2, (Color) new Color(41, 75, 141)));
		headpanel.setBackground(new Color(255, 255, 255));
		headpanel.setBounds(0, 0, 1265, 51);
		contentPane.add(headpanel);
		headpanel.setLayout(null);
		
		JPanel searchPanel = new JPanel();
		searchPanel.setBounds(476, 13, 294, 31);
		searchPanel.setBackground(new Color(255, 255, 255));
		headpanel.add(searchPanel);
		searchPanel.setLayout(null);
		
		searchField = new RoundedTextField();
		searchField.setText("Search");
		searchField.setBounds(0, 0, 294, 31);
		searchField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                if (searchField.getText().equals("")) {
                    searchField.setForeground(new Color(96, 96, 96));
                    searchField.setText("Search"); // Set text directly
                }
            }

            @Override
            public void focusGained(FocusEvent e) {
                if (searchField.getText().equals("Search")) { // Check for text directly
                    searchField.setForeground(Color.BLACK);
                    searchField.setText("");
                }
            }
        });
		searchField.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        String userInput = searchField.getText();

		        if (userInput != null && !userInput.isEmpty()) {
		            bodyPanel.setVisible(true);
		        }
 
		        if (userInput.equalsIgnoreCase("Work")) {
		            menuClicked(workpanel);
		            bodyPanel.setVisible(false);
		            workpanel.setVisible(true);
		            attendancepanel.setVisible(false);
//		            mppanel.setVisible(false);
		        } else if (userInput.equalsIgnoreCase("Attendance")) {
		            menuClicked(attendancepanel);
		            bodyPanel.setVisible(false);
		            workpanel.setVisible(false);
		            attendancepanel.setVisible(true);
//		            mppanel.setVisible(false);
		        }else if (userInput.equalsIgnoreCase("Profile")) {
//		        	menuClicked(mppanel);
		            bodyPanel.setVisible(false);
		            workpanel.setVisible(false);
		            attendancepanel.setVisible(false);
//		            mppanel.setVisible(true);
		        }
		    }
		});
		searchPanel.add(searchField);
		searchField.setColumns(10);
		
		
		// to do
		JPanel profilePanel = new JPanel();
		profilePanel.setBorder(new MatteBorder(2, 0, 3, 0, (Color) new Color(41, 75, 141)));
		profilePanel.addMouseListener(new PanelButtonMouseAdapter(profilePanel) {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        isVisible = !isVisible; // Toggle isVisible flag
		        profilemenuPanel.setVisible(isVisible); // Set visibility based on the flag
		    }
		});

		profilePanel.setBackground(new Color(255, 255, 255));
		profilePanel.setBounds(1075, 0, 63, 51);
		headpanel.add(profilePanel);
		profilePanel.setLayout(null);
		 
		JLabel profilelbl = new JLabel(""); 
		profilelbl.setIcon(profile);
		profilelbl.setBounds(12, 13, 39, 31);
		profilePanel.add(profilelbl);
		
		JPanel minimizePanel = new JPanel();
		minimizePanel.setBackground(new Color(255, 255, 255));
		minimizePanel.addMouseListener(new PanelButtonMouseAdapter(minimizePanel) {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        setState(JFrame.ICONIFIED); // Minimize the frame
		    }
		});
		minimizePanel.setBounds(1166, 13, 41, 31);
		headpanel.add(minimizePanel);
		minimizePanel.setLayout(null);
		
		JLabel minilbl = new JLabel("");
		minilbl.setBounds(12, 0, 29, 31);
		minilbl.setIcon(mini);// ====
		minimizePanel.add(minilbl);
		
		JPanel exitPanel = new JPanel();
		exitPanel.addMouseListener(new PanelButtonMouseAdapter2(exitPanel) {
			@Override
			public void mouseClicked(MouseEvent e) {
				int option = JOptionPane.showConfirmDialog(contentPane, "Are you sure you want to close this application?", "Confirmation", JOptionPane.YES_NO_OPTION);

				if (option == JOptionPane.YES_OPTION) {
				    System.exit(0); // Exit the application
				} 

			}
		});
		exitPanel.setBackground(new Color(255, 255, 255));
		exitPanel.setBounds(1212, 13, 41, 31);
		headpanel.add(exitPanel);
		exitPanel.setLayout(null);
		
		JLabel exitlbl = new JLabel("");
		exitlbl.setIcon(exit);
		exitlbl.setBounds(12, 0, 29, 31);
		exitPanel.add(exitlbl);
		
		JPanel logoPanel = new JPanel();
		logoPanel.setBackground(new Color(255, 255, 255));
		logoPanel.setBounds(12, 13, 183, 31);
		logoPanel.setOpaque(false);
		headpanel.add(logoPanel);
		logoPanel.setLayout(null);
		
		JLabel logolbl = new JLabel("");
		logolbl.setBounds(12, 13, 183, 31);
		headpanel.add(logolbl);
		logolbl.setIcon(logo);
		
		JPanel rigthpanel = new JPanel();
		rigthpanel.setBorder(new MatteBorder(0, 2, 2, 2, (Color) new Color(41, 75, 141)));
		rigthpanel.setBackground(new Color(255, 255, 255));
		rigthpanel.setBounds(0, 50, 74, 753);
		contentPane.add(rigthpanel);
		rigthpanel.setLayout(null);
		
		JPanel workPanel = new JPanel();
		workPanel.setBorder(new MatteBorder(0, 2, 0, 1, (Color) new Color(41, 75, 141)));
		workPanel.addMouseListener(new PanelButtonMouseAdapter2(workPanel) {
			@Override
			public void mouseClicked(MouseEvent e) {
				menuClicked(workPanel);
				
				workpanel.setVisible(true);
				bodyPanel.setVisible(false);
				attendancepanel.setVisible(false);
//				mppanel.setVisible(false);
				
				// todo
				 
				
			}
		});
		workPanel.setBackground(new Color(255, 255, 255));
		workPanel.setBounds(0, 109, 73, 57);
		rigthpanel.add(workPanel);
		workPanel.setLayout(null);
		
		JLabel worklbl = new JLabel("");
		worklbl.setIcon(work);
		worklbl.setBounds(22, 0, 28, 27);
		workPanel.add(worklbl);
		
		worklblt = new JLabel("Work");
		worklblt.setFont(new Font("Inter Medium", Font.PLAIN, 10));
		worklblt.setBounds(22, 28, 62, 16);
		workPanel.add(worklblt);
		
		JPanel attendancePanel = new JPanel();
		attendancePanel.setBorder(new MatteBorder(0, 2, 0, 1, (Color) new Color(41, 75, 141)));
		attendancePanel.addMouseListener(new PanelButtonMouseAdapter2(attendancePanel) {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				menuClicked(attendancePanel);
				
				
				attendancepanel.setVisible(true);
				workpanel.setVisible(false);
				bodyPanel.setVisible(false);
//				mppanel.setVisible(false);
			}
		});
		attendancePanel.setBackground(Color.WHITE);
		attendancePanel.setBounds(0, 170, 73, 57);
		rigthpanel.add(attendancePanel);
		attendancePanel.setLayout(null);
		
		JLabel attendancelbl = new JLabel("");
		attendancelbl.setIcon(attendance);
		attendancelbl.setBounds(23, 0, 28, 27);
		attendancePanel.add(attendancelbl);
		
		JLabel lblAttendance = new JLabel("Attendance");
		lblAttendance.setFont(new Font("Inter Medium", Font.PLAIN, 10));
		lblAttendance.setBounds(12, 30, 72, 14);
		attendancePanel.add(lblAttendance);
		
		JPanel homePanel = new JPanel();
		homePanel.addMouseListener(new PanelButtonMouseAdapter(homePanel) {
			@Override
			public void mouseClicked(MouseEvent e) {
				menuClicked(homePanel);
				
				workpanel.setVisible(false);
				attendancepanel.setVisible(false);
				bodyPanel.setVisible(true);
//				mppanel.setVisible(false);
			}
		});
		homePanel.setLayout(null);
		homePanel.setBorder(new MatteBorder(0, 2, 0, 1, (Color) new Color(41, 75, 141)));
		homePanel.setBackground(Color.WHITE);
		homePanel.setBounds(0, 50, 73, 57);
		rigthpanel.add(homePanel);
		
		JLabel homelbl = new JLabel("");
		homelbl.setIcon(home);
		homelbl.setBounds(22, 0, 28, 27);
		homePanel.add(homelbl);
		
		JLabel hometxtlbl = new JLabel("Home");
		hometxtlbl.setFont(new Font("Inter Medium", Font.PLAIN, 10));
		hometxtlbl.setBounds(22, 28, 62, 16);
		homePanel.add(hometxtlbl);
		
		JPanel profilepanel = new JPanel();
		profilepanel.addMouseListener(new PanelButtonMouseAdapter(profilepanel) {
			@Override
			public void mouseClicked(MouseEvent e) {
				menuClicked(profilepanel);
//				mppanel.setVisible(true);
				ProfileEmployeeFrame pef = new ProfileEmployeeFrame();
				pef.setLocationRelativeTo(null);
				pef.setVisible(true);
				
			}
		});
		profilepanel.setLayout(null);
		profilepanel.setBorder(new MatteBorder(0, 2, 0, 1, (Color) new Color(41, 75, 141)));
		profilepanel.setBackground(Color.WHITE);
		profilepanel.setBounds(0, 227, 73, 57);
		rigthpanel.add(profilepanel);
		
		JLabel profilelbls = new JLabel("");
		profilelbls.setIcon(profiles);
		profilelbls.setBounds(24, 11, 28, 27);
		profilepanel.add(profilelbls);
		
		JLabel lblProfile = new JLabel("Profile");
		lblProfile.setFont(new Font("Inter Medium", Font.PLAIN, 10));
		lblProfile.setBounds(24, 39, 62, 16);
		profilepanel.add(lblProfile);
		
		bodyPanel = new JPanel(); 
		bodyPanel.setBorder(new MatteBorder(0, 0, 2, 2, (Color) new Color(41, 75, 141)));
		bodyPanel.setBackground(new Color(255, 255, 255));
		bodyPanel.setBounds(74, 51, 1191, 752);
		contentPane.add(bodyPanel);
		bodyPanel.setLayout(null);
		
		// to - do
		profilemenuPanel = new JPanel();
		profilemenuPanel.setBackground(new Color(255, 255, 255));
		profilemenuPanel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, new Color(41, 75, 141), new Color(41, 75, 141), null));
		profilemenuPanel.setBounds(975, 0, 216, 227);
		profilemenuPanel.setVisible(false);
		bodyPanel.add(profilemenuPanel);
		profilemenuPanel.setLayout(null);
		
		JPanel signoutPanel = new JPanel();
		signoutPanel.setBorder(new MatteBorder(1, 0, 2, 0, (Color) new Color(41, 75, 141)));
		signoutPanel.addMouseListener(new PanelButtonMouseAdapter(signoutPanel) {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				int option = JOptionPane.showConfirmDialog(contentPane, "Sign Out Confirmation", "Confirmation", JOptionPane.YES_NO_OPTION);

				if (option == JOptionPane.YES_OPTION) {
				    System.exit(0); // Exit the application
				} ;
			}
		});
		signoutPanel.setBackground(new Color(255, 255, 255));
		signoutPanel.setBounds(12, 146, 192, 42);
		profilemenuPanel.add(signoutPanel);
		signoutPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Sign Out");
		lblNewLabel.setIcon(signout);
		lblNewLabel.setBounds(12, 13, 93, 29);
		signoutPanel.add(lblNewLabel);
		
		JLabel metrolbl = new JLabel("Metro Pacific Invesment");
		metrolbl.setFont(new Font("Inter Medium", Font.PLAIN, 15));
		metrolbl.setBounds(12, 13, 192, 26);
		profilemenuPanel.add(metrolbl);
		// to do
		JPanel profilePanel_1 = new JPanel();
		profilePanel_1.setLayout(null);
		profilePanel_1.setOpaque(false);
		profilePanel_1.setBackground(Color.WHITE);
		profilePanel_1.setBounds(12, 42, 63, 44);
		profilemenuPanel.add(profilePanel_1);
		
		JLabel profilelbl_1 = new JLabel(""); 
		profilelbl_1.setIcon(profile2);;
		profilelbl_1.setBounds(0, 0, 63, 44);
		profilePanel_1.add(profilelbl_1);
		
		JLabel namelbl = new JLabel("name");
		namelbl.setBounds(87, 42, 56, 16);
		profilemenuPanel.add(namelbl);
		
		JLabel idlbl = new JLabel("id");
		idlbl.setBounds(87, 70, 56, 16);
		profilemenuPanel.add(idlbl);
		// to do
		 manageaccountPanel = new JPanel();
		 manageaccountPanel.addMouseListener(new PanelButtonMouseAdapter(manageaccountPanel) {
			 @Override
			    public void mouseClicked(MouseEvent e) {
			        pef = new ProfileEmployeeFrame(); // Create ProfileEmployeeFrame instance
			        pef.setLocationRelativeTo(null); // Center the frame
			        pef.setUndecorated(true);
			        pef.setVisible(true); // Show the frame
			    }

		 });
		manageaccountPanel.setBorder(new MatteBorder(2, 0, 1, 0, (Color) new Color(41, 75, 141)));
		manageaccountPanel.setBackground(new Color(255, 255, 255));
		manageaccountPanel.setBounds(12, 104, 192, 42);
		profilemenuPanel.add(manageaccountPanel);
		manageaccountPanel.setLayout(null);
		
		JLabel lblManageAccount = new JLabel("Manage Account");
		lblManageAccount.setIcon(manageaccount);
		lblManageAccount.setBounds(12, 13, 125, 29);
		manageaccountPanel.add(lblManageAccount);
		
		JPanel toworktabpanel = new JPanel();
		toworktabpanel.addMouseListener(new PanelButtonMouseAdapter(toworktabpanel) {
			@Override
			public void mouseClicked(MouseEvent e) {
				menuClicked(workpanel);
				attendancepanel.setVisible(false);
				bodyPanel.setVisible(false);
				workpanel.setVisible(true);
			}
		});
		toworktabpanel.setBorder(new LineBorder(new Color(41, 75, 141)));
		toworktabpanel.setBackground(new Color(255, 255, 255));
		toworktabpanel.setBounds(73, 55, 228, 196);
		bodyPanel.add(toworktabpanel);
		toworktabpanel.setLayout(null);
		
		JLabel workicontab2 = new JLabel("");
		workicontab2.setIcon(work2);
		workicontab2.setBounds(66, 36, 82, 75);
		toworktabpanel.add(workicontab2); 
		 
		JLabel worklbl2 = new JLabel("Work");
		worklbl2.setForeground(new Color(0, 0, 0));
		worklbl2.setFont(new Font("Inter Medium", Font.BOLD, 18));
		worklbl2.setBounds(76, 122, 72, 42);
		toworktabpanel.add(worklbl2);
		
		JPanel toattendancetabpanel = new JPanel();
		toattendancetabpanel.addMouseListener(new PanelButtonMouseAdapter(toattendancetabpanel) {
			@Override
			public void mouseClicked(MouseEvent e) {
				menuClicked(attendancepanel);
				attendancepanel.setVisible(true);
				bodyPanel.setVisible(false);
				workpanel.setVisible(false);
				
			}
		});
		toattendancetabpanel.setBorder(new LineBorder(new Color(41, 75, 141)));
		toattendancetabpanel.setBackground(new Color(255, 255, 255));
		toattendancetabpanel.setBounds(345, 55, 228, 196);
		bodyPanel.add(toattendancetabpanel);
		toattendancetabpanel.setLayout(null);
		
		JLabel attendanceicontab2 = new JLabel("");
		attendanceicontab2.setIcon(attendance2);
		attendanceicontab2.setBounds(70, 36, 82, 75);
		toattendancetabpanel.add(attendanceicontab2);
		
		JLabel attendancelbl2 = new JLabel("Attendance");
		attendancelbl2.setFont(new Font("Inter Medium", Font.BOLD, 18));
		attendancelbl2.setBounds(54, 122, 152, 42);
		toattendancetabpanel.add(attendancelbl2);
		
		//--------------- end ------------------------- to do
		
	}
	
	// create new method for Jpanel Class
	public void menuClicked(JPanel selectedPanel) {
		ebp.setVisible(false);
		workpanel.setVisible(false);
		attendancepanel.setVisible(false);;
//		mppanel.setVisible(false);
		selectedPanel.setVisible(true);
		// set the selected panel to the variable
		this.selectedPanel = selectedPanel;
	}
	
	private class PanelButtonMouseAdapter extends MouseAdapter{
		JPanel panel;
		
		public PanelButtonMouseAdapter(JPanel panel) { 
			this.panel = panel;
		}
		
		public void mouseEntered(MouseEvent e) {
			panel.setBackground(new Color(195, 195, 195));
		}
		
		
		public void mouseExited(MouseEvent e) {
			panel.setBackground(new Color(255, 255, 255));
		}
		
		public void mousePressed(MouseEvent e) {
			panel.setBackground(new Color(195, 195, 195));
		}
		
		public void mouseReleased(MouseEvent e) {
			panel.setBackground(new Color(195, 195, 195));
		}
	} 
	
	private class PanelButtonMouseAdapter2 extends MouseAdapter{
		JPanel panel;
		
		public PanelButtonMouseAdapter2(JPanel panel) {
			this.panel = panel;
		}
		
		public void mouseEntered(MouseEvent e) {
			panel.setBackground(new Color(195, 195, 195));
		}
		
		public void mouseExited(MouseEvent e) {
			panel.setBackground(new Color(255, 255, 255));
		}
		
		public void mousePressed(MouseEvent e) {
			panel.setBackground(new Color(195, 195, 195));
		}
		
		public void mouseReleased(MouseEvent e) {
			panel.setBackground(new Color(195, 195,195));
		}
	}
}
