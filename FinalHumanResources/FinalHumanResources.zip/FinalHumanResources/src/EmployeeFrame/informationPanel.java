	package EmployeeFrame;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.border.MatteBorder;
import javax.swing.JTextField;

public class informationPanel extends JPanel {

	private static final long serialVersionUID = 1L;
   private JTextField primaryfield;
   private JTextField secondaryfield;
   private JTextField collegefield;
   private JTextField workexperience1;
   private JTextField firstnamefield;
   private JTextField contactfield;
   private JTextField addressfield;
   private JTextField middlenamefield;
   private JTextField genderfield;
   private JTextField lastnamefield;
   private JTextField birthfield;
   private JTextField emailfield;
   private JTextField agefield;
   private JPanel skillspanel;
   private JLabel lblEducationalBackground_1;
   private JLabel lblNewLabel_2;
   private JLabel lblNewLabel_1_4;
   private JLabel lblNewLabel_1_5;
   private JTextField skillsfield;
   private JTextField frameworkfield;
   private JTextField toolsfield;
   private JLabel lblWorkExperience_1;
   private JLabel certificatelbl;
	/**
	 * Create the panel.
	 */
	public informationPanel() {
		setBackground(Color.WHITE); 		
		setBounds(10, 244, 918, 287);
		setLayout(null);
		setOpaque(false);
		
		JPanel bodyPanel = new JPanel();
		bodyPanel.setBounds(0, 0, 918, 321);
		add(bodyPanel);
		bodyPanel.setLayout(null); 
		
		 // Create the scroll pane and set its bounds
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(0, 0, 918, 287); // Adjusted the size to fit within the bounds of bodyPanel
        bodyPanel.add(scrollPane);
          
         
        // Create the panel to hold the content to be scrolled
        JPanel scrollContent = new JPanel();
        scrollContent.setBackground(new Color(255, 255, 255));
        scrollContent.setLayout(null);
        scrollContent.setPreferredSize(new Dimension(925, 610)); // Set a preferred size for scrolling
        scrollPane.setViewportView(scrollContent);
        
        JPanel head = new JPanel();
        head.setBorder(new MatteBorder(0, 0, 1, 0, (Color) new Color(192, 192, 192)));
        head.setBackground(new Color(255, 255, 255));
        head.setBounds(0, 0, 904, 221);
        scrollContent.add(head);
        head.setLayout(null);
         
        JLabel informationlnl = new JLabel("Information");
        informationlnl.setFont(new Font("Inter Light BETA", Font.BOLD, 16));
        informationlnl.setBounds(10, 0, 105, 39);
        head.add(informationlnl);
        
        JLabel lblNewLabel = new JLabel("firstname :");
        lblNewLabel.setFont(new Font("Inter Medium", Font.PLAIN, 12));
        lblNewLabel.setBounds(10, 68, 74, 23);
        head.add(lblNewLabel);
        
        JLabel lblMiddleName = new JLabel("middle name :");
        lblMiddleName.setFont(new Font("Inter Medium", Font.PLAIN, 12));
        lblMiddleName.setBounds(245, 68, 111, 23);
        head.add(lblMiddleName);
        
        JLabel lblLastName = new JLabel("last name :");
        lblLastName.setFont(new Font("Inter Medium", Font.PLAIN, 12));
        lblLastName.setBounds(485, 68, 74, 23);
        head.add(lblLastName);
        
        JLabel lblContact = new JLabel("contact :");
        lblContact.setFont(new Font("Inter Medium", Font.PLAIN, 12));
        lblContact.setBounds(10, 120, 74, 23);
        head.add(lblContact);
        
        JLabel lblGender = new JLabel("gender : ");
        lblGender.setFont(new Font("Inter Medium", Font.PLAIN, 12));
        lblGender.setBounds(271, 118, 74, 23);
        head.add(lblGender);
        
        JLabel birthlbl = new JLabel("Birth :");
        birthlbl.setFont(new Font("Inter Medium", Font.PLAIN, 12));
        birthlbl.setBounds(513, 120, 46, 23);
        head.add(birthlbl);
        
        JLabel agelbl = new JLabel("age : ");
        agelbl.setFont(new Font("Inter Medium", Font.PLAIN, 12));
        agelbl.setBounds(708, 118, 74, 23);
        head.add(agelbl);
        
        JLabel lblNewLabel_5 = new JLabel("address :");
        lblNewLabel_5.setFont(new Font("Inter Medium", Font.PLAIN, 12));
        lblNewLabel_5.setBounds(10, 173, 74, 23);
        head.add(lblNewLabel_5);
        
        firstnamefield = new JTextField();
        firstnamefield.setBackground(new Color(255, 255, 255));
        firstnamefield.setEditable(false);
        firstnamefield.setFont(new Font("Inter Medium", Font.PLAIN, 14));
        firstnamefield.setBounds(78, 64, 140, 33);
        head.add(firstnamefield);
        firstnamefield.setColumns(10);
        
        contactfield = new JTextField();
        contactfield.setBackground(new Color(255, 255, 255));
        contactfield.setEditable(false);
        contactfield.setFont(new Font("Inter Medium", Font.PLAIN, 14));
        contactfield.setColumns(10);
        contactfield.setBounds(78, 116, 140, 33);
        head.add(contactfield);
        
        addressfield = new JTextField();
        addressfield.setBackground(new Color(255, 255, 255));
        addressfield.setEditable(false);
        addressfield.setFont(new Font("Inter Medium", Font.PLAIN, 14));
        addressfield.setColumns(10);
        addressfield.setBounds(78, 169, 185, 33);
        head.add(addressfield);
        
        middlenamefield = new JTextField();
        middlenamefield.setBackground(new Color(255, 255, 255));
        middlenamefield.setEditable(false);
        middlenamefield.setFont(new Font("Inter Medium", Font.PLAIN, 14));
        middlenamefield.setColumns(10);
        middlenamefield.setBounds(335, 61, 140, 33);
        head.add(middlenamefield);
        
        genderfield = new JTextField();
        genderfield.setBackground(new Color(255, 255, 255));
        genderfield.setEditable(false);
        genderfield.setFont(new Font("Inter Medium", Font.PLAIN, 14));
        genderfield.setColumns(10);
        genderfield.setBounds(335, 116, 140, 33);
        head.add(genderfield);
        
        lastnamefield = new JTextField();
        lastnamefield.setBackground(new Color(255, 255, 255));
        lastnamefield.setEditable(false);
        lastnamefield.setFont(new Font("Inter Medium", Font.PLAIN, 14));
        lastnamefield.setColumns(10);
        lastnamefield.setBounds(554, 62, 140, 33);
        head.add(lastnamefield);
        
        birthfield = new JTextField();
        birthfield.setBackground(new Color(255, 255, 255));
        birthfield.setEditable(false);
        birthfield.setFont(new Font("Inter Medium", Font.PLAIN, 14));
        birthfield.setColumns(10);
        birthfield.setBounds(554, 116, 140, 33);
        head.add(birthfield);
        
        emailfield = new JTextField();
        emailfield.setBackground(new Color(255, 255, 255));
        emailfield.setEditable(false);
        emailfield.setFont(new Font("Inter Medium", Font.PLAIN, 14));
        emailfield.setColumns(10);
        emailfield.setBounds(742, 64, 152, 33);
        head.add(emailfield);
         
        agefield = new JTextField();
        agefield.setBackground(new Color(255, 255, 255));
        agefield.setEditable(false);
        agefield.setFont(new Font("Inter Medium", Font.PLAIN, 14));
        agefield.setColumns(10);
        agefield.setBounds(742, 116, 152, 33);
        head.add(agefield);
        
        JPanel educationalpanel = new JPanel();
        educationalpanel.setBorder(new MatteBorder(0, 0, 1, 0, (Color) new Color(192, 192, 192)));
        educationalpanel.setBackground(new Color(255, 255, 255));
        educationalpanel.setBounds(0, 214, 904, 195);
        scrollContent.add(educationalpanel);
        educationalpanel.setLayout(null);
        
        JLabel lblEducationalBackground = new JLabel("Educational Background");
        lblEducationalBackground.setFont(new Font("Inter Light BETA", Font.BOLD, 16));
        lblEducationalBackground.setBounds(10, 11, 244, 39);
        educationalpanel.add(lblEducationalBackground);
        
        JLabel lblNewLabel_1 = new JLabel("Primary         :");
        lblNewLabel_1.setFont(new Font("Inter Medium", Font.PLAIN, 12));
        lblNewLabel_1.setBounds(10, 52, 79, 39);
        educationalpanel.add(lblNewLabel_1);
        
        JLabel lblNewLabel_1_1 = new JLabel("Secondary   :");
        lblNewLabel_1_1.setFont(new Font("Inter Medium", Font.PLAIN, 12));
        lblNewLabel_1_1.setBounds(10, 97, 79, 39);
        educationalpanel.add(lblNewLabel_1_1);
        
        JLabel lblNewLabel_1_2 = new JLabel("College         : ");
        lblNewLabel_1_2.setFont(new Font("Inter Medium", Font.PLAIN, 12));
        lblNewLabel_1_2.setBounds(10, 144, 79, 39);
        educationalpanel.add(lblNewLabel_1_2);
        
        primaryfield = new JTextField();
        primaryfield.setBackground(new Color(255, 255, 255));
        primaryfield.setEditable(false);
        primaryfield.setFont(new Font("Inter Medium", Font.PLAIN, 14));
        primaryfield.setBounds(99, 52, 386, 39);
        educationalpanel.add(primaryfield);
        primaryfield.setColumns(10);
        
        secondaryfield = new JTextField();
        secondaryfield.setBackground(new Color(255, 255, 255));
        secondaryfield.setEditable(false);
        secondaryfield.setFont(new Font("Inter Medium", Font.PLAIN, 14));
        secondaryfield.setColumns(10);
        secondaryfield.setBounds(99, 98, 386, 39);
        educationalpanel.add(secondaryfield);
        
        collegefield = new JTextField();
        collegefield.setBackground(new Color(255, 255, 255));
        collegefield.setEditable(false);
        collegefield.setFont(new Font("Inter Medium", Font.PLAIN, 14));
        collegefield.setColumns(10);
        collegefield.setBounds(99, 145, 386, 39);
        educationalpanel.add(collegefield);
        
        JLabel lblWorkExperience = new JLabel("Work Experience");
        lblWorkExperience.setFont(new Font("Inter Light BETA", Font.BOLD, 16));
        lblWorkExperience.setBounds(635, 11, 244, 39);
        educationalpanel.add(lblWorkExperience);
        
        JLabel lblNewLabel_1_3 = new JLabel("1        :");
        lblNewLabel_1_3.setFont(new Font("Inter Medium", Font.PLAIN, 12));
        lblNewLabel_1_3.setBounds(542, 52, 46, 39);
        educationalpanel.add(lblNewLabel_1_3);
        
        workexperience1 = new JTextField();
        workexperience1.setBackground(new Color(255, 255, 255));
        workexperience1.setEditable(false);
        workexperience1.setFont(new Font("Inter Medium", Font.PLAIN, 14));
        workexperience1.setColumns(10);
        workexperience1.setBounds(581, 52, 313, 39);
        educationalpanel.add(workexperience1);
        
        skillspanel = new JPanel();
        skillspanel.setLayout(null);
        skillspanel.setBackground(Color.WHITE);
        skillspanel.setBounds(0, 410, 904, 195);
        scrollContent.add(skillspanel);
        
        lblEducationalBackground_1 = new JLabel("Skills");
        lblEducationalBackground_1.setFont(new Font("Inter Light BETA", Font.BOLD, 16));
        lblEducationalBackground_1.setBounds(10, 11, 244, 39);
        skillspanel.add(lblEducationalBackground_1);
        
        lblNewLabel_2 = new JLabel("Skills               :");
        lblNewLabel_2.setFont(new Font("Inter Medium", Font.PLAIN, 12));
        lblNewLabel_2.setBounds(10, 52, 79, 39);
        skillspanel.add(lblNewLabel_2);
        
        lblNewLabel_1_4 = new JLabel("Framework   :");
        lblNewLabel_1_4.setFont(new Font("Inter Medium", Font.PLAIN, 12));
        lblNewLabel_1_4.setBounds(10, 97, 79, 39);
        skillspanel.add(lblNewLabel_1_4);
        
        lblNewLabel_1_5 = new JLabel("Tools              : ");
        lblNewLabel_1_5.setFont(new Font("Inter Medium", Font.PLAIN, 12));
        lblNewLabel_1_5.setBounds(10, 144, 79, 39);
        skillspanel.add(lblNewLabel_1_5);
        
        skillsfield = new JTextField();
        skillsfield.setBackground(new Color(255, 255, 255));
        skillsfield.setText("Java, Python, JavaScript, C#");
        skillsfield.setFont(new Font("Inter Medium", Font.PLAIN, 14));
        skillsfield.setEditable(false);
        skillsfield.setColumns(10);
        skillsfield.setBounds(99, 52, 386, 39);
        skillspanel.add(skillsfield);
        
        frameworkfield = new JTextField();
        frameworkfield.setBackground(new Color(255, 255, 255));
        frameworkfield.setText("Cloud Control Matrix, NIST, ISO 27001 and ISO 27002");
        frameworkfield.setFont(new Font("Inter Medium", Font.PLAIN, 14));
        frameworkfield.setEditable(false);
        frameworkfield.setColumns(10);
        frameworkfield.setBounds(99, 98, 386, 39);
        skillspanel.add(frameworkfield);
        
        toolsfield = new JTextField();
        toolsfield.setBackground(new Color(255, 255, 255));
        toolsfield.setText("Kali Linux, Firewalls, Penetration testing");
        toolsfield.setFont(new Font("Inter Medium", Font.PLAIN, 14));
        toolsfield.setEditable(false);
        toolsfield.setColumns(10);
        toolsfield.setBounds(99, 145, 386, 39);
        skillspanel.add(toolsfield);
        
        lblWorkExperience_1 = new JLabel("Certificate");
        lblWorkExperience_1.setFont(new Font("Inter Light BETA", Font.BOLD, 16));
        lblWorkExperience_1.setBounds(635, 11, 244, 39);
        skillspanel.add(lblWorkExperience_1);
        
        certificatelbl = new JLabel("");
        certificatelbl.setBounds(635, 52, 223, 113);
        skillspanel.add(certificatelbl);
        
        
        
        // Adjust the preferred size of the scroll pane
        scrollPane.setPreferredSize(new Dimension(700, 8));
		 
        // add picture from sql table 
        loadpictureicon(); 
		 
        // Fetch data from the database and update labels
        fetchDataAndUpdateLabels("Charles", "Leclecr", "Lcharles@yahoo.com", "0906210123", "1342 Tondo Morza Manila", 26," Jan 01, 1998", "Male","Fransico Balagtas Elementary School 2001-2007","Cayetano Arellano High School 2007-2011", "National University-Manila 2011-2015", "JP Morgans Cybersecurity july 2015 - feb 2018");
        
        
        }

        // method for displaying SQL data in labels
	private void fetchDataAndUpdateLabels(String e_fname, String e_lname, String e_emailaddress, String c_contact,  String c_address, int c_age, String c_birthday,  String c_gender, String c_elementary,String c_highschool, String c_college, String c_workexperience) {
	    try {
	        String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
	        Connection conn = DriverManager.getConnection(url);

	        String query = "SELECT * FROM Employee JOIN Credentials ON Employee.e_id = Credentials.c_id WHERE Employee.e_fname = ? AND Employee.e_lname = ? "
	        		+ "AND Employee.e_emailaddress = ? AND Credentials.c_contact = ? AND Credentials.c_address = ? AND Credentials.c_age = ? AND Credentials.c_birthday = ?"
	        		+ " AND Credentials.c_gender = ? AND Credentials.c_elementary = ? AND Credentials.c_highschool = ? AND Credentials.c_college = ? AND Credentials.c_workexperience = ?;";
	        try (PreparedStatement pstmt = conn.prepareStatement(query)) { 
	            pstmt.setString(1, "Charles"); 
	            pstmt.setString(2, "Leclerc"); 
	            pstmt.setString(3, "Lcharles@yahoo.com");
	            pstmt.setString(4, "0906210123");
	            pstmt.setString(5, "1342 Tondo Morza Manila");
	            pstmt.setInt(6, 26);
	            pstmt.setString(7, "Jan 01, 1998");
	            pstmt.setString(8, "Male");
	            pstmt.setString(9, "Fransico Balagtas Elementary School 2001-2007");
	            pstmt.setString(10, "Cayetano Arellano High School 2007-2011");
	            pstmt.setString(11, "National University-Manila 2011-2015");
	            pstmt.setString(12, "JP Morgans Cybersecurity july 2015 - feb 2018");
	            ResultSet result = pstmt.executeQuery(); 
	            if (result.next()) {                                    
	               firstnamefield.setText(result.getString("e_fname"));
	               lastnamefield.setText(result.getString("e_lname")); 
	               emailfield.setText(result.getString("e_emailaddress")); 
	               contactfield.setText(result.getString("c_contact")); 
	               addressfield.setText(result.getString("c_address"));
	               agefield.setText(String.valueOf(result.getInt("c_age")));
	               birthfield.setText(result.getString("c_birthday"));
	               genderfield.setText(result.getString("c_gender")); 
	               primaryfield.setText(result.getString("c_elementary"));
	               secondaryfield.setText(result.getString("c_highschool"));
	               collegefield.setText(result.getString("c_college"));
	               workexperience1.setText(result.getString("c_workexperience"));
	               System.out.println("Data Retrieve");
	            } else { 
	                System.out.println("No data found for the given query.");
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        System.out.println("Error fetching data from the database: " + e.getMessage());
	    }
	}
	
	 // method for retrive image from sql
    private void loadpictureicon() {

        try {
            // Load the JDBC driver class
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            // Define the JDBC URL
            String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";

            // Establish the database connection
            try (Connection connection = DriverManager.getConnection(url)) {
                // Prepare the SQL statement
                String sql = "SELECT c_certificate FROM Credentials WHERE c_id = ?;";
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setInt(1, 1); // Assuming the ID of the image you want to retrieve is 1

                    // Execute the query
                    try (ResultSet resultSet = statement.executeQuery()) {
                        if (resultSet.next()) { 
                            // Retrieve the image data from the result set
                            byte[] imageData = resultSet.getBytes("c_certificate");

                            if (imageData != null && imageData.length > 0) { // Check if image data is not null or empty
                                // Convert the byte array to a BufferedImage
                                try (ByteArrayInputStream bis = new ByteArrayInputStream(imageData)) {
                                    BufferedImage bufferedImage = ImageIO.read(bis);

                                    if (bufferedImage != null) { // Check if BufferedImage was successfully created
                                        // Resize the image to fit the JLabel
                                        Image scaledImage = bufferedImage.getScaledInstance(certificatelbl.getWidth(), certificatelbl.getHeight(), Image.SCALE_SMOOTH);

                                        // Set the scaled image to the JLabel
                                        certificatelbl.setIcon(new ImageIcon(scaledImage));
                                    } else {
                                        System.out.println("Failed to read image data from the database.");
                                    }
                                }
                            } else {
                                System.out.println("Image data retrieved from the database is null or empty.");
                            }
                        } else {
                            System.out.println("No image data found for the specified employee ID.");
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
