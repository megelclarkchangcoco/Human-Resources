package EmployeeFrame;

import java.awt.EventQueue;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.awt.Font;
import java.awt.Image;
import javax.swing.border.MatteBorder;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class ProfileEmployeeFrame extends JFrame {
	private ImageIcon exit = new ImageIcon
			(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\loginframeicon\\\\cross-small.png")
			.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon dots = new ImageIcon
			(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\employeeframeicon\\circle.png")
			.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel profilelbl;
	private JLabel realtime; 
	private JLabel realtimelbls; 
	private JLabel lnamelbl;  
	private JLabel fnamelbl;
    private JLabel designationnamelbl;
    
    public static informationPanel informationpanels; 
    public static  overviewPanel overviewpanel;
    public static payrollPanel payrollpanel;
    public static performancePanel performancepanel; 
    public static JPanel selectedPanel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProfileEmployeeFrame frame = new ProfileEmployeeFrame();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null); // Center the frame
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}); 
	}

	/**
	 * Create the frame. 
	 */
	public ProfileEmployeeFrame() {
		
		  
		setTitle("Manage Profile");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(106, 125, 936, 568);
		setLocationRelativeTo(null);
		setUndecorated(true);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		// creae an instance panel class
		overviewpanel = new overviewPanel();
		informationpanels = new informationPanel();
		payrollpanel = new payrollPanel();
		performancepanel = new performancePanel();
		
		// set the bound of the panel
		overviewpanel.setBounds(10, 284, 915, 270);
		informationpanels.setBounds(10, 284, 915, 270);
		payrollpanel.setBounds(10, 284, 915, 270);
		performancepanel.setBounds(10, 284, 915, 270);
		
		// add the all panel instance to the contenet pane of the employeeframe
		contentPane.add(overviewpanel);
		contentPane.add(informationpanels);
		contentPane.add(payrollpanel);
		contentPane.add(performancepanel);
		// Call revalidate() and repaint to update the frame
		contentPane.revalidate();
		contentPane.repaint();
		
		JPanel wholepanel = new JPanel();
		wholepanel.setBackground(new Color(255, 255, 255));
		wholepanel.setForeground(new Color(190, 190, 190));
		wholepanel.setBorder(new LineBorder(new Color(41, 75, 141), 2));
		wholepanel.setBounds(0, 38, 935, 531);
		contentPane.add(wholepanel);
		wholepanel.setLayout(null);
		
		JPanel profilepanel = new JPanel();
		profilepanel.setBackground(new Color(255, 255, 255));
		profilepanel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(192, 192, 192)));
		profilepanel.setBounds(10, 10, 915, 117);
		wholepanel.add(profilepanel);
		profilepanel.setLayout(null);
		
		 profilelbl = new JLabel("");
		profilelbl.setBounds(10, 11, 95, 95);
		profilepanel.add(profilelbl);
		
		 lnamelbl = new JLabel(""); 
		 lnamelbl.setFont(new Font("Inter Medium", Font.BOLD, 25));
		lnamelbl.setBounds(115, 24, 147, 40);
		profilepanel.add(lnamelbl);
		
		 fnamelbl = new JLabel("");
		 fnamelbl.setFont(new Font("Inter Medium", Font.BOLD, 25));
		fnamelbl.setBounds(217, 24, 147, 40);
		profilepanel.add(fnamelbl);
		
		JLabel designationlbl = new JLabel("Designation :");
		designationlbl.setFont(new Font("Inter Medium", Font.PLAIN, 12));
		designationlbl.setBounds(115, 67, 95, 23);
		profilepanel.add(designationlbl);
		
		 designationnamelbl = new JLabel("");
		 designationnamelbl.setFont(new Font("Inter Medium", Font.PLAIN, 13));
		designationnamelbl.setBounds(202, 67, 117, 23);
		profilepanel.add(designationnamelbl);
		
		JLabel colorpanel = new JLabel("");
		colorpanel.setIcon(dots);
		colorpanel.setBounds(115, 92, 20, 20);
		profilepanel.add(colorpanel);
		
		JLabel lblNewLabel_1 = new JLabel("online");
		lblNewLabel_1.setFont(new Font("Inter Medium", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(139, 92, 52, 20);
		profilepanel.add(lblNewLabel_1);
		
		
		JPanel overviewpanels = new JPanel();
		overviewpanels.addMouseListener(new PanelButtonMouseAdapter(overviewpanels) {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				menuClicked(overviewpanels);
				overviewpanel.setVisible(true);
				informationpanels.setVisible(false);
				payrollpanel.setVisible(false);
			}
		});
		overviewpanels.setBackground(new Color(255, 255, 255));
		overviewpanels.setBounds(10, 138, 100, 24);
		wholepanel.add(overviewpanels);
		overviewpanels.setLayout(null);
		
		JLabel overviewlbk = new JLabel("  Overview");
		overviewlbk.setBackground(new Color(0, 0, 0));
		overviewlbk.setFont(new Font("Inter Medium", Font.PLAIN, 15));
		overviewlbk.setBounds(10, 0, 80, 25);
		overviewpanels.add(overviewlbk);
		
		JPanel informationpanel = new JPanel();
		informationpanel.addMouseListener(new PanelButtonMouseAdapter(informationpanel) {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
				menuClicked(informationpanel);
				overviewpanel.setVisible(false);
				informationpanels.setVisible(true);
				payrollpanel.setVisible(false);
				performancepanel.setVisible(false);
				
			}
		});
		informationpanel.setBackground(new Color(255, 255, 255));
		informationpanel.setBounds(120, 138, 100, 24);  
		wholepanel.add(informationpanel);
		informationpanel.setLayout(null);
		
		JLabel lblInformation_1 = new JLabel("Information");
		lblInformation_1.setFont(new Font("Inter Medium", Font.PLAIN, 15));
		lblInformation_1.setBounds(10, 0, 90, 25);
		informationpanel.add(lblInformation_1);
		
		JPanel payrollpanels = new JPanel();
		payrollpanels.addMouseListener(new PanelButtonMouseAdapter(payrollpanels) {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				menuClicked(payrollpanels);
				overviewpanel.setVisible(false);
				informationpanels.setVisible(false);
				payrollpanel.setVisible(true);
				performancepanel.setVisible(false);
			}
		});
		payrollpanels.setBackground(new Color(255, 255, 255));
		payrollpanels.setBounds(232, 138, 100, 24);
		wholepanel.add(payrollpanels);
		payrollpanels.setLayout(null);
		
		JLabel lblInformation = new JLabel("Payroll");
		lblInformation.setFont(new Font("Inter Medium", Font.PLAIN, 15));
		lblInformation.setBounds(22, 0, 68, 25);
		payrollpanels.add(lblInformation);
		
		JPanel clockpanel = new JPanel();
		clockpanel.setBackground(new Color(255, 255, 255));
		clockpanel.setBorder(new LineBorder(new Color(192, 192, 192)));
		clockpanel.setBounds(10, 163, 915, 70);
		wholepanel.add(clockpanel);
		clockpanel.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Date :");
		lblNewLabel_2.setFont(new Font("Inter Medium", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(10, 21, 63, 29);
		clockpanel.add(lblNewLabel_2);
		
		JLabel realtimelbl = new JLabel("Time :");
		realtimelbl.setFont(new Font("Inter Medium", Font.PLAIN, 14));
		realtimelbl.setBounds(206, 21, 63, 29);
		clockpanel.add(realtimelbl);
		
		JLabel lblNewLabel_2_2 = new JLabel("Work Time :");
		lblNewLabel_2_2.setFont(new Font("Inter Medium", Font.PLAIN, 14));
		lblNewLabel_2_2.setBounds(418, 21, 90, 29);
		clockpanel.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_3 = new JLabel("Performance :");
		lblNewLabel_2_3.setFont(new Font("Inter Medium", Font.PLAIN, 14));
		lblNewLabel_2_3.setBounds(670, 21, 114, 29);
		clockpanel.add(lblNewLabel_2_3);

        realtime = new JLabel("");
        realtime.setFont(new Font("Inter Medium", Font.BOLD, 16));
        realtime.setBounds(251, 21, 100, 29); // Adjusted bounds to fit the time
        clockpanel.add(realtime);
        
        // Start the timer to update the time every second
        Timer timer = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                updateTime();
            }
        });
        timer.start();
        
        // to do
	    realtimelbls = new JLabel("");
		realtimelbls.setFont(new Font("Inter Medium", Font.BOLD, 16));
		Date currentDate = new Date();
		
		// Format Date component
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String CurrentDateFormatted = dateFormat.format(currentDate);
		
		realtimelbls.setText(CurrentDateFormatted);
		realtimelbls.setBounds(56, 20, 107, 29);
		clockpanel.add(realtimelbls);
		
		JLabel lblNewLabel_2_6 = new JLabel("9 am - 5 pm");
		lblNewLabel_2_6.setFont(new Font("Inter Medium", Font.BOLD, 16));
		lblNewLabel_2_6.setBounds(506, 20, 107, 29);
		clockpanel.add(lblNewLabel_2_6);
		
		JLabel performancesqllbl = new JLabel("");
		performancesqllbl.setFont(new Font("Inter Medium", Font.BOLD, 16));
		performancesqllbl.setBounds(767, 21, 90, 29);
		clockpanel.add(performancesqllbl);
		
		JPanel Performance = new JPanel();
		Performance.addMouseListener(new PanelButtonMouseAdapter(Performance) {
			@Override
			public void mouseClicked(MouseEvent e) {
				menuClicked(Performance);
				
				overviewpanel.setVisible(false);
				informationpanels.setVisible(false);
				payrollpanel.setVisible(false);
				performancepanel.setVisible(true);
				
				
				
			}
		});
		Performance.setLayout(null);
		Performance.setBackground(Color.WHITE);
		Performance.setBounds(340, 138, 100, 24);
		wholepanel.add(Performance);
		
		JLabel lblPerformance = new JLabel("Performance");
		lblPerformance.setFont(new Font("Inter Medium", Font.PLAIN, 15));
		lblPerformance.setBounds(0, 0, 100, 25);
		Performance.add(lblPerformance);
		
		RoundedJPanelProfile headPanel = new RoundedJPanelProfile();
		headPanel.setOpaque(false);
		headPanel.setBounds(0, 0, 935, 55);
		contentPane.add(headPanel);
		headPanel.setLayout(null);
		
		JPanel exitpanel = new JPanel();
		exitpanel.setOpaque(false);
		exitpanel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				 dispose();
		        
				
			}
		});
		exitpanel.setBounds(907, 11, 23, 22);
		headPanel.add(exitpanel);
		exitpanel.setLayout(null);
		
		JLabel exitlbl = new JLabel("");
		exitlbl.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
		         
				
			}
		});
		exitlbl.setIcon(exit);
		exitlbl.setBounds(0, 0, 29, 22);
		exitpanel.add(exitlbl);
		
		JLabel lblNewLabel = new JLabel("Manage Profile");
		lblNewLabel.setForeground(new Color(192, 192, 192));
		lblNewLabel.setFont(new Font("Inter Medium", Font.BOLD, 15));
		lblNewLabel.setBounds(376, 11, 206, 22);
		headPanel.add(lblNewLabel);
		
		loadProfileIcon();
        // Fetch data from the database and update labels
		fetchDataAndUpdateLabels("Charles", "Leclerc", "CyberSecurity", "IT Department", "Lcharles@yahoo.com", "METRO PACIFIC INVESTMENT", "0906210123");

	}
	// create new method for Jpanel Class
		public void menuClicked(JPanel selectedPanel) {
			overviewpanel.setVisible(false);
			informationpanels.setVisible(false);
			payrollpanel.setVisible(false);
			performancepanel.setVisible(false);
			selectedPanel.setVisible(true);
			// set the selected panel to the variable
			this.selectedPanel = selectedPanel;
		} 
		 
	// method for real time 
	private void updateTime() {
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
	    String currentTime = LocalTime.now().format(formatter);  
	    realtime.setText(currentTime);
	}
	 // method for retrive image from sql
    private void loadProfileIcon() {

        try {
            // Load the JDBC driver class
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            // Define the JDBC URL
            String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";

            // Establish the database connection
            try (Connection connection = DriverManager.getConnection(url)) {
                // Prepare the SQL statement
                String sql = "SELECT e_profile FROM Employee WHERE e_id = ?;";
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setInt(1, 1); // Assuming the ID of the image you want to retrieve is 1

                    // Execute the query
                    try (ResultSet resultSet = statement.executeQuery()) {
                        if (resultSet.next()) { 
                            // Retrieve the image data from the result set
                            byte[] imageData = resultSet.getBytes("e_profile");

                            if (imageData != null && imageData.length > 0) { // Check if image data is not null or empty
                                // Convert the byte array to a BufferedImage
                                try (ByteArrayInputStream bis = new ByteArrayInputStream(imageData)) {
                                    BufferedImage bufferedImage = ImageIO.read(bis);

                                    if (bufferedImage != null) { // Check if BufferedImage was successfully created
                                        // Resize the image to fit the JLabel
                                        Image scaledImage = bufferedImage.getScaledInstance(profilelbl.getWidth(), profilelbl.getHeight(), Image.SCALE_SMOOTH);

                                        // Set the scaled image to the JLabel
                                        profilelbl.setIcon(new ImageIcon(scaledImage));
                                        System.out.println("Image data retrieved from the databas");
                                    } else {
                                        System.out.println("Failed to read image data from the database.");
                                    }
                                }
                            } else {
                                System.out.println("Image data retrieved from the database is null or empty.");
                            }
                        } else {
                            System.out.println("No image data found for the specified employee ID.");
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
 // method for displaying SQL data in labels
    private void fetchDataAndUpdateLabels(String e_fname, String e_lname, String e_designaiton, String e_department, String e_emailaddress, String e_company, String c_contact) {
        try {
            String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
            Connection conn = DriverManager.getConnection(url);

            // use a prepared Statement to avoid SQL injection
            String query = "SELECT * FROM Employee JOIN Credentials ON Employee.e_id = Credentials.c_id WHERE Employee.e_fname = ?  AND Employee.e_lname = ? AND Employee.e_designation = ?  AND Employee.e_department = ?  AND Employee.e_emailaddress = ?  AND Employee.e_company = ? AND Credentials.c_contact = ?;";
            try (PreparedStatement pstmt = conn.prepareStatement(query)) { 
                // Set the parameters using the provided values
                pstmt.setString(1, "Charles"); // Set the first parameter (e_fname)
                pstmt.setString(2, "Leclerc"); // Set the second parameter (e_lname)
                pstmt.setString(3, "CyberSecurity"); // Set the second parameter (designation);
                pstmt.setString(4, "IT Department");
                pstmt.setString(5,"Lcharles@yahoo.com");
                pstmt.setString(6,"METRO PACIFIC INVESMENT");
                pstmt.setString(7,"0906210123");
                					
                ResultSet result = pstmt.executeQuery(); 
                if (result.next()) { 
                    // update label with data from result set
                    fnamelbl.setText(result.getString("e_fname"));
                    lnamelbl.setText(result.getString("e_lname"));
                    designationnamelbl.setText(result.getString("e_designation"));

                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception properly
        }
    }
    
    private class PanelButtonMouseAdapter extends MouseAdapter{
		JPanel panel;
		 
		public PanelButtonMouseAdapter(JPanel panel) { 
			this.panel = panel;
		}
		
		public void mouseEntered(MouseEvent e) {
			panel.setBackground(new Color(195, 195, 195));
		}
		
		
		public void mouseExited(MouseEvent e) {
			panel.setBackground(new Color(255, 255, 255));
		}
		
		public void mousePressed(MouseEvent e) {
			panel.setBackground(new Color(195, 195, 195));
		}
		
		public void mouseReleased(MouseEvent e) {
			panel.setBackground(new Color(195, 195, 195));
		}
	}
}
