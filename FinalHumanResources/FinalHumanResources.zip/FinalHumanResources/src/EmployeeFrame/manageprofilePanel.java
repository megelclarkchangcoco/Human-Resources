package EmployeeFrame;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.JLabel;
import java.awt.Font;

public class manageprofilePanel extends JPanel {

	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	public manageprofilePanel() {
		  setBorder(new MatteBorder(0, 0, 2, 2, new Color(41, 75, 141)));
	        setBackground(Color.WHITE); 
	        setLayout(null);
	        setVisible(false);
	        setBounds(74, 51, 1191, 752);
	        
	        // Create the body panel to hold the scroll pane
	        JPanel bodyPanel = new JPanel();
	        bodyPanel.setBorder(new LineBorder(new Color(41, 75, 141), 2));
	        bodyPanel.setBounds(0, 0, 1191, 752); // Adjusted the size to fit within the bounds of TablePanel
	        add(bodyPanel);
	        bodyPanel.setLayout(null);   
	        
	        // Create the scroll pane and set its bounds
	        JScrollPane scrollPane = new JScrollPane();
	        scrollPane.setBounds(0, 0, 1191, 752); // Adjusted the size to fit within the bounds of bodyPanel
	        bodyPanel.add(scrollPane);
	        
	        // Create the panel to hold the content to be scrolledv
	        JPanel scrollContent = new JPanel();
	        scrollContent.setBackground(Color.WHITE);
	        scrollContent.setLayout(null);
	        scrollContent.setPreferredSize(new Dimension(1000, 800)); // Set a preferred size for scrolling
	        scrollPane.setViewportView(scrollContent);
	        
	        JPanel headpanel = new JPanel();
	        headpanel.setBackground(new Color(41, 75, 141));
	        headpanel.setBounds(0, 0, 1172, 54);
	        scrollContent.add(headpanel);
	        headpanel.setLayout(null);
	        
	        JLabel lblNewLabel = new JLabel("Manage Profile");
	        lblNewLabel.setBounds(458, 11, 298, 38);
	        lblNewLabel.setForeground(Color.LIGHT_GRAY);
	        lblNewLabel.setFont(new Font("Inter Medium", Font.BOLD, 25));
	        headpanel.add(lblNewLabel);
	         
	        JPanel bodypanel = new JPanel();
	        bodypanel.setBackground(new Color(255, 255, 255));
	        bodypanel.setBounds(0, 52, 1172, 657);
	        scrollContent.add(bodypanel);
	        bodypanel.setLayout(null);
	        
	        JLabel profilelbl = new JLabel("");
	        profilelbl.setBounds(10, 11, 156, 135);
	        bodypanel.add(profilelbl);
	        
	        // Adjust the preferred size of the scroll pane
	        scrollPane.setPreferredSize(new Dimension(1181, 752));
	}
}
