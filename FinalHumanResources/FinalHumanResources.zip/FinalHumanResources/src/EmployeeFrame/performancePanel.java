package EmployeeFrame;

import java.awt.Color;
import java.awt.Dimension;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;

import javax.swing.JTextPane;
import javax.imageio.ImageIO;
import javax.swing.DropMode;
import javax.swing.ImageIcon;
import javax.swing.border.MatteBorder;

public class performancePanel extends JPanel {

    private static final long serialVersionUID = 1L;
    private JTextPane areaofimprovementstextpane;
    private JTextPane feedbacktextpane;
    private JLabel achivementpicture;

    /**
     * Create the panel.
     */
    public performancePanel() {
        setBackground(Color.WHITE);
        setBounds(10, 248, 915, 270);
        setVisible(false);
        setLayout(null);
        setOpaque(false);

        JPanel bodyPanel = new JPanel();
        bodyPanel.setBounds(0, 0, 918, 321);
        add(bodyPanel);
        bodyPanel.setLayout(null);

        // Create the scroll pane and set its bounds
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(0, 0, 918, 287); // Adjusted the size to fit within the bounds of bodyPanel
        bodyPanel.add(scrollPane);

        // Create the panel to hold the content to be scrolled
        JPanel scrollContent = new JPanel();
        scrollContent.setBackground(new Color(255, 255, 255));
        scrollContent.setPreferredSize(new Dimension(915, 440)); // Set a preferred size for scrolling
        scrollPane.setViewportView(scrollContent);
        scrollContent.setLayout(null);

        JPanel panel = new JPanel();
        panel.setBorder(new MatteBorder(0, 0, 1, 0, (Color) new Color(0, 0, 0)));
        panel.setBackground(new Color(255, 255, 255));
        panel.setBounds(0, 0, 905, 215);
        scrollContent.add(panel);
        panel.setLayout(null);

        JLabel lblNewLabel = new JLabel("Achievements");
        lblNewLabel.setFont(new Font("Inter Medium", Font.BOLD, 16));
        lblNewLabel.setBounds(10, 11, 134, 31);
        panel.add(lblNewLabel); 

         achivementpicture = new JLabel("");
        achivementpicture.setBounds(43, 54, 215, 127);
        panel.add(achivementpicture);

        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(255, 255, 255));
        panel_1.setBounds(0, 214, 904, 227);
        scrollContent.add(panel_1);
        panel_1.setLayout(null);

        JLabel lblAreaOf = new JLabel("Area of Improvements");
        lblAreaOf.setBounds(10, 11, 254, 31);
        lblAreaOf.setFont(new Font("Inter Medium", Font.BOLD, 16));
        panel_1.add(lblAreaOf);

        JLabel lblFeedback = new JLabel("Feedback");
        lblFeedback.setBounds(10, 118, 254, 31);
        lblFeedback.setFont(new Font("Inter Medium", Font.BOLD, 16));
        panel_1.add(lblFeedback);

         areaofimprovementstextpane = new JTextPane();
        areaofimprovementstextpane.setBounds(10, 41, 254, 78);
        areaofimprovementstextpane.setDropMode(DropMode.INSERT);
        areaofimprovementstextpane.setEditable(false); // make it non-editable
        panel_1.add(areaofimprovementstextpane);

         feedbacktextpane = new JTextPane();
        feedbacktextpane.setDropMode(DropMode.INSERT);
        feedbacktextpane.setBounds(10, 149, 254, 78);
        feedbacktextpane.setEditable(false); // make it non-editable
        panel_1.add(feedbacktextpane);
        
        fetchdata();
        loadAchivementsIcon();

    }
    // fetch data in jtextpane
    private void fetchdata() {
    // Fetch data from SQL table and set it in JTextPanes
    try {
    	String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";

        Connection conn = DriverManager.getConnection(url);
        String query = "SELECT Areas_of_improvements, Feedback FROM Performance";
        PreparedStatement statement = conn.prepareStatement(query);
        ResultSet resultSet = statement.executeQuery();

        if (resultSet.next()) {
            areaofimprovementstextpane.setText(resultSet.getString("Areas_of_improvements"));
            feedbacktextpane.setText(resultSet.getString("Feedback"));
        }

        conn.close();
    } catch (SQLException e) {
        e.printStackTrace();
     }
    }
    
    private void loadAchivementsIcon() {
    	 // Load the JDBC driver class
        try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			
			 // Define the JDBC URL
	        String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
	        
	        // Establish the database connection
	        try (Connection connection = DriverManager.getConnection(url)){
	        	// Prepare the sql Statement
	        	String query = "SELECT Achievements FROM Performance WHERE performance_id = ?";
	        	try(PreparedStatement statement = connection.prepareStatement(query)){
	        		statement.setInt(1,1);
	        		
	        		// Excuse the query
	        		try(ResultSet resultSet = statement.executeQuery()){
	        			if(resultSet.next()) {
	        				// Retrieve the image data frp, the result set
	        				byte[] imageData = resultSet.getBytes("Achievements");
	        				
	        				if(imageData != null && imageData.length > 0){// Check if image data is not null or empty
	        					// convert the byte array to a bufferedImage
	        					try(ByteArrayInputStream bis = new ByteArrayInputStream(imageData)){
	        						BufferedImage bufferedImage = ImageIO.read(bis);
	        						
	        						if(bufferedImage != null) {// check if bufferedImage was successfully created
	        							// Resize the image to fit the JLabel
                                        Image scaledImage = bufferedImage.getScaledInstance(achivementpicture.getWidth(), achivementpicture.getHeight(), Image.SCALE_SMOOTH);
	        						
                                        // set the scaled image to the jlabel
                                        achivementpicture.setIcon(new ImageIcon(scaledImage));
                                        
	        						}else {
                                        System.out.println("Failed to read image data from the database.");

	        						}
	        					}
	        				} else {
                                System.out.println("Image data retrieved from the database is null or empty.");
	        				}
	        			}else {
                            System.out.println("No image data found for the specified employee ID.");
	        			}
	        		}
	        	}
	        }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

       
    }
}
