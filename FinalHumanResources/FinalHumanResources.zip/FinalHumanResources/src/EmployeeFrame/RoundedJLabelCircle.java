package EmployeeFrame;

import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;

public class RoundedJLabelCircle extends JLabel {
    private Shape shape;

    public RoundedJLabelCircle(String text) {
        super(text);
        setOpaque(true);
        setBackground(new Color(255, 255, 255));
    }


    @Override
    protected void paintComponent(Graphics g) {
        g.setColor(getBackground());
        int diameter = Math.min(getWidth(), getHeight());
        g.fillOval((getWidth() - diameter) / 2, (getHeight() - diameter) / 2, diameter, diameter);
        super.paintComponent(g);
    }

    @Override
    protected void paintBorder(Graphics g) {
        g.setColor(getForeground());
        int diameter = Math.min(getWidth(), getHeight());
        g.drawOval((getWidth() - diameter) / 2, (getHeight() - diameter) / 2, diameter, diameter);
    }

    @Override
    public boolean contains(int x, int y) {
        if (shape == null || !shape.getBounds().equals(getBounds())) {
            int diameter = Math.min(getWidth(), getHeight());
            shape = new Ellipse2D.Float((getWidth() - diameter) / 2, (getHeight() - diameter) / 2, diameter, diameter);
        }
        return shape.contains(x, y);
    }
}
