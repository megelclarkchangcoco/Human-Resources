package EmployeeFrame;

import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFileChooser;

public class workPanel extends JPanel {
	
	private ImageIcon sql1 = new ImageIcon
			(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\workpanelicon\\sql2.png")
			.getImage().getScaledInstance(77, 68, Image.SCALE_DEFAULT));
	private ImageIcon bugs = new ImageIcon
			(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\workpanelicon\\bug.png")
			.getImage().getScaledInstance(77, 68, Image.SCALE_DEFAULT));
	private ImageIcon turnover = new ImageIcon
			(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\workpanelicon\\turnoberf.png")
			.getImage().getScaledInstance(77, 68, Image.SCALE_DEFAULT));
	private static final long serialVersionUID = 1L;
	
	private JPanel oneworkPanel;
	private JPanel turninPanel;
	private JLabel pic2;
	private JLabel notes1lbl;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel instructionlbl;
	private JLabel instruction1;
	private JLabel lblCreateHuman;
	private JLabel lblConnectYour;
	private JLabel lblConnectYour_1;
	private JLabel lblGoodluck;
	private JLabel attatchlbl;
	private JLabel attatchlbl_1;
    private int labelCounter = 0;
    private JPanel twoworkpanel;
    private JPanel turninpanel2;
    private JLabel lblNewLabel_3;
    private JLabel pic3;
    private JLabel notes1lbl_1;
    private JLabel lblNewLabel_4;
    private JLabel lblNewLabel_5;
    private JLabel instructionlbl_1;
    private JLabel instruction1_1;
    private JLabel lblCreateHuman_1;
    private JLabel lblConnectYour_2;
    private JLabel lblGoodluck_1;
    private JLabel attatchlbl_2;
    private JLabel attatchlbl_3;
    private JButton attatchbutton_1;
    private JButton btnRemove_1;
    private JPanel threeworkpanel;
    private JPanel turninpanel3;
    private JLabel lblNewLabel_6;
    private JLabel pic4;
    private JLabel notes1lbl_2;
    private JLabel lblNewLabel_7;
    private JLabel lblNewLabel_8;
    private JLabel instructionlbl_2;
    private JLabel instruction1_2;
    private JLabel lblCreateHuman_2;
    private JLabel lblConnectYour_3;
    private JLabel lblGoodluck_2;
    private JLabel attatchlbl_4;
    private JLabel attatchlbl_5;
    private JButton attatchbutton_2;
    private JButton btnRemove_2;
	
	/**
	 * Create the panel.
	 */
	public workPanel() {
		setBorder(new MatteBorder(0, 0, 2, 2, (Color) new Color(41, 75, 141)));
		setBackground(new Color(255, 255, 255));
		setLayout(null); 
		setBounds(74, 51, 1191, 752);  
		setVisible(false);
		
		oneworkPanel = new JPanel();	
		oneworkPanel.setBorder(new LineBorder(new Color(41, 71, 141)));
		oneworkPanel.setForeground(new Color(41, 71, 141));
		oneworkPanel.setBackground(new Color(255, 255, 255));
		oneworkPanel.setBounds(54, 46, 858, 93);
		oneworkPanel.addMouseListener(new PanelButtonMouseAdapter(oneworkPanel) {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (oneworkPanel.getHeight() == 93) {
                    oneworkPanel.setSize(new Dimension(858, 364));
                } else {
                    oneworkPanel.setSize(new Dimension(858, 93));
                }
            }
        }); 
		add(oneworkPanel);
		oneworkPanel.setLayout(null);
		
		turninPanel = new RoundedJPanel();
		turninPanel.setBackground(new Color(41, 71, 141));
		turninPanel.setBounds(742, 23, 106, 32);
		turninPanel.setOpaque(false);
		oneworkPanel.add(turninPanel);
		turninPanel.setLayout(null);
		 
		JLabel lblNewLabel = new JLabel("Turn in");
		lblNewLabel.setFont(new Font("Inter Medium", Font.BOLD, 16));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBounds(21, 11, 75, 14);
		turninPanel.add(lblNewLabel);
		
		pic2 = new JLabel("");
		pic2.setIcon(sql1);
		pic2.setBounds(48, 11, 77, 68);
		oneworkPanel.add(pic2);
		
		notes1lbl = new JLabel("Create Human Resources System with SQL ");
		notes1lbl.setFont(new Font("Inter Medium", Font.BOLD, 12));
		notes1lbl.setBounds(146, 23, 312, 32);
		oneworkPanel.add(notes1lbl);
		
		lblNewLabel_1 = new JLabel("March 5 2024");
		lblNewLabel_1.setFont(new Font("Inter Medium", Font.PLAIN, 12));
		lblNewLabel_1.setForeground(new Color(190, 190, 190));
		lblNewLabel_1.setBounds(146, 52, 128, 13);
		oneworkPanel.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("Work");
		lblNewLabel_2.setFont(new Font("Inter Medium", Font.PLAIN, 12));
		lblNewLabel_2.setForeground(new Color(190, 190, 190));
		lblNewLabel_2.setBounds(146, 66, 128, 13);
		oneworkPanel.add(lblNewLabel_2);
		
		instructionlbl = new JLabel("instruction");
		instructionlbl.setFont(new Font("Inter Medium", Font.BOLD, 12));
		instructionlbl.setBounds(24, 95, 77, 14);
		oneworkPanel.add(instructionlbl);
		
		instruction1 = new JLabel("1. create human resources erd");
		instruction1.setFont(new Font("Inter Medium", Font.PLAIN, 12));
		instruction1.setBounds(34, 116, 270, 14);
		oneworkPanel.add(instruction1);
		
		lblCreateHuman = new JLabel("2. Create Human Resources System");
		lblCreateHuman.setBounds(34, 131, 270, 14);
		oneworkPanel.add(lblCreateHuman);
		
		lblConnectYour = new JLabel("3. Connect your System to SQL Server");
		lblConnectYour.setFont(new Font("Inter Medium", Font.PLAIN, 12));
		lblConnectYour.setBounds(34, 146, 270, 14);
		oneworkPanel.add(lblConnectYour);
		
		lblConnectYour_1 = new JLabel("4. choose pair ");
		lblConnectYour_1.setFont(new Font("Inter Medium", Font.PLAIN, 12));
		lblConnectYour_1.setBounds(34, 163, 270, 14);
		oneworkPanel.add(lblConnectYour_1);
		
		lblGoodluck = new JLabel("Goodluck!");
		lblGoodluck.setFont(new Font("Inter Medium", Font.BOLD, 12));
		lblGoodluck.setBounds(24, 188, 77, 14);
		oneworkPanel.add(lblGoodluck);
		
		attatchlbl = new JLabel("");
		attatchlbl.setBounds(34, 231, 217, 14);
		oneworkPanel.add(attatchlbl);
		
		attatchlbl_1 = new JLabel("");
		attatchlbl_1.setBounds(34, 256, 217, 14);
		oneworkPanel.add(attatchlbl_1);
		
		JButton attatchbutton = new JButton("Attach");
		attatchbutton.setForeground(new Color(41, 71, 141));
		attatchbutton.setBounds(24, 317, 89, 23);
		attatchbutton.addActionListener((ActionListener) new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int returnValue = fileChooser.showOpenDialog(null);
                if (returnValue == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    if (labelCounter == 0) {
                        attatchlbl.setText(selectedFile.getName());
                        labelCounter++;
                    } else if (labelCounter == 1) {
                        attatchlbl_1.setText(selectedFile.getName());
                        labelCounter++;
                    } else {
                        JOptionPane.showMessageDialog(null, "Only two attachments allowed.");
                    }
                }
            }
        });
		oneworkPanel.add(attatchbutton);
		
		JButton btnRemove = new JButton("Remove");
		btnRemove.setForeground(new Color(41, 71, 141));
		btnRemove.setBounds(119, 317, 89, 23);
		btnRemove.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (labelCounter == 1) {
                    attatchlbl.setText("");
                    labelCounter--;
                } else if (labelCounter == 2) {
                    attatchlbl_1.setText("");
                    labelCounter--;
                }
            }
        });
		oneworkPanel.add(btnRemove);
		
		twoworkpanel = new JPanel();
		twoworkpanel.addMouseListener(new PanelButtonMouseAdapter(twoworkpanel) {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        if (twoworkpanel.getHeight() == 93) {
		            twoworkpanel.setBounds(54, 184, 858, 359);
		        } else {
		            twoworkpanel.setBounds(54, 184, 858, 93);
		        }
		    }
		});
		twoworkpanel.setLayout(null);
		twoworkpanel.setForeground(new Color(41, 71, 141));
		twoworkpanel.setBorder(new LineBorder(new Color(41, 71, 141)));
		twoworkpanel.setBackground(Color.WHITE);
		twoworkpanel.setBounds(54, 184, 858, 93);
		add(twoworkpanel);


		
		turninpanel2 = new RoundedJPanel();
		turninpanel2.setLayout(null);
		turninpanel2.setOpaque(false);
		turninpanel2.setBackground(new Color(41, 71, 141));
		turninpanel2.setBounds(742, 23, 106, 32);
		twoworkpanel.add(turninpanel2);
		
		lblNewLabel_3 = new JLabel("Turn in");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_3.setBounds(21, 11, 75, 14);
		turninpanel2.add(lblNewLabel_3);
		
		pic3 = new JLabel("");
		pic3.setIcon(bugs);
		pic3.setBounds(48, 11, 77, 68);
		twoworkpanel.add(pic3);
		
		notes1lbl_1 = new JLabel("Fix Bug");
		notes1lbl_1.setFont(new Font("Inter Medium", Font.BOLD, 12));
		notes1lbl_1.setBounds(146, 23, 312, 32);
		twoworkpanel.add(notes1lbl_1);
		
		lblNewLabel_4 = new JLabel("March 10 2024");
		lblNewLabel_4.setFont(new Font("Inter Medium", Font.PLAIN, 12));
		lblNewLabel_4.setForeground(new Color(190, 190, 190));
		lblNewLabel_4.setBounds(146, 52, 128, 13);
		twoworkpanel.add(lblNewLabel_4);
		
		lblNewLabel_5 = new JLabel("work");
		lblNewLabel_5.setFont(new Font("Inter Medium", Font.PLAIN, 12));
		lblNewLabel_5.setForeground(new Color(190, 190, 190));
		lblNewLabel_5.setBounds(146, 66, 128, 13);
		twoworkpanel.add(lblNewLabel_5);
		
		instructionlbl_1 = new JLabel("instruction");
		instructionlbl_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		instructionlbl_1.setBounds(24, 95, 77, 14);
		twoworkpanel.add(instructionlbl_1);
		
		instruction1_1 = new JLabel("fix the database server");
		instruction1_1.setFont(new Font("Inter Medium", Font.PLAIN, 12));
		instruction1_1.setBounds(34, 116, 270, 14);
		twoworkpanel.add(instruction1_1);
		
		lblCreateHuman_1 = new JLabel("create new server for our new\r\n");
		lblCreateHuman_1.setFont(new Font("Inter Medium", Font.PLAIN, 12));
		lblCreateHuman_1.setBounds(34, 131, 270, 14);
		twoworkpanel.add(lblCreateHuman_1);
		
		lblConnectYour_2 = new JLabel("System and use php for this system");
		lblConnectYour_2.setFont(new Font("Inter Medium", Font.PLAIN, 12));
		lblConnectYour_2.setBounds(34, 146, 270, 14);
		twoworkpanel.add(lblConnectYour_2);
		
		lblGoodluck_1 = new JLabel("Goodluck!");
		lblGoodluck_1.setFont(new Font("Inter Medium", Font.BOLD, 12));
		lblGoodluck_1.setBounds(24, 188, 77, 14);
		twoworkpanel.add(lblGoodluck_1);
		
		attatchlbl_2 = new JLabel("");
		attatchlbl_2.setBounds(34, 231, 217, 14);
		twoworkpanel.add(attatchlbl_2);
		
		attatchlbl_3 = new JLabel("");
		attatchlbl_3.setBounds(34, 256, 217, 14);
		twoworkpanel.add(attatchlbl_3);
		
		attatchbutton_1 = new JButton("Attach");
		attatchbutton_1.setForeground(new Color(41, 71, 141));
		attatchbutton_1.setBounds(24, 317, 89, 23);
		twoworkpanel.add(attatchbutton_1);
		
		btnRemove_1 = new JButton("Remove");
		btnRemove_1.setForeground(new Color(41, 71, 141));
		btnRemove_1.setBounds(119, 317, 89, 23);
		twoworkpanel.add(btnRemove_1);
		
		threeworkpanel = new JPanel();
		threeworkpanel.addMouseListener(new PanelButtonMouseAdapter(threeworkpanel) {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        if (threeworkpanel.getHeight() == 93) {
		        	threeworkpanel.setBounds(54, 326, 858, 352);
		        } else {
		        	threeworkpanel.setBounds(54, 326, 858, 93);
		        }
		    }
		});
		threeworkpanel.setLayout(null);
		threeworkpanel.setForeground(new Color(41, 71, 141));
		threeworkpanel.setBorder(new LineBorder(new Color(41, 71, 141)));
		threeworkpanel.setBackground(Color.WHITE);
		threeworkpanel.setBounds(54, 326, 858, 93);
		add(threeworkpanel);

		
		turninpanel3 = new RoundedJPanel();
		turninpanel3.setLayout(null);
		turninpanel3.setOpaque(false);
		turninpanel3.setBackground(new Color(41, 71, 141));
		turninpanel3.setBounds(742, 23, 106, 32);
		threeworkpanel.add(turninpanel3);
		
		lblNewLabel_6 = new JLabel("Turn in");
		lblNewLabel_6.setForeground(Color.WHITE);
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_6.setBounds(21, 11, 75, 14);
		turninpanel3.add(lblNewLabel_6);
		
		pic4 = new JLabel("");
		pic4.setIcon(turnover);
		pic4.setBounds(48, 11, 77, 68);
		threeworkpanel.add(pic4);
		
		notes1lbl_2 = new JLabel("Turn Over");
		notes1lbl_2.setFont(new Font("Inter Medium", Font.BOLD, 14));
		notes1lbl_2.setBounds(146, 23, 312, 32);
		threeworkpanel.add(notes1lbl_2);
		
		lblNewLabel_7 = new JLabel("March 15 2024");
		lblNewLabel_7.setFont(new Font("Inter Medium", Font.PLAIN, 11));
		lblNewLabel_7.setForeground(new Color(190, 190, 190));
		lblNewLabel_7.setBounds(146, 52, 128, 13);
		threeworkpanel.add(lblNewLabel_7);
		
		lblNewLabel_8 = new JLabel("work");
		lblNewLabel_8.setFont(new Font("Inter Medium", Font.PLAIN, 11));
		lblNewLabel_8.setForeground(new Color(190, 190, 190));
		lblNewLabel_8.setBounds(146, 66, 128, 13);
		threeworkpanel.add(lblNewLabel_8);
		
		instructionlbl_2 = new JLabel("instruction");
		instructionlbl_2.setFont(new Font("Inter Medium", Font.BOLD, 11));
		instructionlbl_2.setBounds(24, 95, 77, 14);
		threeworkpanel.add(instructionlbl_2);
		
		instruction1_2 = new JLabel("turnover your all file for this new system\r\n");
		instruction1_2.setFont(new Font("Inter Medium", Font.PLAIN, 11));
		instruction1_2.setBounds(34, 116, 270, 14);
		threeworkpanel.add(instruction1_2);
		
		lblCreateHuman_2 = new JLabel("and report all your work progress on your system\r\n");
		lblCreateHuman_2.setFont(new Font("Inter Medium", Font.PLAIN, 11));
		lblCreateHuman_2.setBounds(34, 131, 270, 14);
		threeworkpanel.add(lblCreateHuman_2);
		
		lblConnectYour_3 = new JLabel("and present your new system in your team leader");
		lblConnectYour_3.setFont(new Font("Inter Medium", Font.PLAIN, 11));
		lblConnectYour_3.setBounds(34, 146, 270, 14);
		threeworkpanel.add(lblConnectYour_3);
		
		lblGoodluck_2 = new JLabel("Goodluck!");
		lblGoodluck_2.setFont(new Font("Inter Medium", Font.BOLD, 11));
		lblGoodluck_2.setBounds(24, 188, 77, 14);
		threeworkpanel.add(lblGoodluck_2);
		
		attatchlbl_4 = new JLabel("");
		attatchlbl_4.setBounds(34, 231, 217, 14);
		threeworkpanel.add(attatchlbl_4);
		
		attatchlbl_5 = new JLabel("");
		attatchlbl_5.setBounds(34, 256, 217, 14);
		threeworkpanel.add(attatchlbl_5);
		
		attatchbutton_2 = new JButton("Attach");
		attatchbutton_2.setForeground(new Color(41, 71, 141));
		attatchbutton_2.setBounds(24, 317, 89, 23);
		threeworkpanel.add(attatchbutton_2);
		
		btnRemove_2 = new JButton("Remove");
		btnRemove_2.setForeground(new Color(41, 71, 141));
		btnRemove_2.setBounds(119, 317, 89, 23);
		threeworkpanel.add(btnRemove_2);

	}
	
	private class PanelButtonMouseAdapter extends MouseAdapter{
		JPanel panel;
		
		public PanelButtonMouseAdapter(JPanel panel) {
			this.panel = panel;
		}
		
		public void mouseEntered(MouseEvent e) {
			panel.setBackground(new Color(195, 195, 195));
		}
		
		public void mouseExited(MouseEvent e) {
			panel.setBackground(new Color(255, 255, 255));
		}
		
		public void mousePressed(MouseEvent e) {
			panel.setBackground(new Color(195, 195, 195));
		}
		
		public void mouseReleased(MouseEvent e) {
			panel.setBackground(new Color(195, 195, 195));
		}
	}
}
