package EmployeeFrame;

import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.MatteBorder;
import javax.swing.border.LineBorder;
import javax.swing.JTextField;

public class overviewPanel extends JPanel {

	private static final long serialVersionUID = 1L;
    private JTextField emailfield;
    private JTextField companyfield;
    private JTextField chatfield;
    private JTextField jobtitlefield;
    private JTextField workcontactfield;
    private JTextField departmentfield;

	/**
	 * Create the panel. 
	 */
	public overviewPanel() {
		setBackground(Color.WHITE); 		
		setBounds(10, 244, 918, 287);
		setLayout(null);
	      	
		JPanel bodypanel = new JPanel();
		bodypanel.setBorder(new LineBorder(new Color(192, 192, 192)));
		bodypanel.setBackground(new Color(255, 255, 255));
		bodypanel.setBounds(0, 0, 918, 287); 
		add(bodypanel);
		bodypanel.setLayout(null);
		
		JLabel contactinformationlbl = new JLabel("Contact Information");
		contactinformationlbl.setFont(new Font("Inter Medium", Font.PLAIN, 16));
		contactinformationlbl.setBounds(10, 11, 207, 29);
		bodypanel.add(contactinformationlbl);
		
		JLabel lblNewLabel_2_1 = new JLabel("Email :");
		lblNewLabel_2_1.setFont(new Font("Inter Medium", Font.PLAIN, 14));
		lblNewLabel_2_1.setBounds(10, 51, 63, 29);
		bodypanel.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("Company : ");
		lblNewLabel_2_1_1.setFont(new Font("Inter Medium", Font.PLAIN, 14));
		lblNewLabel_2_1_1.setBounds(10, 114, 84, 29);
		bodypanel.add(lblNewLabel_2_1_1);
		
		JLabel lblNewLabel_2_1_2 = new JLabel("Chat :");
		lblNewLabel_2_1_2.setFont(new Font("Inter Medium", Font.PLAIN, 14));
		lblNewLabel_2_1_2.setBounds(340, 51, 63, 29);
		bodypanel.add(lblNewLabel_2_1_2);
		
		JLabel lblNewLabel_2_1_3 = new JLabel("Job Title :");
		lblNewLabel_2_1_3.setFont(new Font("Inter Medium", Font.PLAIN, 14));
		lblNewLabel_2_1_3.setBounds(340, 114, 84, 29);
		bodypanel.add(lblNewLabel_2_1_3);
		
		JLabel lblNewLabel_2_1_4 = new JLabel("Work Contact :");
		lblNewLabel_2_1_4.setFont(new Font("Inter Medium", Font.PLAIN, 14));
		lblNewLabel_2_1_4.setBounds(619, 51, 107, 29);
		bodypanel.add(lblNewLabel_2_1_4);
		
		JLabel lblNewLabel_2_1_5 = new JLabel("Department :"); 
		lblNewLabel_2_1_5.setFont(new Font("Inter Medium", Font.PLAIN, 14));
		lblNewLabel_2_1_5.setBounds(619, 114, 107, 29);
		bodypanel.add(lblNewLabel_2_1_5);
		
		emailfield = new JTextField();
		emailfield.setBackground(new Color(255, 255, 255));
		emailfield.setEditable(false);
		emailfield.setFont(new Font("Inter Medium", Font.PLAIN, 16));
		emailfield.setBounds(83, 51, 244, 29);
		bodypanel.add(emailfield);
		emailfield.setColumns(10);
		
		companyfield = new JTextField();
		companyfield.setBackground(new Color(255, 255, 255));
		companyfield.setEditable(false);
		companyfield.setFont(new Font("Inter Medium", Font.PLAIN, 16));
		companyfield.setBounds(83, 115, 244, 29);
		bodypanel.add(companyfield); 
		companyfield.setColumns(10);
		
		chatfield = new JTextField();
		chatfield.setBackground(new Color(255, 255, 255));
		chatfield.setEditable(false);
		chatfield.setFont(new Font("Inter Medium", Font.PLAIN, 16));
		chatfield.setColumns(10);
		chatfield.setBounds(409, 51, 185, 29);
		bodypanel.add(chatfield);
		
		jobtitlefield = new JTextField();
		jobtitlefield.setBackground(new Color(255, 255, 255));
		jobtitlefield.setEditable(false);
		jobtitlefield.setFont(new Font("Inter Medium", Font.PLAIN, 16));
		jobtitlefield.setColumns(10);
		jobtitlefield.setBounds(409, 114, 185, 29);
		bodypanel.add(jobtitlefield);
		
		workcontactfield = new JTextField();
		workcontactfield.setBackground(new Color(255, 255, 255));
		workcontactfield.setEditable(false);
		workcontactfield.setFont(new Font("Inter Medium", Font.PLAIN, 16));
		workcontactfield.setColumns(10);
		workcontactfield.setBounds(724, 51, 185, 29);
		bodypanel.add(workcontactfield);
		 
		departmentfield = new JTextField();
		departmentfield.setBackground(new Color(255, 255, 255));
		departmentfield.setEditable(false);
		departmentfield.setFont(new Font("Inter Medium", Font.PLAIN, 16));
		departmentfield.setColumns(10);
		departmentfield.setBounds(724, 119, 185, 29);
		bodypanel.add(departmentfield);
		 
		// Fetch data from the database and update labels
		fetchDataAndUpdateLabels("Charles", "Leclerc", "CyberSecurity", "IT Department", "Lcharles@yahoo.com", "METRO PACIFIC INVESTMENT", "0906210123");
	}
	// method for displaying SQL data in labels
    private void fetchDataAndUpdateLabels(String e_fname, String e_lname, String e_designaiton, String e_department, String e_emailaddress, String e_company, String c_contact) {
        try {
            String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
            Connection conn = DriverManager.getConnection(url);

            // use a prepared Statement to avoid SQL injection
            String query = "SELECT * FROM Employee JOIN Credentials ON Employee.e_id = Credentials.c_id WHERE Employee.e_fname = ?  AND Employee.e_lname = ? AND Employee.e_designation = ?  AND Employee.e_department = ?  AND Employee.e_emailaddress = ?  AND Employee.e_company = ? AND Credentials.c_contact = ?;";
            try (PreparedStatement pstmt = conn.prepareStatement(query)) { 
                // Set the parameters using the provided values
                pstmt.setString(1, "Charles"); // Set the first parameter (e_fname)
                pstmt.setString(2, "Leclerc"); // Set the second parameter (e_lname)
                pstmt.setString(3, "CyberSecurity"); // Set the second parameter (designation);
                pstmt.setString(4, "IT Department");
                pstmt.setString(5,"Lcharles@yahoo.com");
                pstmt.setString(6,"METRO PACIFIC INVESMENT");
                pstmt.setString(7,"0906210123");
                					
                ResultSet result = pstmt.executeQuery(); 
                if (result.next()) { 

                   emailfield.setText(result.getString("e_emailaddress"));
                    companyfield.setText(result.getString("e_company"));  
                    chatfield.setText(result.getString("e_department"));
                    jobtitlefield.setText(result.getString("e_designation"));
                    workcontactfield.setText(result.getString("c_contact")); 
                    departmentfield.setText(result.getString("e_department"));

                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception properly
        }
    }
}
