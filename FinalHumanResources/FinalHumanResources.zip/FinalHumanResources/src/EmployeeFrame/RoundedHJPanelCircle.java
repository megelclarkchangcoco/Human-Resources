package EmployeeFrame;

import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;


public class RoundedHJPanelCircle extends JPanel {
    private Shape shape;

    public RoundedHJPanelCircle() {
        setOpaque(true);
        setBackground(new Color(255, 255, 255));
    }

    @Override
    protected void paintComponent(Graphics g) {
        g.setColor(getBackground());
        int diameter = Math.min(getWidth(), getHeight()) * 2; // Increase diameter by a factor of 2
        g.fillOval((getWidth() - diameter) / 2, (getHeight() - diameter) / 2, diameter, diameter);
        super.paintComponent(g);
    }

    @Override
    protected void paintBorder(Graphics g) {
    	g.setColor(new Color(120, 182, 50));
        int diameter = Math.min(getWidth(), getHeight()) * 2; // Increase diameter by a factor of 2
        g.drawOval((getWidth() - diameter) / 2, (getHeight() - diameter) / 2, diameter, diameter);
    }

    @Override
    public boolean contains(int x, int y) {
        if (shape == null || !shape.getBounds().equals(getBounds())) {
            int diameter = Math.min(getWidth(), getHeight()) * 2; // Increase diameter by a factor of 2
            shape = new Ellipse2D.Float((getWidth() - diameter) / 2, (getHeight() - diameter) / 2, diameter, diameter);
        }
        return shape.contains(x, y);
    }
}



