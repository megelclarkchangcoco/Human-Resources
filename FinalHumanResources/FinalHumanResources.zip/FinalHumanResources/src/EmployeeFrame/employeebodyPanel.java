package EmployeeFrame;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;




public class employeebodyPanel extends JPanel {
	
	private ImageIcon work2 = new ImageIcon
			(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\loginframeicon\\\\edit (2).png")
			.getImage().getScaledInstance(82, 75, Image.SCALE_DEFAULT));
	private ImageIcon attendance2 = new ImageIcon
			(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\loginframeicon\\\\calendar-clock (1).png")
			.getImage().getScaledInstance(82, 75, Image.SCALE_DEFAULT));
	
	private ImageIcon signout = new ImageIcon
			(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\loginframeicon\\\\sign-in-alt.png")
			.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon profile2 = new ImageIcon
			(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\loginframeicon\\\\lecprofile.png")
			.getImage().getScaledInstance(63, 44, Image.SCALE_DEFAULT));
	private ImageIcon manageaccount = new ImageIcon
			(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\loginframeicon\\\\user-pen.png")
			.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));

	private static final long serialVersionUID = 1L;
	
	private JPanel profilemenuPanel;
	private JPanel bodyPanel;
	private JLabel worklblt;
	private JPanel manageaccountPanel;
	private JPanel contentPane;
	
	/**
	 * Create the panel.
	 */
	public employeebodyPanel() {
		    setBorder(new MatteBorder(0, 0, 2, 2, new Color(41, 75, 141)));
	        setBackground(Color.WHITE); 
	        setLayout(null);
	        
	        setBounds(74, 51, 1191, 752);
	        bodyPanel = new JPanel();
			bodyPanel.setBorder(new MatteBorder(0, 0, 2, 2, (Color) new Color(41, 75, 141)));
			bodyPanel.setBackground(new Color(255, 255, 255));
			bodyPanel.setBounds(74, 51, 1191, 752);
			bodyPanel.setLayout(null);
	        
	        profilemenuPanel = new JPanel();
			profilemenuPanel.setBackground(new Color(255, 255, 255));
			profilemenuPanel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, new Color(41, 75, 141), new Color(41, 75, 141), null));
			profilemenuPanel.setBounds(975, 0, 216, 227);
			profilemenuPanel.setVisible(false);
			bodyPanel.add(profilemenuPanel);
			profilemenuPanel.setLayout(null);
			
			JPanel signoutPanel = new JPanel();
			signoutPanel.setBorder(new MatteBorder(1, 0, 2, 0, (Color) new Color(41, 75, 141)));
			signoutPanel.addMouseListener(new PanelButtonMouseAdapter(signoutPanel) {
				@Override
				public void mouseClicked(MouseEvent e) {
					
					int option = JOptionPane.showConfirmDialog(contentPane, "Sign Out Confirmation", "Confirmation", JOptionPane.YES_NO_OPTION);

					if (option == JOptionPane.YES_OPTION) {
					    System.exit(0); // Exit the application
					} ;
				}
			});
			signoutPanel.setBackground(new Color(255, 255, 255));
			signoutPanel.setBounds(12, 146, 192, 42);
			profilemenuPanel.add(signoutPanel);
			signoutPanel.setLayout(null);
			
			JLabel lblNewLabel = new JLabel("Sign Out");
			lblNewLabel.setIcon(signout);
			lblNewLabel.setBounds(12, 13, 93, 29);
			signoutPanel.add(lblNewLabel);
			
			JLabel metrolbl = new JLabel("Metro Pacific Invesment");
			metrolbl.setFont(new Font("Inter Medium", Font.PLAIN, 15));
			metrolbl.setBounds(12, 13, 153, 26);
			profilemenuPanel.add(metrolbl);
			// to do
			JPanel profilePanel_1 = new JPanel();
			profilePanel_1.setLayout(null);
			profilePanel_1.setOpaque(false);
			profilePanel_1.setBackground(Color.WHITE);
			profilePanel_1.setBounds(12, 42, 63, 44);
			profilemenuPanel.add(profilePanel_1);
			
			JLabel profilelbl_1 = new JLabel("");
			profilelbl_1.setIcon(profile2);;
			profilelbl_1.setBounds(0, 0, 63, 44);
			profilePanel_1.add(profilelbl_1);
			
			JLabel namelbl = new JLabel("name");
			namelbl.setBounds(87, 42, 56, 16);
			profilemenuPanel.add(namelbl);
			
			JLabel idlbl = new JLabel("id");
			idlbl.setBounds(87, 70, 56, 16);
			profilemenuPanel.add(idlbl);
			// to do
			 manageaccountPanel = new JPanel();
			 manageaccountPanel.addMouseListener(new PanelButtonMouseAdapter(manageaccountPanel) {
				 @Override
				    public void mouseClicked(MouseEvent e) {
				 }
			 });
			manageaccountPanel.setBorder(new MatteBorder(2, 0, 1, 0, (Color) new Color(41, 75, 141)));
			manageaccountPanel.setBackground(new Color(255, 255, 255));
			manageaccountPanel.setBounds(12, 104, 192, 42);
			profilemenuPanel.add(manageaccountPanel);
			manageaccountPanel.setLayout(null);
			
			JLabel lblManageAccount = new JLabel("Manage Account");
			lblManageAccount.setIcon(manageaccount);
			lblManageAccount.setBounds(12, 13, 125, 29);
			manageaccountPanel.add(lblManageAccount);
			
			JPanel toworktabpanel = new JPanel();
			toworktabpanel.addMouseListener(new PanelButtonMouseAdapter(toworktabpanel) {
				@Override
				public void mouseClicked(MouseEvent e) {

				}
			});
			toworktabpanel.setBorder(new LineBorder(new Color(41, 75, 141)));
			toworktabpanel.setBackground(new Color(255, 255, 255));
			toworktabpanel.setBounds(73, 55, 228, 196);
			bodyPanel.add(toworktabpanel);
			toworktabpanel.setLayout(null);
			
			JLabel workicontab2 = new JLabel("");
			workicontab2.setIcon(work2);
			workicontab2.setBounds(66, 36, 82, 75);
			toworktabpanel.add(workicontab2); 
			 
			JLabel worklbl2 = new JLabel("Work");
			worklbl2.setForeground(new Color(0, 0, 0));
			worklbl2.setFont(new Font("Inter Medium", Font.BOLD, 18));
			worklbl2.setBounds(76, 122, 72, 42);
			toworktabpanel.add(worklbl2);
			
			JPanel toattendancetabpanel = new JPanel();
			toattendancetabpanel.addMouseListener(new PanelButtonMouseAdapter(toattendancetabpanel) {
				@Override
				public void mouseClicked(MouseEvent e) {

					
				}
			});
			toattendancetabpanel.setBorder(new LineBorder(new Color(41, 75, 141)));
			toattendancetabpanel.setBackground(new Color(255, 255, 255));
			toattendancetabpanel.setBounds(345, 55, 228, 196);
			bodyPanel.add(toattendancetabpanel);
			toattendancetabpanel.setLayout(null);
			
			JLabel attendanceicontab2 = new JLabel("");
			attendanceicontab2.setIcon(attendance2);
			attendanceicontab2.setBounds(70, 36, 82, 75);
			toattendancetabpanel.add(attendanceicontab2);
			
			JLabel attendancelbl2 = new JLabel("Attendance");
			attendancelbl2.setFont(new Font("Inter Medium", Font.BOLD, 18));
			attendancelbl2.setBounds(54, 122, 152, 42);
			toattendancetabpanel.add(attendancelbl2);
	}
	
	
	private class PanelButtonMouseAdapter extends MouseAdapter{
		JPanel panel;
		
		public PanelButtonMouseAdapter(JPanel panel) { 
			this.panel = panel;
		}
		
		public void mouseEntered(MouseEvent e) {
			panel.setBackground(new Color(195, 195, 195));
		}
		
		
		public void mouseExited(MouseEvent e) {
			panel.setBackground(new Color(255, 255, 255));
		}
		
		public void mousePressed(MouseEvent e) {
			panel.setBackground(new Color(195, 195, 195));
		}
		
		public void mouseReleased(MouseEvent e) {
			panel.setBackground(new Color(195, 195, 195));
		}
	}
}
