package EmployeeFrame;

import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class CustomTextPane extends JTextPane {

    public CustomTextPane() {
        // Call the superclass constructor
        super();

     // Set default text
        setText("Reasons"); setHorizontalAlignment(JTextField.CENTER);


        // Set default text color
        setForeground(new Color(96, 96, 96));
        setBounds(10, 11, 327, 164);
        setFont(new Font("Tahoma", Font.BOLD, 16));



        // Add focus listener to handle text changes
        addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (getText().equals("Reasons")) {
                    setText("");
                    setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (getText().isEmpty()) {
                    setText("Reasons");
                    setForeground(new Color(96, 96, 96));
                }
            }
        });
    }

	private void setHorizontalAlignment(int center) {
		// TODO Auto-generated method stub
		
	}
}
