package EmployeeFrame;
import com.toedter.calendar.JDateChooser;
import com.toedter.calendar.JTextFieldDateEditor;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class CustomDateChooser extends JDateChooser {

    public CustomDateChooser() {
        // Call the superclass constructor
        super();

        // Set the format of the date chooser
        this.setDateFormatString("yy/MMMM/dd");

        // Get the text field date editor of the date chooser
        JTextFieldDateEditor editor = (JTextFieldDateEditor) this.getDateEditor();
        editor.setEditable(false); // Make the text field non-editable
        editor.setHorizontalAlignment(JTextField.CENTER); // Center align text
        editor.setFont(new Font("Tahoma", Font.BOLD, 14)); // Set font
        editor.setText("Select From Date?"); // Set default text
        editor.setForeground(new Color(96, 96, 96)); // Revert text color to gray when not focused

        

        
        // Add focus listener to clear default text when focused
        editor.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (editor.getText().equals("Select From Date?")) {
                    editor.setText("");
                    editor.setForeground(Color.BLACK); // Change text color to black when focused
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (editor.getText().isEmpty()) {
                    editor.setText("Select From Date?");
                    editor.setForeground(new Color(96, 96, 96)); // Revert text color to gray when not focused
                }
            }
        });

        // Add a property change listener to update the text field when a date is chosen
        this.addPropertyChangeListener("date", new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                if ("date".equals(evt.getPropertyName())) {
                    editor.setDate((java.util.Date) evt.getNewValue());
                }
            }
        });

        // Set the preferred size of the date chooser
        this.setPreferredSize(new Dimension(200, 30));

        // Set the background color of the date chooser 
        this.setBackground(Color.WHITE);
    }

    @Override
    public Dimension getPreferredSize() {
        // Override the getPreferredSize method to ensure proper sizing
        return new Dimension(200, 30);
    }

    @Override
    protected void paintComponent(Graphics g) {
        // Override the paintComponent method to paint a border around the date chooser
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setColor(Color.GRAY);
        g2d.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
        g2d.dispose();
    }
}
