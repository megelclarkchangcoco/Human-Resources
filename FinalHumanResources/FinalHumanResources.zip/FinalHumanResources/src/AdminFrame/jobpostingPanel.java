package AdminFrame;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.LineBorder;
import javax.swing.border.EtchedBorder;

import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextPane;

public class jobpostingPanel extends JPanel {
	private ImageIcon add = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\plus (1).png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon post = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\plus-small.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon edit = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\file-edit.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon trash = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\trash (1).png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));

	private ImageIcon logo = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\wew.jpg").getImage().getScaledInstance(62, 52, Image.SCALE_DEFAULT));

	
	private JPanel scrollContent;
	private JPanel newPanel;
    private Connection connection;
	 
	private static final long serialVersionUID = 1L;
	private int panelCount = 0;

	/**
	 * Create the panel.
	 */
	public jobpostingPanel() {
		setLayout(null);
		setBounds(217,76,1217,688);
		setOpaque(false);
		
		JPanel bodypanel = new JPanel(); 
		bodypanel.setBackground(new Color(255, 255, 255));
		bodypanel.setBounds(0,0,1217,688);
		add(bodypanel);
		bodypanel.setLayout(null);
		 
		JLabel lblleaverequest = new JLabel("Job Posting");
		lblleaverequest.setForeground(new Color(55, 75, 86));
		lblleaverequest.setFont(new Font("Inter", Font.BOLD, 38));
		lblleaverequest.setBounds(35, 11, 343, 58);
		bodypanel.add(lblleaverequest);
		
		 // Create the scroll pane and set its bounds
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(0, 0, 1217, 752); // Adjusted the size to fit within the bounds of bodyPanel
        bodypanel.add(scrollPane);
        
        // Create the panel to hold the content to be scrolled
        scrollContent = new JPanel();
        scrollContent.setBackground(Color.WHITE);
        scrollContent.setPreferredSize(new Dimension(1000, 800)); // Set a preferred size for scrolling
        scrollPane.setViewportView(scrollContent);
        scrollContent.setLayout(null);
        
        JPanel titlepanel = new JPanel();
        titlepanel.setBounds(57, 96, 123, 42);
        titlepanel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
        titlepanel.setBackground(new Color(255, 255, 255));
        scrollContent.add(titlepanel);
        titlepanel.setLayout(null);
        
        JLabel lblNewLabel = new JLabel("All Postings");
        lblNewLabel.setForeground(new Color(55, 75, 86));
        lblNewLabel.setFont(new Font("Inter", Font.PLAIN, 14));
        lblNewLabel.setBounds(26, 11, 87, 20);
        titlepanel.add(lblNewLabel);    
        
        JPanel addpostpanel = new JPanel(); 
        addpostpanel.setBounds(1023, 52, 139, 42); 
        addpostpanel.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		 addPanel();
        	}
        });
        addpostpanel.setLayout(null);
        addpostpanel.setBorder(new EtchedBorder(EtchedBorder.RAISED, null, null));
        addpostpanel.setBackground(new Color(55, 75, 86));
        scrollContent.add(addpostpanel);
        
        JLabel lblAdd = new JLabel("add new post");
        lblAdd.setIcon(add);
        lblAdd.setForeground(new Color(255, 255, 255));
        lblAdd.setFont(new Font("Inter", Font.PLAIN, 14));
        lblAdd.setBounds(10, 11, 119, 20);
        addpostpanel.add(lblAdd);
        
        newPanel = new JPanel();
   	    newPanel.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		if (newPanel.getHeight() == 128) {
        			newPanel.setSize(new Dimension(1105, 383));
                } else {
                	newPanel.setSize(new Dimension(1105, 128));
                }
        	}
        });
   	    newPanel.setBounds(57, 138, 1105, 383);
        newPanel.setBorder(new LineBorder(new Color(192, 192, 192)));
        newPanel.setBackground(new Color(255, 255, 255));
        scrollContent.add(newPanel);
        newPanel.setLayout(null);
        
        JTextPane txtpnTitle = new JTextPane();
        txtpnTitle.setFont(new Font("Inter Medium", Font.PLAIN, 18));
        txtpnTitle.setText("Title");
        txtpnTitle.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				if (txtpnTitle.getText().equals("")) {
					txtpnTitle.setForeground(new Color(96, 96, 96));
					txtpnTitle.setText("Title");
				}
			}

			@Override 
			public void focusGained(FocusEvent e) {
				if (txtpnTitle.getText().equals("Title")) {
					txtpnTitle.setForeground(Color.BLACK);
					txtpnTitle.setText("");
				}
			}
			
		});
        txtpnTitle.setBounds(10, 11, 256, 29);
        newPanel.add(txtpnTitle);
        
        JTextPane txtpnLocation = new JTextPane();
        txtpnLocation.setText("Location");
        txtpnLocation.setFont(new Font("Inter Medium", Font.PLAIN, 14));
        txtpnLocation.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				if (txtpnLocation.getText().equals("")) {
					txtpnLocation.setForeground(new Color(96, 96, 96));
					txtpnLocation.setText("Location");
				}
			}

			@Override 
			public void focusGained(FocusEvent e) {
				if (txtpnLocation.getText().equals("Location")) {
					txtpnLocation.setForeground(Color.BLACK);
					txtpnLocation.setText("");
				}
			}
		});
        txtpnLocation.setBounds(75, 42, 191, 52);
        newPanel.add(txtpnLocation);
        
        JLabel lbllogo = new JLabel("");
        lbllogo.setIcon(logo); 
        lbllogo.setBounds(10, 42, 62, 52); 
        newPanel.add(lbllogo); 
        
        JTextPane jobdescriptionpane = new JTextPane(); 
        jobdescriptionpane.setText("Platform");   
        jobdescriptionpane.setFont(new Font("Inter Medium", Font.PLAIN, 12)); 
        jobdescriptionpane.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				if (jobdescriptionpane.getText().equals("")) {
					jobdescriptionpane.setForeground(new Color(96, 96, 96));
					jobdescriptionpane.setText("Platform");
				}
			}

			@Override 
			public void focusGained(FocusEvent e) {
				if (jobdescriptionpane.getText().equals("Platform")) {
					jobdescriptionpane.setForeground(Color.BLACK);
					jobdescriptionpane.setText("");
				}
			}
		});
        jobdescriptionpane.setBounds(10, 100, 1085, 272); 
        newPanel.add(jobdescriptionpane);
        
        JPanel editpanels = new JPanel();
        editpanels.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        	}
        });
        editpanels.setBorder(new LineBorder(new Color(192, 192, 192)));
        editpanels.setBackground(new Color(255, 255, 255));
        editpanels.setBounds(1015, 11, 35, 29);
        newPanel.add(editpanels);
        editpanels.setLayout(null);
        
        JLabel editlbl = new JLabel("");
        editlbl.setIcon(edit);
        editlbl.setBounds(10, 0, 25, 29);
        editpanels.add(editlbl);
        
        // panel logic function
        JPanel postpanel = new JPanel();
        postpanel.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		String title = txtpnTitle.getText().trim();
          		 String Location = txtpnLocation.getText().trim();
          		 String platform = jobdescriptionpane.getText().trim();
                   if (title.isEmpty()) {
                       JOptionPane.showMessageDialog(jobpostingPanel.this, "Empty Title Field", "Error", JOptionPane.ERROR_MESSAGE);
                   }
                   if(Location.isEmpty()) {
                       JOptionPane.showMessageDialog(jobpostingPanel.this, "Empty Location Field", "Error", JOptionPane.ERROR_MESSAGE);

                   } 
                   if(platform.isEmpty()) {
                       JOptionPane.showMessageDialog(jobpostingPanel.this, "Empty Description Field", "Error", JOptionPane.ERROR_MESSAGE);

                   }else {
                  	 txtpnTitle.setEditable(false);
                       JOptionPane.showMessageDialog(jobpostingPanel.this, "Data saved successfully");
                       savePanelData(title, Location, platform); // Save panel data to database
                   }
        	}
        });
        postpanel.setBorder(new LineBorder(new Color(192, 192, 192)));
        postpanel.setBackground(new Color(255, 255, 255));
        postpanel.setBounds(923, 11, 82, 29);
        newPanel.add(postpanel);
        postpanel.setLayout(null);
        
        JLabel lblpost = new JLabel("post");
        lblpost.setIcon(post);
        lblpost.setFont(new Font("Inter Medium", Font.PLAIN, 14));
        lblpost.setBounds(10, 0, 62, 29);
        postpanel.add(lblpost);
        
        JPanel deletepanel = new JPanel();
        deletepanel.setBounds(1060, 11, 35, 29);
        newPanel.add(deletepanel);
        deletepanel.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		scrollContent.remove(newPanel);
        		scrollContent.revalidate();
        		scrollContent.repaint();
                 panelCount--;
                 adjustPanelPositions(); 
                 deletePanelData(txtpnTitle.getText(), txtpnLocation.getText(), jobdescriptionpane.getText());
        	}
        });
        deletepanel.setBorder(new LineBorder(new Color(192, 192, 192)));
        deletepanel.setBackground(new Color(255, 255, 255));
        deletepanel.setLayout(null);
        
        JLabel deletelbl = new JLabel("");
        deletelbl.setIcon(trash);
        deletelbl.setBounds(10, 0, 25, 29);
        deletepanel.add(deletelbl);
        
        connectToDatabase(); // connect to the database
        loadPanelData(); // Load panel data when the frame is initialized
        
	}
	
	
	// method for add post panel 
    private void addPanel() {
    	
    	if (panelCount < 5) { // Limit addition to 5 panels
        adjustPanelPositions(); // Move existing panels down
    	
   	    newPanel = new JPanel();
   	    newPanel.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		if (newPanel.getHeight() == 128) {
        			newPanel.setSize(new Dimension(1105, 383));
                } else {
                	newPanel.setSize(new Dimension(1105, 128));
                }
        	}
        });
   	    newPanel.setBounds(57, 138, 1105, 128);
        newPanel.setBorder(new LineBorder(new Color(192, 192, 192)));
        newPanel.setBackground(new Color(255, 255, 255));
        scrollContent.add(newPanel);
        newPanel.setLayout(null);
        
        JTextPane txtpnTitle = new JTextPane();
        txtpnTitle.setFont(new Font("Inter Medium", Font.PLAIN, 18));
        txtpnTitle.setText("Title");
        txtpnTitle.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				if (txtpnTitle.getText().equals("")) {
					txtpnTitle.setForeground(new Color(96, 96, 96));
					txtpnTitle.setText("Title");
				}
			}

			@Override 
			public void focusGained(FocusEvent e) {
				if (txtpnTitle.getText().equals("Title")) {
					txtpnTitle.setForeground(Color.BLACK);
					txtpnTitle.setText("");
				}
			}
			
		});
        txtpnTitle.setBounds(10, 11, 256, 29);
        newPanel.add(txtpnTitle);
        
        JTextPane txtpnLocation = new JTextPane();
        txtpnLocation.setText("Location");
        txtpnLocation.setFont(new Font("Inter Medium", Font.PLAIN, 14));
        txtpnLocation.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				if (txtpnLocation.getText().equals("")) {
					txtpnLocation.setForeground(new Color(96, 96, 96));
					txtpnLocation.setText("Location");
				}
			}

			@Override 
			public void focusGained(FocusEvent e) {
				if (txtpnLocation.getText().equals("Location")) {
					txtpnLocation.setForeground(Color.BLACK);
					txtpnLocation.setText("");
				}
			}
		});
        txtpnLocation.setBounds(75, 42, 191, 52);
        newPanel.add(txtpnLocation);
        
        JLabel lbllogo = new JLabel("");
        lbllogo.setIcon(logo); 
        lbllogo.setBounds(10, 42, 62, 52); 
        newPanel.add(lbllogo); 
        
        JTextPane jobdescriptionpane = new JTextPane(); 
        jobdescriptionpane.setText("Platform");   
        jobdescriptionpane.setFont(new Font("Inter Medium", Font.PLAIN, 12)); 
        jobdescriptionpane.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				if (jobdescriptionpane.getText().equals("")) {
					jobdescriptionpane.setForeground(new Color(96, 96, 96));
					jobdescriptionpane.setText("Platform");
				}
			}

			@Override 
			public void focusGained(FocusEvent e) {
				if (jobdescriptionpane.getText().equals("Platform")) {
					jobdescriptionpane.setForeground(Color.BLACK);
					jobdescriptionpane.setText("");
				}
			}
		});
        jobdescriptionpane.setBounds(10, 100, 1085, 272); 
        newPanel.add(jobdescriptionpane);
        
        JPanel editpanels = new JPanel();
        editpanels.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        	}
        });
        editpanels.setBorder(new LineBorder(new Color(192, 192, 192)));
        editpanels.setBackground(new Color(255, 255, 255));
        editpanels.setBounds(1015, 11, 35, 29);
        newPanel.add(editpanels);
        editpanels.setLayout(null);
        
        JLabel editlbl = new JLabel("");
        editlbl.setIcon(edit);
        editlbl.setBounds(10, 0, 25, 29);
        editpanels.add(editlbl);
        
        JPanel deletepanel = new JPanel();
        deletepanel.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		scrollContent.remove(newPanel);
        		scrollContent.revalidate();
        		scrollContent.repaint();
                 panelCount--;
                 adjustPanelPositions(); 
                 deletePanelData(txtpnTitle.getText(), txtpnLocation.getText(), jobdescriptionpane.getText());
        	}
        });
        deletepanel.setBorder(new LineBorder(new Color(192, 192, 192)));
        deletepanel.setBackground(new Color(255, 255, 255));
        deletepanel.setBounds(1060, 11, 35, 29);
        scrollContent.add(deletepanel);
        deletepanel.setLayout(null);
        
        JLabel deletelbl = new JLabel("");
        deletelbl.setIcon(trash);
        deletelbl.setBounds(10, 0, 25, 29);
        deletepanel.add(deletelbl);
        
        // panel logic function
        JPanel postpanel = new JPanel();
        postpanel.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		String title = txtpnTitle.getText().trim();
          		 String Location = txtpnLocation.getText().trim();
          		 String platform = jobdescriptionpane.getText().trim();
                   if (title.isEmpty()) {
                       JOptionPane.showMessageDialog(jobpostingPanel.this, "Empty Title Field", "Error", JOptionPane.ERROR_MESSAGE);
                   }
                   if(Location.isEmpty()) {
                       JOptionPane.showMessageDialog(jobpostingPanel.this, "Empty Location Field", "Error", JOptionPane.ERROR_MESSAGE);

                   } 
                   if(platform.isEmpty()) {
                       JOptionPane.showMessageDialog(jobpostingPanel.this, "Empty Description Field", "Error", JOptionPane.ERROR_MESSAGE);

                   }else {
                  	 txtpnTitle.setEditable(false);
                       JOptionPane.showMessageDialog(jobpostingPanel.this, "Data saved successfully");
                       savePanelData(title, Location, platform); // Save panel data to database
                   }
        	}
        });
        postpanel.setBorder(new LineBorder(new Color(192, 192, 192)));
        postpanel.setBackground(new Color(255, 255, 255));
        postpanel.setBounds(923, 11, 82, 29);
        newPanel.add(postpanel);
        postpanel.setLayout(null);
        
        JLabel lblpost = new JLabel("post");
        lblpost.setIcon(post);
        lblpost.setFont(new Font("Inter Medium", Font.PLAIN, 14));
        lblpost.setBounds(10, 0, 62, 29);
        postpanel.add(lblpost);
       
        
        scrollContent.add(newPanel);
        scrollContent.revalidate();
        scrollContent.repaint();
        panelCount++;
    	} else {
            JOptionPane.showMessageDialog(jobpostingPanel.this, "Maximum panel limit reached", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // method for move down panel
    private void adjustPanelPositions() {
        Component[] components = scrollContent.getComponents();
        int yPos = 69;
        for (int i = 0; i < components.length; i++) {
            if (components[i] instanceof JPanel) {
                JPanel existingPanel = (JPanel) components[i];
                existingPanel.setBounds(41, yPos, 461, 101);
                yPos += 150; // Increment yPos for the next panel
            }
        }
    }
 // Connect to the database
    private void connectToDatabase() {
        String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
        try {
            connection = DriverManager.getConnection(url);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    // Method for Save panel data to database
    private void savePanelData(String text, String location, String platform) {
        String query = "INSERT INTO jobposting(jobtitle, joblocation, jobdescription) VALUES (?,?,?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, text);
            statement.setString(2, location);
            statement.setString(3, platform);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
 // Delete panel data from database
    private void deletePanelData(String text, String location, String platform) {
        String query = "INSERT INTO jobposting(jobtitle, joblocation, jobdescription) VALUES (?,?,?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, text);
            statement.setString(2, location);
            statement.setString(3, platform);
        	statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    // Load panel data from database
    private void loadPanelData() {
        String query = "SELECT jobtitle, joblocation, jobdescription FROM jobposting";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                String text = resultSet.getString("jobtitle");
                String text2 = resultSet.getString("joblocation");
                String text3 = resultSet.getString("jobdescription");
                addPanel(); // Add panel with loaded text
                JTextPane textPane = (JTextPane) ((JPanel) scrollContent.getComponent(scrollContent.getComponentCount() - 1)).getComponent(0);
                JTextPane textPane2 = (JTextPane) ((JPanel) scrollContent.getComponent(scrollContent.getComponentCount() - 1)).getComponent(1);
                JTextPane textPane3 = (JTextPane) ((JPanel) scrollContent.getComponent(scrollContent.getComponentCount() - 1)).getComponent(2);
                textPane.setText(text);
                textPane.setEditable(false); // Make text pane not editable
                textPane2.setText(text2);
                textPane2.setEditable(false); // Make text pane not editable
                textPane3.setText(text3);
                textPane3.setEditable(false); // Make text pane not editable
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


}
