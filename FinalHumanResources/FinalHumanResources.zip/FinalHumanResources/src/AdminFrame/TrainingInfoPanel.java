package AdminFrame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import com.toedter.calendar.JDateChooser;
import javax.swing.JTextField;



public class TrainingInfoPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTable table;
	private JLabel lblprofile;
	private JTextPane fullnamepane, idpane, emailpane;
	private JTextField seasionfield;
	private JTextField trainingdesignationfield;
	private JDateChooser startChooser, endChooser;
	private JLabel seasionemptylbl, startemptylbl, endemptylbl, designationempty;
	/**
	 * Create the panel.
	 */
	public TrainingInfoPanel() {
		setLayout(null); 
		setBounds(217,76,1217,688); 
		setOpaque(false);
		
		
		JPanel bodypanel = new JPanel();
		bodypanel.setBackground(Color.WHITE);
		bodypanel.setBounds(0, 0, 1217, 688);
		add(bodypanel);
		bodypanel.setLayout(null);
		
		JLabel lblemployeedata = new JLabel("Training");
		lblemployeedata.setForeground(new Color(55, 75, 86));
		lblemployeedata.setFont(new Font("Inter", Font.BOLD, 38));
		lblemployeedata.setBounds(35, 11, 343, 58); 
		bodypanel.add(lblemployeedata);
		
		JPanel tablepanel = new JPanel();
		tablepanel.setBackground(new Color(255, 255, 255));
		tablepanel.setBounds(35, 80, 588, 525);
		bodypanel.add(tablepanel);
		tablepanel.setLayout(new BorderLayout()); // Use BorderLayout for proper component placement

		// Create a JScrollPane and add the JTable to it
		JScrollPane scrollPane = new JScrollPane();  
		scrollPane.setBackground(Color.WHITE);
		scrollPane.setOpaque(false);
		scrollPane.setBounds(0, 0, 525, 525);
		tablepanel.add(scrollPane, BorderLayout.CENTER);

		table = new JTable();
		table.setShowGrid(false);
		table.setFont(new Font("Inter", Font.PLAIN, 12));
		table.setShowVerticalLines(false);
		table.setRowHeight(30);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				
			},
			new String[] {
					"NO.", "Lastname", "Firstname", "seasion", "Start", "End","Designation"
			}
		));
		table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
		    @Override
		    public void valueChanged(ListSelectionEvent e) {
		        if (!e.getValueIsAdjusting()) {
		            // Check if any row is selected
		            if (table.getSelectedRow() != -1) {
		                // Call the method to view data when a row is selected
		            	viewSQLdata();
		                loadProfileIcon(); 
		            }
		        }
		    }
		});
		// Assuming your table has already been configured
		scrollPane.setViewportView(table); // Set the JTable as the view of the scroll pane
		fetchDatainTable();
		
		JSeparator separator = new JSeparator();
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setBounds(633, 39, 24, 638);
		bodypanel.add(separator);
		
		JPanel viewpanel = new JPanel();
		viewpanel.addMouseListener(new PanelButtonMouseAdapter(viewpanel) {
			@Override
			public void mouseClicked(MouseEvent e) {
				viewSQLdata();
				loadProfileIcon();
			}
		});
		viewpanel.setBorder(new LineBorder(new Color(41, 75, 86)));
		viewpanel.setBackground(new Color(255, 255, 255));
		viewpanel.setBounds(692, 611, 147, 39);
		bodypanel.add(viewpanel);
		viewpanel.setLayout(null);
		
		JLabel viewlbl = new JLabel("View");
		viewlbl.setForeground(new Color(41, 75, 86));
		viewlbl.setFont(new Font("Inter", Font.BOLD, 16));
		viewlbl.setBounds(46, 11, 76, 17);
		viewpanel.add(viewlbl);
		
		lblprofile = new JLabel("");
		lblprofile.setBounds(667, 52, 113, 107);
		bodypanel.add(lblprofile);
		
		 idpane = new JTextPane();
		 idpane.setEditable(false);
		idpane.setFont(new Font("Inter", Font.BOLD, 16));
		idpane.setBounds(877, 89, 330, 26);
		bodypanel.add(idpane);
		
		 emailpane = new JTextPane();
		 emailpane.setEditable(false);
		emailpane.setFont(new Font("Inter", Font.BOLD, 16));
		emailpane.setBounds(877, 113, 330, 26);
		bodypanel.add(emailpane);
		
		JLabel lblNewLabel_3_1_1_2_1 = new JLabel("Email                 :");
		lblNewLabel_3_1_1_2_1.setFont(new Font("Inter", Font.PLAIN, 12));
		lblNewLabel_3_1_1_2_1.setBounds(790, 113, 102, 26);
		bodypanel.add(lblNewLabel_3_1_1_2_1);
		
		JLabel lblNewLabel_3_1_1_1_1 = new JLabel("ID                       :");
		lblNewLabel_3_1_1_1_1.setFont(new Font("Inter", Font.PLAIN, 12));
		lblNewLabel_3_1_1_1_1.setBounds(790, 89, 102, 26);
		bodypanel.add(lblNewLabel_3_1_1_1_1);
		

		 fullnamepane = new JTextPane();
		 fullnamepane.setEditable(false);
		fullnamepane.setFont(new Font("Inter", Font.BOLD, 16));
		fullnamepane.setBounds(877, 63, 330, 26);
		bodypanel.add(fullnamepane);
		
		JLabel lblNewLabel_3_1_1_1_2 = new JLabel("Full Name        :");
		lblNewLabel_3_1_1_1_2.setFont(new Font("Inter", Font.PLAIN, 12));
		lblNewLabel_3_1_1_1_2.setBounds(790, 63, 102, 26);
		bodypanel.add(lblNewLabel_3_1_1_1_2);
		
		 startChooser = new JDateChooser();
		startChooser.setForeground(Color.BLACK);
		startChooser.setBounds(667, 324, 347, 43);
		bodypanel.add(startChooser);
		
		 endChooser = new JDateChooser();
		endChooser.setForeground(Color.BLACK);
		endChooser.setBounds(667, 424, 347, 43);
		bodypanel.add(endChooser);
		
		seasionfield = new JTextField();
		seasionfield.setBounds(667, 219, 347, 43);
		bodypanel.add(seasionfield);
		seasionfield.setColumns(10);
		
		trainingdesignationfield = new JTextField();
		trainingdesignationfield.setColumns(10);
		trainingdesignationfield.setBounds(667, 533, 347, 43);
		bodypanel.add(trainingdesignationfield);
		
		JPanel updatepanel = new JPanel();
		updatepanel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				insertTrainingInfotoDatabase();
				saveDataToTable();
			}
		});
		updatepanel.setLayout(null);
		updatepanel.setBorder(new LineBorder(new Color(41, 75, 86)));
		updatepanel.setBackground(Color.WHITE);
		updatepanel.setBounds(849, 611, 147, 39);
		bodypanel.add(updatepanel);
		
		JLabel lblUpdate = new JLabel("Update");
		lblUpdate.setForeground(new Color(41, 75, 86));
		lblUpdate.setFont(new Font("Inter", Font.BOLD, 16));
		lblUpdate.setBounds(46, 11, 76, 17);
		updatepanel.add(lblUpdate);
		
		JLabel lblSeasion = new JLabel("Seasion ");
		lblSeasion.setForeground(new Color(55, 75, 86));
		lblSeasion.setFont(new Font("Inter", Font.BOLD, 20));
		lblSeasion.setBounds(667, 173, 102, 58);
		bodypanel.add(lblSeasion);
		
		JLabel lblStartDate = new JLabel("Start Date");
		lblStartDate.setForeground(new Color(55, 75, 86));
		lblStartDate.setFont(new Font("Inter", Font.BOLD, 20));
		lblStartDate.setBounds(667, 273, 120, 58);
		bodypanel.add(lblStartDate);
		
		JLabel lblEndDate = new JLabel("End Date");
		lblEndDate.setForeground(new Color(55, 75, 86));
		lblEndDate.setFont(new Font("Inter", Font.BOLD, 20));
		lblEndDate.setBounds(667, 372, 102, 58);
		bodypanel.add(lblEndDate);
		
		JLabel lblTrainingDesignation = new JLabel("Training Designation");
		lblTrainingDesignation.setForeground(new Color(55, 75, 86));
		lblTrainingDesignation.setFont(new Font("Inter", Font.BOLD, 20));
		lblTrainingDesignation.setBounds(667, 478, 225, 58);
		bodypanel.add(lblTrainingDesignation);
		
		seasionemptylbl = new JLabel("seasion is empty please fill up");
		seasionemptylbl.setVisible(false);
		seasionemptylbl.setForeground(new Color(255, 0, 0));
		seasionemptylbl.setVisible(false);;
		seasionemptylbl.setBounds(667, 264, 309, 14);
		bodypanel.add(seasionemptylbl);
		
		 startemptylbl = new JLabel("start date is empty please fill up");
		 startemptylbl.setVisible(false);
		startemptylbl.setForeground(new Color(255, 0, 0));
		startemptylbl.setBounds(667, 368, 329, 14);
		bodypanel.add(startemptylbl);
		
		 endemptylbl = new JLabel("end date is empty please fill up");
		 endemptylbl.setVisible(false);
		endemptylbl.setForeground(Color.RED);
		endemptylbl.setBounds(667, 469, 298, 14);
		bodypanel.add(endemptylbl);
		
		 designationempty = new JLabel("designation date is empty please fill up");
		 designationempty.setVisible(false);
		designationempty.setForeground(Color.RED);
		designationempty.setBounds(667, 575, 259, 14);
		bodypanel.add(designationempty);
	}
	
	// method for display sql table data in jtable
		private void fetchDatainTable() {
			// Assuming this code is within a method
			try {
				String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
			    Connection connection = DriverManager.getConnection(url);

			    String sql = "SELECT * FROM Training;"; // Adjust SQL query according to your table name
			    PreparedStatement statement = connection.prepareStatement(sql);
			    ResultSet resultSet = statement.executeQuery();
			    // Create a DefaultTableModel with columns "Employee ID", "Lastname", "Firstname", "Designation"
			    DefaultTableModel tableModel = new DefaultTableModel(
			        new String[] {"NO.", "Lastname", "Firstname", "seasion", "Start", "End","Designation"}, 0);

			    // Populate table model with data from result set
			    while (resultSet.next()) {
			        int applicantID = resultSet.getInt("training_id"); // Adjust column name as per your table
			        String lastName = resultSet.getString("apprentice_lname");
			        String firstName = resultSet.getString("apprentice_fname");
			        String seasion = resultSet.getString("seasion");
			        String start = resultSet.getString("startDate");
			        String end = resultSet.getString("endDate");
			        String designation = resultSet.getString("designation");

			        Object[] rowData = {applicantID, lastName, firstName, seasion, start, end, designation};
			        tableModel.addRow(rowData);
			    }

			    // Set the table model to your JTable
			    table.setModel(tableModel);

			    // Close the result set and statement 
			    resultSet.close();
			    statement.close();
			    connection.close();
			} catch (Exception e) {
			    e.printStackTrace();
			    JOptionPane.showMessageDialog(null, "Error: Failed to retrieve data from the database. ", "Error", JOptionPane.ERROR_MESSAGE);
			}
		}
		
		// Method to view data from the selected row in the table
		private void viewSQLdata() {
		    int selectedRow = table.getSelectedRow();
		    if (selectedRow != -1) { // If a row is selected
		        try {
		            // Load the JDBC driver class
		            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

		            // Define the JDBC URL
		            String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";

		            // Establish the database connection
		            try (Connection connection = DriverManager.getConnection(url)) {
		                // Get the employee ID from the selected row as an Object
		                Object employeeIDObject = table.getValueAt(selectedRow, 0);
		                
		                if (employeeIDObject instanceof Integer) { // Check if the employee ID is an Integer
		                    int employeeID = (int) employeeIDObject; // Cast the Object to an int

		                    String sql = "SELECT * FROM Training WHERE training_id = ?";
		                    try (PreparedStatement statement = connection.prepareStatement(sql)) {
		                        // Set the employee ID as the parameter for the SQL query
		                        statement.setInt(1, employeeID);

		                        // Execute the query
		                        try (ResultSet resultSet = statement.executeQuery()) {
		                            if (resultSet.next()) { 
		                                // Retrieve and display data 
		                                String lastName = resultSet.getString("apprentice_lname");
		                                String firstName = resultSet.getString("apprentice_fname");


		                                // Set data to labels or whatever UI components you're using
		                                idpane.setText(String.valueOf(employeeID));
		                                fullnamepane.setText(lastName + ", " + firstName);
		                            }
		                        }
		                    }
		                }
		            }
		        } catch (Exception e) {
		            e.printStackTrace();
		            JOptionPane.showMessageDialog(null, "Error: Failed to retrieve data from the database.", "Error", JOptionPane.ERROR_MESSAGE);
		        }
		    }
		}
		
		 // method for retrive image from sql
		private void loadProfileIcon() {
		    int selectedRow = table.getSelectedRow();
		    if (selectedRow != -1) { // If a row is selected
		        try {
		            // Load the JDBC driver class
		            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

		            // Define the JDBC URL
		            String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";

		            // Establish the database connection
		            try (Connection connection = DriverManager.getConnection(url)) {
		                // Prepare the SQL statement to retrieve the profile image based on the employee ID of the selected row
		                String sql = "SELECT profileImage FROM Training WHERE training_id = ?";
		                try (PreparedStatement statement = connection.prepareStatement(sql)) {
		                    // Get the employee ID of the selected row
		                    int employeeID = (int) table.getValueAt(selectedRow, 0);
		                    // Set the employee ID as the parameter for the SQL query
		                    statement.setInt(1, employeeID);

		                    // Execute the query
		                    try (ResultSet resultSet = statement.executeQuery()) {
		                        if (resultSet.next()) { 
		                            // Retrieve and display the profile image
		                            byte[] imageData = resultSet.getBytes("profileImage");
		                            if (imageData != null && imageData.length > 0) {
		                                try (ByteArrayInputStream bis = new ByteArrayInputStream(imageData)) {
		                                    BufferedImage bufferedImage = ImageIO.read(bis);
		                                    if (bufferedImage != null) {
		                                        Image scaledImage = bufferedImage.getScaledInstance(lblprofile.getWidth(), lblprofile.getHeight(), Image.SCALE_SMOOTH); 
		                                        lblprofile.setIcon(new ImageIcon(scaledImage));
		                                    } else {
		                                        System.out.println("Failed to read image data from the database.");
		                                    }
		                                }
		                            } else {
		                                System.out.println("Image data retrieved from the database is null or empty.");
		                            }
		                        } else {
		                            System.out.println("No image data found for the specified employee ID.");
		                        }
		                    }
		                }
		            }
		        } catch (Exception e) {
		            e.printStackTrace();
		        }
		    }
		}
		
	
		// method for save update in sql
		private void insertTrainingInfotoDatabase() {
		    try {
		        // Load the JDBC driver class
		        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

		        // Define the JDBC URL
		        String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";

		        // Establish the database connection
		        try (Connection connection = DriverManager.getConnection(url)) {
		            // Retrieve data from fields
		            String seasion = seasionfield.getText();
		            Date startDate = startChooser.getDate();
		            Date endDate = endChooser.getDate();
		            String designation = trainingdesignationfield.getText();
		            
		            // Retrieve selected row from JTable
		            int selectedRow = table.getSelectedRow();
		            if (selectedRow != -1) {
		                // Assuming your table has the training_id in the first column
		                int trainingId = (int) table.getValueAt(selectedRow, 0);
		                
		                if (startDate == null){
		                	startemptylbl.setVisible(true);
		                	
		                } 
		                if(endDate == null) {
		                	endemptylbl.setVisible(true);
		                	
		                }
		                if(seasion.isEmpty()) {
	                		seasionemptylbl.setVisible(true);
	                		
	                	}
	                	 if(designation.isEmpty()) {
	                		designationempty.setVisible(true);
	                		
	                	}
		                if(seasion.isEmpty() || startDate == null || endDate == null || designation.isEmpty()) {
		                	startemptylbl.setVisible(true);
		                	endemptylbl.setVisible(true);
		                	seasionemptylbl.setVisible(true);
		                	designationempty.setVisible(true);
		                	return;
		                }
		                
		                // Prepare statement to update Training table
		                String query = "UPDATE Training SET seasion = ?, startDate = ?, endDate = ?, designation = ? WHERE training_id = ?";
		                try (PreparedStatement pstmt = connection.prepareStatement(query)) {

		                	 
		 		            String startDateStr = new SimpleDateFormat("yyyy-MM-dd").format(startDate);
		                    String endDateStr = new SimpleDateFormat("yyyy-MM-dd").format(endDate);
		                    
		                	pstmt.setString(1, seasion);
		                    pstmt.setString(2, startDateStr);
		                    pstmt.setString(3, endDateStr);
		                    pstmt.setString(4, designation);
		                    pstmt.setInt(5, trainingId);
		                    // Execute the update
		                    int rowsAffected = pstmt.executeUpdate();
		                    if (rowsAffected > 0) {
		                        JOptionPane.showMessageDialog(null, "Data updated successfully.");
		                    } else {
		                        JOptionPane.showMessageDialog(null, "Failed to update data in the database.", "Error", JOptionPane.ERROR_MESSAGE);
		                    }
		                }
		            } else {
		                JOptionPane.showMessageDialog(null, "Please select a row from the table.", "Error", JOptionPane.ERROR_MESSAGE);
		            }
		        }
		    } catch (ClassNotFoundException | SQLException e) {
		        e.printStackTrace();
		        JOptionPane.showMessageDialog(null, "Error: Failed to update data in the database.", "Error", JOptionPane.ERROR_MESSAGE);
		    }
		}
		
		// method for save data in table 
		private void saveDataToTable() {
		    // Retrieve data from user input fields
		    String season = seasionfield.getText();
		    Date startDate = startChooser.getDate();
		    Date endDate = endChooser.getDate();
		    String designation = trainingdesignationfield.getText();

		    // Check if all required fields are filled
		    if (season.isEmpty() || startDate == null || endDate == null || designation.isEmpty()) {
		        return;
		    }

		    // Get selected row index
		    int selectedRowIndex = table.getSelectedRow();

		    // If a row is selected, update data in the selected row
		    if (selectedRowIndex != -1) {
		        // Update the data in the selected row
		        table.setValueAt(season, selectedRowIndex, 3);
		        table.setValueAt(startDate, selectedRowIndex, 4);
		        table.setValueAt(endDate, selectedRowIndex, 5);
		        table.setValueAt(designation, selectedRowIndex, 6);
		    } else {
		        // Create an Object array to hold the data
		        Object[] rowData = {"", "","",season, startDate, endDate, designation};

		        // Add the row data to the table model
		        DefaultTableModel model = (DefaultTableModel) table.getModel();
		        model.addRow(rowData);
		    }

		    // Clear input fields after adding or updating data in the table
		    seasionfield.setText("");
		    startChooser.setDate(null);
		    endChooser.setDate(null);
		    trainingdesignationfield.setText("");

		    JOptionPane.showMessageDialog(null, "Data added/updated in table successfully.");
		}







		private class PanelButtonMouseAdapter extends MouseAdapter{
			JPanel panel;
			
			public PanelButtonMouseAdapter(JPanel panel) {
				this.panel = panel;
			}
			
			public void mouseEntered(MouseEvent e) {
				panel.setBackground(new Color(240, 240, 240));
			}
			
			public void mouseExited(MouseEvent e) {
				panel.setBackground(new Color(255, 255, 255));
			}
			
			public void mousePressed(MouseEvent e) {
				panel.setBackground(new Color(240, 240, 240));
			}
			
			public void mouseReleased(MouseEvent e) {
				panel.setBackground(new Color(240, 240, 240));
			}
		}
}
