package AdminFrame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;



public class applicantTrackingPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTable table;
	private JTextPane fullnamepane, idpane, emailpane, applyingjobspane, birthpane,agepane,genderpane,addresspane, contactpane, primarypane,secondarypane,collegepane, languagepane,frameworkpane,toolspane,workexperiencenpane;
	private JLabel lblprofile;
	private byte[] imageData; // imagedate


	/**
	 * Create the panel.
	 */
	public applicantTrackingPanel() {
	    this.imageData = imageData; // inherit

	    
		setLayout(null);
		setBounds(217,76,1217,688);
		setOpaque(false);
        

		JPanel bodypanel = new JPanel(); 
		bodypanel.setBackground(new Color(255, 255, 255));
		bodypanel.setBounds(0,0,1217,688);
		add(bodypanel);
		bodypanel.setLayout(null);
		  
		JLabel lblemployeedata = new JLabel("Applicant Tracking");
		lblemployeedata.setForeground(new Color(55, 75, 86));
		lblemployeedata.setFont(new Font("Inter", Font.BOLD, 38));
		lblemployeedata.setBounds(35, 11, 472, 58); 
		bodypanel.add(lblemployeedata);
		
		JPanel tablepanel = new JPanel();
		tablepanel.setBackground(new Color(255, 255, 255));
		tablepanel.setBounds(35, 80, 525, 525);
		bodypanel.add(tablepanel);
		tablepanel.setLayout(new BorderLayout()); // Use BorderLayout for proper component placement

		// Create a JScrollPane and add the JTable to it
		JScrollPane scrollPane = new JScrollPane(); 
		scrollPane.setBackground(Color.WHITE);
		scrollPane.setOpaque(false);
		scrollPane.setBounds(0, 0, 525, 525);
		tablepanel.add(scrollPane, BorderLayout.CENTER);

		table = new JTable();
		table.setShowGrid(false);
		table.setFont(new Font("Inter", Font.PLAIN, 12));
		table.setShowVerticalLines(false);
		table.setRowHeight(30);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				
			},
			new String[] {
				"  No ID", "  Lastname", "  Firstname", "  Applying Job"
			}
		));
		table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
		    @Override
		    public void valueChanged(ListSelectionEvent e) {
		        if (!e.getValueIsAdjusting()) {
		            // Check if any row is selected
		            if (table.getSelectedRow() != -1) {
		                // Call the method to view data when a row is selected
		                viewSQLdata();
		                viewCredentialsData();
		                loadProfileIcon(); 
		            }
		        }
		    }
		});
		// Assuming your table has already been configured
		scrollPane.setViewportView(table); // Set the JTable as the view of the scroll pane
		fetchDatainTable();
		
		JSeparator separator = new JSeparator();
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setBounds(573, 39, 24, 638);
		bodypanel.add(separator);
		
		JPanel viewpanel = new JPanel();
		viewpanel.addMouseListener(new PanelButtonMouseAdapter(viewpanel) {
			@Override
			public void mouseClicked(MouseEvent e) {
				viewSQLdata();
				loadProfileIcon();
				viewCredentialsData();
			}
		});
		viewpanel.setBorder(new LineBorder(new Color(41, 75, 86)));
		viewpanel.setBackground(new Color(255, 255, 255));
		viewpanel.setBounds(35, 616, 147, 39);
		bodypanel.add(viewpanel);
		viewpanel.setLayout(null);
		
		JLabel viewlbl = new JLabel("View");
		viewlbl.setForeground(new Color(41, 75, 86));
		viewlbl.setFont(new Font("Inter", Font.BOLD, 16));
		viewlbl.setBounds(46, 11, 76, 17);
		viewpanel.add(viewlbl);
		
		JPanel interviewpanel = new JPanel();
		interviewpanel.addMouseListener(new PanelButtonMouseAdapter(interviewpanel) {
			@Override
			public void mouseClicked(MouseEvent e) {
				openInterviewFrame(imageData);

				
			}
		});
		interviewpanel.setBorder(new LineBorder(new Color(41, 75, 86)));
		interviewpanel.setBackground(new Color(255, 255, 255));
		interviewpanel.setBounds(225, 616, 147, 39);
		bodypanel.add(interviewpanel);
		interviewpanel.setLayout(null);
		
		JLabel lblinterview = new JLabel("Interview");
		lblinterview.setForeground(new Color(41, 75, 86));
		lblinterview.setFont(new Font("Inter", Font.BOLD, 16));
		lblinterview.setBounds(28, 11, 90, 17);
		interviewpanel.add(lblinterview);
		
		JPanel deletepanel = new JPanel();
		deletepanel.addMouseListener(new PanelButtonMouseAdapter(deletepanel) {
			@Override
			public void mouseClicked(MouseEvent e) {
				deleteSQLdata();
			}
		});
		deletepanel.setBorder(new LineBorder(new Color(41, 75, 86)));
		deletepanel.setBackground(new Color(255, 255, 255));
		deletepanel.setBounds(413, 616, 147, 39);
		bodypanel.add(deletepanel);
		deletepanel.setLayout(null);
		
		JLabel lblDelete = new JLabel("Delete");
		lblDelete.setForeground(new Color(41, 75, 86));
		lblDelete.setFont(new Font("Inter", Font.BOLD, 16));
		lblDelete.setBounds(43, 11, 76, 17);
		deletepanel.add(lblDelete);
		
		 lblprofile = new JLabel(""); 
		lblprofile.setBounds(607, 43, 113, 107);
		bodypanel.add(lblprofile);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(607, 161, 532, 2);
		bodypanel.add(separator_1);
		
		JLabel lblInformation = new JLabel("Information");
		lblInformation.setFont(new Font("Inter", Font.PLAIN, 13));
		lblInformation.setBounds(607, 174, 83, 26);
		bodypanel.add(lblInformation);
		
		 birthpane = new JTextPane();
		 birthpane.setEditable(false);
		birthpane.setFont(new Font("Inter", Font.BOLD, 16));
		birthpane.setBounds(694, 211, 330, 26);
		bodypanel.add(birthpane);
		
		JLabel lblbirth = new JLabel("Birth                 :");
		lblbirth.setFont(new Font("Inter", Font.PLAIN, 12));
		lblbirth.setBounds(607, 211, 102, 26);
		bodypanel.add(lblbirth);
		
		 agepane = new JTextPane();
		 agepane.setEditable(false);
		agepane.setFont(new Font("Inter", Font.BOLD, 16));
		agepane.setBounds(694, 235, 330, 26);
		bodypanel.add(agepane);
		
		JLabel lblage = new JLabel("Age                   :");
		lblage.setFont(new Font("Inter", Font.PLAIN, 12));
		lblage.setBounds(607, 235, 102, 26);
		bodypanel.add(lblage);
		
		 genderpane = new JTextPane();
		 genderpane.setEditable(false);
		genderpane.setFont(new Font("Inter", Font.BOLD, 16));
		genderpane.setBounds(694, 260, 330, 26);
		bodypanel.add(genderpane);
		
		JLabel lblgender = new JLabel("Gender             :");
		lblgender.setFont(new Font("Inter", Font.PLAIN, 12));
		lblgender.setBounds(607, 260, 102, 26);
		bodypanel.add(lblgender);
		
		 addresspane = new JTextPane();
		 addresspane.setEditable(false);
		addresspane.setFont(new Font("Inter", Font.BOLD, 16));
		addresspane.setBounds(694, 284, 330, 26);
		bodypanel.add(addresspane);
		
		JLabel lbladdress = new JLabel("Address            :");
		lbladdress.setFont(new Font("Inter", Font.PLAIN, 12));
		lbladdress.setBounds(607, 284, 102, 26);
		bodypanel.add(lbladdress);
		
		 contactpane = new JTextPane();
		 contactpane.setEditable(false);
		contactpane.setFont(new Font("Inter", Font.BOLD, 16));
		contactpane.setBounds(694, 309, 330, 26);
		bodypanel.add(contactpane);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("Contact            :");
		lblNewLabel_3_1_1.setFont(new Font("Inter", Font.PLAIN, 12));
		lblNewLabel_3_1_1.setBounds(607, 309, 102, 26);
		bodypanel.add(lblNewLabel_3_1_1);
		
		 idpane = new JTextPane();
		 idpane.setEditable(false);
		idpane.setFont(new Font("Inter", Font.BOLD, 16));
		idpane.setBounds(817, 80, 330, 26);
		bodypanel.add(idpane);
		
		 emailpane = new JTextPane();
		 emailpane.setEditable(false);
		emailpane.setFont(new Font("Inter", Font.BOLD, 16));
		emailpane.setBounds(817, 104, 330, 26);
		bodypanel.add(emailpane);
		
		JLabel lblNewLabel_3_1_1_2_1 = new JLabel("Email                 :");
		lblNewLabel_3_1_1_2_1.setFont(new Font("Inter", Font.PLAIN, 12));
		lblNewLabel_3_1_1_2_1.setBounds(730, 104, 102, 26);
		bodypanel.add(lblNewLabel_3_1_1_2_1);
		
		JLabel lblNewLabel_3_1_1_1_1 = new JLabel("ID                       :");
		lblNewLabel_3_1_1_1_1.setFont(new Font("Inter", Font.PLAIN, 12));
		lblNewLabel_3_1_1_1_1.setBounds(730, 80, 102, 26);
		bodypanel.add(lblNewLabel_3_1_1_1_1);
		
		JLabel lblNewLabel_3_1_1_3_1 = new JLabel("Applying Job  :");
		lblNewLabel_3_1_1_3_1.setFont(new Font("Inter", Font.PLAIN, 12));
		lblNewLabel_3_1_1_3_1.setBounds(730, 129, 102, 26);
		bodypanel.add(lblNewLabel_3_1_1_3_1);
		
		 applyingjobspane = new JTextPane();
		 applyingjobspane.setEditable(false);
		applyingjobspane.setFont(new Font("Inter", Font.BOLD, 16));
		applyingjobspane.setBounds(817, 129, 330, 26);
		bodypanel.add(applyingjobspane);
		
		 fullnamepane = new JTextPane();
		 fullnamepane.setEditable(false);
		fullnamepane.setFont(new Font("Inter", Font.BOLD, 16));
		fullnamepane.setBounds(817, 54, 330, 26);
		bodypanel.add(fullnamepane);
		
		JLabel lblNewLabel_3_1_1_1_2 = new JLabel("Full Name        :");
		lblNewLabel_3_1_1_1_2.setFont(new Font("Inter", Font.PLAIN, 12));
		lblNewLabel_3_1_1_1_2.setBounds(730, 54, 102, 26);
		bodypanel.add(lblNewLabel_3_1_1_1_2);
		
		JLabel lblEducationalBackground = new JLabel("Educational Background");
		lblEducationalBackground.setFont(new Font("Inter", Font.PLAIN, 13));
		lblEducationalBackground.setBounds(607, 346, 285, 26);
		bodypanel.add(lblEducationalBackground);
		
		JLabel lblprimary = new JLabel(" Primary           :");
		lblprimary.setFont(new Font("Inter", Font.PLAIN, 12));
		lblprimary.setBounds(607, 383, 102, 26);
		bodypanel.add(lblprimary);
		
		JLabel lblsecondary = new JLabel("Secondary      :");
		lblsecondary.setFont(new Font("Inter", Font.PLAIN, 12));
		lblsecondary.setBounds(607, 407, 102, 26);
		bodypanel.add(lblsecondary);
		
		JLabel lblcollege = new JLabel("College            :");
		lblcollege.setFont(new Font("Inter", Font.PLAIN, 12));
		lblcollege.setBounds(607, 432, 102, 26);
		bodypanel.add(lblcollege);
		
		 collegepane = new JTextPane();
		 collegepane.setEditable(false);
		collegepane.setFont(new Font("Inter", Font.BOLD, 16));
		collegepane.setBounds(694, 432, 445, 26);
		bodypanel.add(collegepane);
		
		 secondarypane = new JTextPane();
		 secondarypane.setEditable(false);
		secondarypane.setFont(new Font("Inter", Font.BOLD, 16));
		secondarypane.setBounds(694, 407, 445, 26);
		bodypanel.add(secondarypane);
		
		 primarypane = new JTextPane();
		 primarypane.setEditable(false);
		primarypane.setFont(new Font("Inter", Font.BOLD, 16));
		primarypane.setBounds(694, 383, 445, 26);
		bodypanel.add(primarypane);
		
		 languagepane = new JTextPane();
		languagepane.setFont(new Font("Inter", Font.BOLD, 16));
		languagepane.setBounds(694, 506, 445, 26);
		bodypanel.add(languagepane);
		
		 frameworkpane = new JTextPane();
		 frameworkpane.setEditable(false);
		frameworkpane.setFont(new Font("Inter", Font.BOLD, 16));
		frameworkpane.setBounds(694, 530, 445, 26);
		bodypanel.add(frameworkpane);
		
		 toolspane = new JTextPane();
		 toolspane.setEditable(false);
		toolspane.setFont(new Font("Inter", Font.BOLD, 16));
		toolspane.setBounds(694, 555, 445, 26);
		bodypanel.add(toolspane);
		
		JLabel lblSkills = new JLabel("Skills");
		lblSkills.setFont(new Font("Inter", Font.PLAIN, 13));
		lblSkills.setBounds(607, 469, 285, 26);
		bodypanel.add(lblSkills);
		
		JLabel lblLanguage = new JLabel("language         :");
		lblLanguage.setFont(new Font("Inter", Font.PLAIN, 12));
		lblLanguage.setBounds(607, 506, 102, 26);
		bodypanel.add(lblLanguage);
		
		JLabel lblFrameworks = new JLabel("Frameworks   :");
		lblFrameworks.setFont(new Font("Inter", Font.PLAIN, 12));
		lblFrameworks.setBounds(607, 530, 102, 26);
		bodypanel.add(lblFrameworks);
		
		JLabel lblTools = new JLabel("Tools                 :");
		lblTools.setFont(new Font("Inter", Font.PLAIN, 12));
		lblTools.setBounds(607, 555, 102, 26);
		bodypanel.add(lblTools);
		
		JLabel lblWorkExperience = new JLabel("Work Experience");
		lblWorkExperience.setFont(new Font("Inter", Font.PLAIN, 13));
		lblWorkExperience.setBounds(607, 580, 285, 26);
		bodypanel.add(lblWorkExperience);
		
		workexperiencenpane = new JTextPane();
		workexperiencenpane.setFont(new Font("Inter", Font.BOLD, 16));
		workexperiencenpane.setBounds(694, 616, 445, 26);
		bodypanel.add(workexperiencenpane);

	}
	// method for display sql table data in jtable
	private void fetchDatainTable() {
		// Assuming this code is within a method
		try {
		    String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
		    Connection connection = DriverManager.getConnection(url);

		    String sql = "SELECT * FROM Tracking"; // Adjust SQL query according to your table name
		    PreparedStatement statement = connection.prepareStatement(sql);
		    ResultSet resultSet = statement.executeQuery();

		    // Create a DefaultTableModel with columns "Employee ID", "Lastname", "Firstname", "Designation"
		    DefaultTableModel tableModel = new DefaultTableModel(
		        new String[] {"No ID", "Lastname", "Firstname", "Applying Job"}, 0);

		    // Populate table model with data from result set
		    while (resultSet.next()) {
		        int trackingId = resultSet.getInt("tracking_id"); // Adjust column name as per your table
		        String lastName = resultSet.getString("lastname");
		        String firstName = resultSet.getString("firstname");
		        String applyingjob = resultSet.getString("applyingJob");

		        Object[] rowData = {trackingId, lastName, firstName, applyingjob};
		        tableModel.addRow(rowData);
		    }

		    // Set the table model to your JTable
		    table.setModel(tableModel);

		    // Close the result set and statement 
		    resultSet.close();
		    statement.close();
		    connection.close();
		} catch (Exception e) {
		    e.printStackTrace();
		    JOptionPane.showMessageDialog(null, "Error: Failed to retrieve data from the database. ", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	// Method to view data from the selected row in the table
	private void viewSQLdata() {
	    int selectedRow = table.getSelectedRow();
	    if (selectedRow != -1) { // If a row is selected
	        try {
	            // Load the JDBC driver class
	            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

	            // Define the JDBC URL
	            String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";

	            // Establish the database connection
	            try (Connection connection = DriverManager.getConnection(url)) {
	                // Get the employee ID from the selected row as an Object
	                Object employeeIDObject = table.getValueAt(selectedRow, 0);
	                
	                if (employeeIDObject instanceof Integer) { // Check if the employee ID is an Integer
	                    int trackingID = (int) employeeIDObject; // Cast the Object to an int

	                    String sql = "SELECT * FROM Tracking WHERE tracking_id = ?";
	                    try (PreparedStatement statement = connection.prepareStatement(sql)) {
	                        // Set the employee ID as the parameter for the SQL query
	                        statement.setInt(1, trackingID);

	                        // Execute the query
	                        try (ResultSet resultSet = statement.executeQuery()) {
	                            if (resultSet.next()) { 
	                                // Retrieve and display data 
	                                String lastName = resultSet.getString("lastname");
	                                String firstName = resultSet.getString("firstname");
	                                String email = resultSet.getString("email");
	                                String applyingjob = resultSet.getString("applyingJob");


	                                // Set data to labels or whatever UI components you're using
	                                idpane.setText(String.valueOf(trackingID));
	                                fullnamepane.setText(lastName + ", " + firstName);
	                                emailpane.setText(email);
	                                applyingjobspane.setText(applyingjob);

	                            }
	                        }
	                    }
	                }
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(null, "Error: Failed to retrieve data from the database.", "Error", JOptionPane.ERROR_MESSAGE);
	        }
	    }
	}
	// Method to view data from the selected row in the table for Trackign
	private void viewCredentialsData() {
	    int selectedRow = table.getSelectedRow();
	    if (selectedRow != -1) { // If a row is selected
	        try {
	            // Load the JDBC driver class
	            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

	            // Define the JDBC URL
	            String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";

	            // Establish the database connection
	            try (Connection connection = DriverManager.getConnection(url)) {
	                // Get the employee ID from the selected row as an Object
	                Object trackingIDobject = table.getValueAt(selectedRow, 0);
	                
	                if (trackingIDobject instanceof Integer) { // Check if the employee ID is an Integer
	                    int credentialID = (int) trackingIDobject; // Cast the Object to an int

	                    String sql = "SELECT * FROM Tracking WHERE tracking_id = ?";
	                    try (PreparedStatement statement = connection.prepareStatement(sql)) {
	                        // Set the employee ID as the parameter for the SQL query
	                        statement.setInt(1, credentialID);

	                        // Execute the query
	                        try (ResultSet resultSet = statement.executeQuery()) {
	                            if (resultSet.next()) { 
	                                // Retrieve and display data
	                                int contact = resultSet.getInt("contact");
	                                String address = resultSet.getString("address");
	                                int age = resultSet.getInt("age");
	                                String birthday = resultSet.getString("birthday");
	                                String gender = resultSet.getString("gender");
	                                String primary = resultSet.getString("elementary");
	                                String secondary = resultSet.getString("highschool");
	                                String college = resultSet.getString("college");
	                                String language = resultSet.getString("lanugae");
	                                String frameworks = resultSet.getString("frameworks");
	                                String tools = resultSet.getString("tools");
	                                String workexperience = resultSet.getString("workexperince");
	                                String applyingjob = resultSet.getString("applyingJob");
	                                

	                                // Set data to labels or whatever UI components you're using
	                                idpane.setText(String.valueOf(credentialID));
	                                contactpane.setText(String.valueOf(contact)); 
	                                addresspane.setText(address);
	                                agepane.setText(String.valueOf(age)); 
	                                birthpane.setText(birthday);
	                                genderpane.setText(gender);
	                                primarypane.setText(primary); 
	                                secondarypane.setText(secondary);
	                                collegepane.setText(college);
	                                languagepane.setText(language);
	                                frameworkpane.setText(frameworks);
	                                toolspane.setText(tools);
	                                workexperiencenpane.setText(workexperience);
	                                applyingjobspane.setText(applyingjob);
	                            }
	                        }
	                    }
	                }
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(null, "Error: Failed to retrieve data from the database.", "Error", JOptionPane.ERROR_MESSAGE);
	        }
	    }
	}
	
	// Method to delete data from the selected row in the table and the database
	private void deleteSQLdata() {
	    int selectedRow = table.getSelectedRow();
	    if (selectedRow != -1) { // If a row is selected
	        try {
	            String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
	            Connection connection = DriverManager.getConnection(url);

	            // Assuming the Employee table has primary key e_id
	            int employeeID = (int) table.getValueAt(selectedRow, 0);

	            // Remove the selected row from the table
	            DefaultTableModel model = (DefaultTableModel) table.getModel();
	            model.removeRow(selectedRow);

	            // Delete data from the database
	            String sql = "DELETE FROM Tracking WHERE tracking_id = ?";
	            PreparedStatement statement = connection.prepareStatement(sql);
	            statement.setInt(1, employeeID);
	            statement.executeUpdate();

	            // Close the statement and connection
	            statement.close();
	            connection.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(null, "Error: Failed to delete data from the database.", "Error", JOptionPane.ERROR_MESSAGE);
	        }
	    }
	}
	 // method for retrive image from sql
	private void loadProfileIcon() {
	    int selectedRow = table.getSelectedRow();
	    if (selectedRow != -1) { // If a row is selected
	        try {
	            // Load the JDBC driver class
	            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

	            // Define the JDBC URL
	            String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";

	            // Establish the database connection
	            try (Connection connection = DriverManager.getConnection(url)) {
	                // Prepare the SQL statement to retrieve the profile image based on the employee ID of the selected row
	                String sql = "SELECT profileImage FROM Tracking WHERE tracking_id = ?";
	                try (PreparedStatement statement = connection.prepareStatement(sql)) {
	                    // Get the employee ID of the selected row
	                    int employeeID = (int) table.getValueAt(selectedRow, 0);
	                    // Set the employee ID as the parameter for the SQL query
	                    statement.setInt(1, employeeID);

	                    // Execute the query
	                    try (ResultSet resultSet = statement.executeQuery()) {
	                        if (resultSet.next()) { 
	                            // Retrieve and display the profile image
	                             imageData = resultSet.getBytes("profileImage");
	                            if (imageData != null && imageData.length > 0) {
	                                try (ByteArrayInputStream bis = new ByteArrayInputStream(imageData)) {
	                                    BufferedImage bufferedImage = ImageIO.read(bis);
	                                    if (bufferedImage != null) {
	                                        Image scaledImage = bufferedImage.getScaledInstance(lblprofile.getWidth(), lblprofile.getHeight(), Image.SCALE_SMOOTH); 
	                                        lblprofile.setIcon(new ImageIcon(scaledImage));
	                                    } else {
	                                        System.out.println("Failed to read image data from the database.");
	                                    }
	                                }
	                            } else {
	                                System.out.println("Image data retrieved from the database is null or empty.");
	                            }
	                        } else {
	                            System.out.println("No image data found for the specified employee ID.");
	                        }
	                    }
	                }
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	}
	// method for inherit the text form all textpane and inherit image
	private void openInterviewFrame(byte[] imageData) {
	    String fullName = fullnamepane.getText();
	    String applyingJob = applyingjobspane.getText();
	    String email = emailpane.getText();
	    String contact = contactpane.getText();

	    InterviewFrame interviewFrame = new InterviewFrame(fullName, applyingJob, email, contact, imageData);
	    interviewFrame.setVisible(true);
	}

	private class PanelButtonMouseAdapter extends MouseAdapter{
		JPanel panel;
		
		public PanelButtonMouseAdapter(JPanel panel) {
			this.panel = panel;
		}
		
		public void mouseEntered(MouseEvent e) {
			panel.setBackground(new Color(240, 240, 240));
		}
		
		public void mouseExited(MouseEvent e) {
			panel.setBackground(new Color(255, 255, 255));
		}
		
		public void mousePressed(MouseEvent e) {
			panel.setBackground(new Color(240, 240, 240));
		}
		
		public void mouseReleased(MouseEvent e) {
			panel.setBackground(new Color(240, 240, 240));
		}
	}
}