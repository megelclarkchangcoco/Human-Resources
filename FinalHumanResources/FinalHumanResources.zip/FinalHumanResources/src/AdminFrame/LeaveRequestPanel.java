package AdminFrame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextPane;
import javax.swing.border.LineBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;

public class LeaveRequestPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTable table;
	private  JTextPane fullnamepane, idpane, datetopane, datefrompane, reasonpane;
	private JLabel lblprofile;

	/**
	 * Create the panel.
	 */
	public LeaveRequestPanel() {
		setLayout(null);
		setBounds(217,76,1217,688);
		setOpaque(false);
		
		JPanel bodypanel = new JPanel(); 
		bodypanel.setBackground(new Color(255, 255, 255));
		bodypanel.setBounds(0,0,1217,688);
		add(bodypanel);
		bodypanel.setLayout(null);
		 
		JLabel lblleaverequest = new JLabel("Leave Request");
		lblleaverequest.setForeground(new Color(55, 75, 86));
		lblleaverequest.setFont(new Font("Inter", Font.BOLD, 38));
		lblleaverequest.setBounds(35, 11, 343, 58);
		bodypanel.add(lblleaverequest);
		
		JPanel tablepanel = new JPanel(); 
		tablepanel.setBackground(new Color(255, 255, 255));
		tablepanel.setBounds(35, 80, 589, 525);
		bodypanel.add(tablepanel);
		tablepanel.setLayout(new BorderLayout()); // Use BorderLayout for proper component placement

		// Create a JScrollPane and add the JTable to it
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBackground(Color.WHITE);
		scrollPane.setOpaque(false);
		scrollPane.setBounds(0, 0, 525, 525);
		tablepanel.add(scrollPane, BorderLayout.CENTER);

		 table = new JTable();
		table.setShowGrid(false);
		table.setFont(new Font("Inter", Font.PLAIN, 12));
		table.setShowVerticalLines(false);
		table.setRowHeight(30);
		table.setModel(new DefaultTableModel( 
			new Object[][] {
				
			},
			new String[] {
				"  Employee ID", "  Lastname", "  Firstname", "Date To", "Date From", "Reason", "Status"
			}
		));
		populateLeaveTable();
		scrollPane.setViewportView(table); // Set the JTable as the view of the scroll pane
		
		
		JSeparator separator = new JSeparator();
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setBounds(634, 39, 24, 638);
		bodypanel.add(separator);
		
		 lblprofile = new JLabel("");
		lblprofile.setBounds(723, 80, 130, 113);
		bodypanel.add(lblprofile);
		
		JLabel lblfullname = new JLabel("Fullname     :");
		lblfullname.setFont(new Font("Inter", Font.PLAIN, 12));
		lblfullname.setBounds(723, 231, 76, 26);
		bodypanel.add(lblfullname);
		
		 fullnamepane = new JTextPane();
		 fullnamepane.setEditable(false);
		fullnamepane.setFont(new Font("Inter", Font.BOLD, 16));
		fullnamepane.setBounds(797, 231, 410, 26);
		bodypanel.add(fullnamepane);
		
		JLabel lblId_1 = new JLabel("ID                  :");
		lblId_1.setFont(new Font("Inter", Font.PLAIN, 12));
		lblId_1.setBounds(723, 268, 76, 26);
		bodypanel.add(lblId_1);
		
		 idpane = new JTextPane();
		 idpane.setEditable(false);
		idpane.setFont(new Font("Inter", Font.BOLD, 16));
		idpane.setBounds(797, 268, 410, 26);
		bodypanel.add(idpane);
		
		JLabel lblDateTo_1 = new JLabel("Date to         :");
		lblDateTo_1.setFont(new Font("Inter", Font.PLAIN, 12));
		lblDateTo_1.setBounds(723, 305, 76, 26);
		bodypanel.add(lblDateTo_1);
		
		 datetopane = new JTextPane();
		 datetopane.setEditable(false);
		datetopane.setFont(new Font("Inter", Font.BOLD, 16));
		datetopane.setBounds(797, 305, 410, 26);
		bodypanel.add(datetopane);
		
		JLabel lblfullname_2_1 = new JLabel("Date From   :");
		lblfullname_2_1.setFont(new Font("Inter", Font.PLAIN, 12));
		lblfullname_2_1.setBounds(723, 342, 76, 26);
		bodypanel.add(lblfullname_2_1);
		
		 datefrompane = new JTextPane();
		 datefrompane.setEditable(false);
		datefrompane.setFont(new Font("Inter", Font.BOLD, 16));
		datefrompane.setBounds(797, 342, 410, 26);
		bodypanel.add(datefrompane);
		
		JLabel lblfullname_2_2 = new JLabel("Reason        :");
		lblfullname_2_2.setFont(new Font("Inter", Font.PLAIN, 12));
		lblfullname_2_2.setBounds(723, 376, 76, 26);
		bodypanel.add(lblfullname_2_2);
		
		 reasonpane = new JTextPane();
		 reasonpane.setEditable(false);
		reasonpane.setFont(new Font("Inter", Font.BOLD, 16));
		reasonpane.setBounds(797, 376, 410, 157);
		bodypanel.add(reasonpane);
		
		JPanel viewpanel = new JPanel();
		viewpanel.addMouseListener(new PanelButtonMouseAdapter(viewpanel) {
			@Override
			public void mouseClicked(MouseEvent e) {
				displaySelectedRowData();
				loadProfileIcon();
			}
		});
		viewpanel.setLayout(null);
		viewpanel.setBorder(new LineBorder(new Color(41, 75, 86)));
		viewpanel.setBackground(Color.WHITE);
		viewpanel.setBounds(652, 617, 121, 39);
		bodypanel.add(viewpanel);
		
		JLabel viewlbl = new JLabel("View");
		viewlbl.setForeground(new Color(41, 75, 86));
		viewlbl.setFont(new Font("Inter", Font.BOLD, 16));
		viewlbl.setBounds(33, 11, 89, 17);
		viewpanel.add(viewlbl);
		
		JPanel updatepanel = new JPanel();
		updatepanel.setLayout(null);
		updatepanel.setBorder(new LineBorder(new Color(41, 75, 86)));
		updatepanel.setBackground(Color.WHITE);
		updatepanel.setBounds(797, 617, 121, 39);
		updatepanel.addMouseListener(new PanelButtonMouseAdapter(updatepanel) {
            @Override
            public void mouseClicked(MouseEvent e) {
            	int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    String approvalStatus = "Approved"; // Or fetch the approval status from your UI
                    updateApprovalStatus(approvalStatus);
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a row from the table.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
		bodypanel.add(updatepanel);
		
		JLabel lblapprove = new JLabel("Approve");
		lblapprove.setForeground(new Color(41, 75, 86));
		lblapprove.setFont(new Font("Inter", Font.BOLD, 16));
		lblapprove.setBounds(26, 11, 94, 17);
		updatepanel.add(lblapprove);
		
		JPanel deletepanel = new JPanel();
		deletepanel.setLayout(null);
		deletepanel.setBorder(new LineBorder(new Color(41, 75, 86)));
		deletepanel.setBackground(Color.WHITE);
		deletepanel.setBounds(1086, 617, 121, 39);
		bodypanel.add(deletepanel);
		
		JLabel lblClear = new JLabel("Feedback");
		lblClear.setForeground(new Color(41, 75, 86));
		lblClear.setFont(new Font("Inter", Font.BOLD, 16));
		lblClear.setBounds(26, 11, 93, 17);
		deletepanel.add(lblClear);
		
		JPanel declinedpanel = new JPanel();
		declinedpanel.setLayout(null);
		declinedpanel.addMouseListener(new PanelButtonMouseAdapter(declinedpanel) {
            @Override
            public void mouseClicked(MouseEvent e) {
            	int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    String approvalStatus = "Declined"; // Or fetch the approval status from your UI
                    updateApprovalStatus2(approvalStatus);
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a row from the table.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
		declinedpanel.setBorder(new LineBorder(new Color(41, 75, 86)));
		declinedpanel.setBackground(Color.WHITE);
		declinedpanel.setBounds(942, 617, 121, 39);
		bodypanel.add(declinedpanel);
		
		JLabel lbdeclined = new JLabel("Declined");
		lbdeclined.setForeground(new Color(41, 75, 86));
		lbdeclined.setFont(new Font("Inter", Font.BOLD, 16));
		lbdeclined.setBounds(24, 11, 94, 17);
		declinedpanel.add(lbdeclined);
	}
	// method for display sql table data to Jtable
	private void populateLeaveTable() {
	    try {
	        String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
	        Connection connection = DriverManager.getConnection(url);

	        String sql = "SELECT leave_id, leave_lname, leave_fname, leave_status, leave_toDate, leave_fromDate, leave_reason FROM Leave";
	        PreparedStatement statement = connection.prepareStatement(sql);
	        ResultSet resultSet = statement.executeQuery();

	        DefaultTableModel model = (DefaultTableModel) table.getModel();
	        model.setRowCount(0); // Clear existing data
	        while (resultSet.next()) {
	            int leaveID = resultSet.getInt("leave_id");
	            String lastName = resultSet.getString("leave_lname");
	            String firstName = resultSet.getString("leave_fname"); 
	            String status = resultSet.getString("leave_status");
	            String toDate = resultSet.getString("leave_toDate");
	            String fromDate = resultSet.getString("leave_fromDate");
	            String reason = resultSet.getString("leave_reason");
	            model.addRow(new Object[]{leaveID, lastName, firstName, toDate, fromDate, reason, status});
	        }

	        resultSet.close();
	        statement.close();
	        connection.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error: Failed to retrieve data from the database.", "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
	// method for sql data table and get data from jtable and show textpane
	private void displaySelectedRowData() {
	    int selectedRow = table.getSelectedRow();
	    if (selectedRow != -1) {
	        int leaveID = (int) table.getValueAt(selectedRow, 0);
	        String lastName = (String) table.getValueAt(selectedRow, 1);
	        String firstName = (String) table.getValueAt(selectedRow, 2);	     
	        String toDate = (String) table.getValueAt(selectedRow, 3);
	        String fromDate = (String) table.getValueAt(selectedRow, 4);
	        String reason = (String) table.getValueAt(selectedRow, 5);
	        String status = (String) table.getValueAt(selectedRow, 6);

	        // Display data in text panes or wherever you want
	        idpane.setText(String.valueOf(leaveID));
	        fullnamepane.setText(lastName + ", " + firstName);
	        datetopane.setText(toDate);
	        datefrompane.setText(fromDate);
	        reasonpane.setText(reason);
	       // statuspane.setText(status);
	    }
	}

	private void updateApprovalStatus(String approvalStatus) {
	    int selectedRow = table.getSelectedRow();
	    if (selectedRow != -1) {
	        int leaveID = (int) table.getValueAt(selectedRow, 0);
	        try {
	            String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
	            Connection connection = DriverManager.getConnection(url);

	            String sql = "UPDATE Leave SET leave_status = ? WHERE leave_id = ?";
	            PreparedStatement statement = connection.prepareStatement(sql);
	            statement.setString(1, approvalStatus);
	            statement.setInt(2, leaveID);
	            int rowsUpdated = statement.executeUpdate();

	            if (rowsUpdated > 0) {
	                // Update was successful
	                JOptionPane.showMessageDialog(null, "Approval status updated successfully.");
	                // Refresh the JTable to reflect the changes
	                populateLeaveTable();
	            } else {
	                // No rows were updated
	                JOptionPane.showMessageDialog(null, "Failed to update approval status.");
	            }

	            statement.close();
	            connection.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(null, "Error: Failed to update approval status.", "Error", JOptionPane.ERROR_MESSAGE);
	        }
	    }
	}
	
	private void updateApprovalStatus2(String approvalStatus) {
	    int selectedRow = table.getSelectedRow();
	    if (selectedRow != -1) {
	        int leaveID = (int) table.getValueAt(selectedRow, 0);
	        try {
	            String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
	            Connection connection = DriverManager.getConnection(url);

	            String sql = "UPDATE Leave SET leave_status = ? WHERE leave_id = ?";
	            PreparedStatement statement = connection.prepareStatement(sql);
	            statement.setString(1, approvalStatus);
	            statement.setInt(2, leaveID);
	            int rowsUpdated = statement.executeUpdate();

	            if (rowsUpdated > 0) {
	                // Update was successful
	                JOptionPane.showMessageDialog(null, "Decllined status updated successfully.");
	                // Refresh the JTable to reflect the changes
	                populateLeaveTable();
	            } else {
	                // No rows were updated
	                JOptionPane.showMessageDialog(null, "Failed to update approval status.");
	            }

	            statement.close();
	            connection.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(null, "Error: Failed to update approval status.", "Error", JOptionPane.ERROR_MESSAGE);
	        }
	    }
	}

	
	// method for retrive image from sql
    private void loadProfileIcon() {

        try {
            // Load the JDBC driver class
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            // Define the JDBC URL
            String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";

            // Establish the database connection
            try (Connection connection = DriverManager.getConnection(url)) {
                // Prepare the SQL statement
                String sql = "SELECT e_profile FROM Employee WHERE e_id = ?;";
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setInt(1, 1); // Assuming the ID of the image you want to retrieve is 1

                    // Execute the query
                    try (ResultSet resultSet = statement.executeQuery()) {
                        if (resultSet.next()) { 
                            // Retrieve the image data from the result set
                            byte[] imageData = resultSet.getBytes("e_profile");

                            if (imageData != null && imageData.length > 0) { // Check if image data is not null or empty
                                // Convert the byte array to a BufferedImage
                                try (ByteArrayInputStream bis = new ByteArrayInputStream(imageData)) {
                                    BufferedImage bufferedImage = ImageIO.read(bis);

                                    if (bufferedImage != null) { // Check if BufferedImage was successfully created
                                        // Resize the image to fit the JLabel
                                        Image scaledImage = bufferedImage.getScaledInstance(lblprofile.getWidth(), lblprofile.getHeight(), Image.SCALE_SMOOTH);

                                        // Set the scaled image to the JLabel
                                        lblprofile.setIcon(new ImageIcon(scaledImage));
//                                        System.out.println("Image data retrieved from the databas");
                                    } else {
                                        System.out.println("Failed to read image data from the database.");
                                    }
                                }
                            } else {
                                System.out.println("Image data retrieved from the database is null or empty.");
                            }
                        } else {
                            System.out.println("No image data found for the specified employee ID.");
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
	private void addRowSelectionListener() {
        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = table.getSelectedRow();
                    if (selectedRow != -1) {
                        // If a row is selected
                        int employeeID = (int) table.getValueAt(selectedRow, 0);
                        System.out.println("Selected Employee ID: " + employeeID);
                    }
                }
            }
        });
    }
	private class PanelButtonMouseAdapter extends MouseAdapter{
		JPanel panel;
		
		public PanelButtonMouseAdapter(JPanel panel) {
			this.panel = panel;
		}
		
		public void mouseEntered(MouseEvent e) {
			panel.setBackground(new Color(240, 240, 240));
		}
		
		public void mouseExited(MouseEvent e) {
			panel.setBackground(new Color(255, 255, 255));
		}
		
		public void mousePressed(MouseEvent e) {
			panel.setBackground(new Color(240, 240, 240));
		}
		
		public void mouseReleased(MouseEvent e) {
			panel.setBackground(new Color(240, 240, 240));
		}
	}
}
