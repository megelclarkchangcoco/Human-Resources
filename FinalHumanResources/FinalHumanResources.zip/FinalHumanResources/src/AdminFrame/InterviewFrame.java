package AdminFrame;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.imageio.ImageIO;
import com.toedter.calendar.JDateChooser;
import javax.swing.border.LineBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class InterviewFrame extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextPane fullnamepane;
    private JTextPane applyingjobpane;
    private JTextPane contactpane;
    private JTextPane emailpanes;
    private JLabel lblprofile;
    private JTextField locationfield;
    private JTextField timefield;
    private JLabel locationlbl, schedulelbl, timelbl;
    private JDateChooser scheduleChooser;
    private ImageIcon profileImageIcon; // Store the profile image icon
    private byte[] imageData;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    InterviewFrame frame = new InterviewFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public InterviewFrame() {
    	setTitle("Interview Schedule");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 495, 641);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JPanel bodypanel = new JPanel();
        bodypanel.setBackground(new Color(255, 255, 255));
        bodypanel.setBounds(0, 0, 487, 602);
        contentPane.add(bodypanel);
        bodypanel.setLayout(null);

        lblprofile = new JLabel("");
        lblprofile.setBounds(10, 81, 98, 94);
        bodypanel.add(lblprofile);

        JLabel lblNewLabel = new JLabel("Fullname");
        lblNewLabel.setBounds(151, 80, 63, 14);
        bodypanel.add(lblNewLabel);

        JLabel lblApplyingJob = new JLabel("Applying Job");
        lblApplyingJob.setBounds(151, 107, 84, 14);
        bodypanel.add(lblApplyingJob);

        JLabel lblContact = new JLabel("Contact");
        lblContact.setBounds(151, 132, 65, 14);
        bodypanel.add(lblContact);

        JLabel lblEmail = new JLabel("Email");
        lblEmail.setBounds(151, 157, 63, 14);
        bodypanel.add(lblEmail);

        fullnamepane = new JTextPane();
        fullnamepane.setEditable(false);
        fullnamepane.setBounds(248, 79, 163, 20);
        bodypanel.add(fullnamepane);

        applyingjobpane = new JTextPane();
        applyingjobpane.setEditable(false);
        applyingjobpane.setBounds(248, 106, 163, 20);
        bodypanel.add(applyingjobpane);

        contactpane = new JTextPane();
        contactpane.setEditable(false);
        contactpane.setBounds(248, 131, 163, 20);
        bodypanel.add(contactpane);

        emailpanes = new JTextPane();
        emailpanes.setEditable(false);
        emailpanes.setBounds(246, 156, 165, 20);
        bodypanel.add(emailpanes);

        JSeparator separator = new JSeparator();
        separator.setOrientation(SwingConstants.VERTICAL);
        separator.setBounds(236, 66, 2, 126);
        bodypanel.add(separator);
        
        JLabel lblInterviewSchedule = new JLabel("Interview Schedule");
        lblInterviewSchedule.setForeground(new Color(55, 75, 86));
        lblInterviewSchedule.setFont(new Font("Inter", Font.BOLD, 38));
        lblInterviewSchedule.setBounds(41, 11, 408, 58);
        bodypanel.add(lblInterviewSchedule);
        
        JSeparator separator_1 = new JSeparator();
        separator_1.setBounds(22, 206, 455, 2);
        bodypanel.add(separator_1);
        
        JLabel lblLocation = new JLabel("Location");
        lblLocation.setForeground(new Color(55, 75, 86));
        lblLocation.setFont(new Font("Inter", Font.BOLD, 20));
        lblLocation.setBounds(45, 217, 112, 52);
        bodypanel.add(lblLocation);
        
        JLabel lblSchedule = new JLabel("Schedule");
        lblSchedule.setForeground(new Color(55, 75, 86));
        lblSchedule.setFont(new Font("Inter", Font.BOLD, 20));
        lblSchedule.setBounds(43, 331, 112, 44);
        bodypanel.add(lblSchedule);
        
        locationfield = new JTextField();
        locationfield.setBounds(45, 261, 389, 44);
        bodypanel.add(locationfield);
        locationfield.setColumns(10);
        
         scheduleChooser = new JDateChooser();
        scheduleChooser.setForeground(Color.BLACK);
        scheduleChooser.setBounds(45, 373, 389, 43);
        bodypanel.add(scheduleChooser);
        
        timefield = new JTextField();
        timefield.setColumns(10);
        timefield.setBounds(45, 471, 389, 44);
        bodypanel.add(timefield);
        
        JLabel lblTime = new JLabel("Time");
        lblTime.setForeground(new Color(55, 75, 86));
        lblTime.setFont(new Font("Inter", Font.BOLD, 20));
        lblTime.setBounds(45, 427, 112, 52);
        bodypanel.add(lblTime);
        
        JPanel updatepanel = new JPanel();
        updatepanel.addMouseListener(new PanelButtonMouseAdapter(updatepanel) {
        	@Override
        	public void mouseClicked(MouseEvent e) {
//        		insertInterviewData(imageData);
        		saveIcon();
        		
        	}
        });
        updatepanel.setBorder(new LineBorder(new Color(55, 75, 86)));
        updatepanel.setBackground(new Color(255, 255, 255));
        updatepanel.setBounds(66, 553, 163, 38);
        bodypanel.add(updatepanel);
        updatepanel.setLayout(null);
        
        JLabel lblUpdate = new JLabel("Update");
        lblUpdate.setForeground(new Color(55, 75, 86));
        lblUpdate.setFont(new Font("Inter", Font.BOLD, 20));
        lblUpdate.setBounds(44, 0, 109, 38);
        updatepanel.add(lblUpdate);
        
         locationlbl = new JLabel("location is empty please fill up");
        locationlbl.setVisible(false);
        locationlbl.setForeground(new Color(255, 0, 0));
        locationlbl.setBounds(45, 306, 329, 14);
		bodypanel.add(locationlbl);
		
        schedulelbl = new JLabel("schedule date is empty please fill up");
		 schedulelbl.setVisible(false);
		schedulelbl.setForeground(new Color(255, 0, 0));
		schedulelbl.setBounds(45, 415, 329, 14);
		bodypanel.add(schedulelbl);
		
		  timelbl = new JLabel("time is empty please fill up");
		 timelbl.setVisible(false);
		 timelbl.setForeground(new Color(255, 0, 0));
		 timelbl.setBounds(45, 517, 329, 14);
		bodypanel.add(timelbl);
		
		JPanel closepanel = new JPanel();
		closepanel.addMouseListener(new PanelButtonMouseAdapter(closepanel) {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
		});
		closepanel.setLayout(null);
		closepanel.setBorder(new LineBorder(new Color(55, 75, 86)));
		closepanel.setBackground(Color.WHITE);
		closepanel.setBounds(248, 553, 163, 38);
		bodypanel.add(closepanel);
		
		JLabel lblClose = new JLabel("Close");
		lblClose.setForeground(new Color(55, 75, 86));
		lblClose.setFont(new Font("Inter", Font.BOLD, 20));
		lblClose.setBounds(44, 0, 109, 38);
		closepanel.add(lblClose);
    }
    	// method for display all data text from inherit
    public InterviewFrame(String fullName, String applyingJob, String email, String contact, byte[] imageData) {
        this(); // Call the default constructor to initialize the frame

        // Set values to text panes
        fullnamepane.setText(fullName);
        applyingjobpane.setText(applyingJob);
        contactpane.setText(contact);
        emailpanes.setText(email);

        // Set profile image
        if (imageData != null && imageData.length > 0) {
            try (ByteArrayInputStream bis = new ByteArrayInputStream(imageData)) {
                BufferedImage bufferedImage = ImageIO.read(bis);
                if (bufferedImage != null) {
                    Image scaledImage = bufferedImage.getScaledInstance(lblprofile.getWidth(), lblprofile.getHeight(), Image.SCALE_SMOOTH);
                    profileImageIcon = new ImageIcon(scaledImage); // Store the profile image icon
                    lblprofile.setIcon(profileImageIcon);
                } else {
                    System.out.println("Failed to read image data from the database.");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("Image data retrieved from the database is null or empty.");
        }
    }
    	// method fod
  		private void saveIcon() {
  			 // Get the icon from lblprofile
             Icon icon = lblprofile.getIcon();
             if (icon instanceof ImageIcon) {
                 ImageIcon imageIcon = (ImageIcon) icon;
                 // Extract image data from ImageIcon
                 Image image = imageIcon.getImage();
                 BufferedImage bufferedImage = new BufferedImage(image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_INT_ARGB);
                 Graphics2D g2 = bufferedImage.createGraphics();
                 g2.drawImage(image, 0, 0, null);
                 g2.dispose();
                 try {
                     // Convert BufferedImage to byte array
                     ByteArrayOutputStream baos = new ByteArrayOutputStream();
                     ImageIO.write(bufferedImage, "png", baos);
                     byte[] imageData = baos.toByteArray();
                     // Call the insertInterviewData method with image data
                     insertInterviewData(imageData);
                 } catch (IOException ex) {
                     ex.printStackTrace();
                 }
             } else {
                 System.out.println("No image found in lblprofile.");
             }
  		}
    
    	// method for save update in sql
 		private void insertInterviewData(byte[] profileImage) {
 		    try {
 		        // Load the JDBC driver class
 		        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

 		        // Define the JDBC URL
 		        String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";

 		        // Establish the database connection
 		        try (Connection connection = DriverManager.getConnection(url)) {
 		        	// Retrieve data from fields
 		            String fullname = fullnamepane.getText();
 		            String applyjob = applyingjobpane.getText();
 		            String contact = contactpane.getText();
 		            String emailpane = emailpanes.getText();
 		            String location = locationfield.getText();
 		            Date scheduleDate = scheduleChooser.getDate();
 		            String time = timefield.getText();
	 		       String startDateStr = new SimpleDateFormat("yyyy-MM-dd").format(scheduleDate);

 		        
 		                if (scheduleDate == null){
 		                	schedulelbl.setVisible(true);
 		                	
 		                } 
 		                if(location == null) {
 		                	locationlbl.setVisible(true);
 		                	
 		                }
 		                if(time.isEmpty()) {
 		                	timelbl.setVisible(true);
 	                		
 	                	
 	                	}
 		                if(location.isEmpty() || scheduleDate == null ||  time.isEmpty()) {
 		                	locationlbl.setVisible(true);
 		                	schedulelbl.setVisible(true);
 		                	timelbl.setVisible(true);
 		                	return;
 		                }
 		                
 		               // Prepare statement to insert data into Interview table
 		               String query = "INSERT INTO Interview (fullname, applyingjob, contact, email, location, schedule, profileImage) VALUES (?, ?, ?, ?, ?, ?,?)";
 		               try (PreparedStatement pstmt = connection.prepareStatement(query)) {
 		                   pstmt.setString(1, fullname);
 		                   pstmt.setString(2, applyjob);
 		                   pstmt.setString(3, contact);
 		                   pstmt.setString(4, emailpane);
 		                   pstmt.setString(5, location);
 		                   pstmt.setString(6, startDateStr + " "+ time); 
 		                  pstmt.setBytes(7, profileImage); // Set profile image data
 		                  

 		                   // Execute the query
 		                   int rowsAffected = pstmt.executeUpdate();
 		                   if (rowsAffected > 0) {
 		                       JOptionPane.showMessageDialog(null, "Interview data inserted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
 		                       dispose();
 		                   } else {
 		                       JOptionPane.showMessageDialog(null, "Failed to insert interview data.", "Error", JOptionPane.ERROR_MESSAGE);
 		                   }
 		               }
 		           }
 		        
 		    } catch (ClassNotFoundException | SQLException e) {
 		        e.printStackTrace();
 		        JOptionPane.showMessageDialog(null, "Error: Failed to update data in the database.", "Error", JOptionPane.ERROR_MESSAGE);
 		    }
 		}
 		
 		
 		private class PanelButtonMouseAdapter extends MouseAdapter{
			JPanel panel;
			
			public PanelButtonMouseAdapter(JPanel panel) {
				this.panel = panel;
			}
			
			public void mouseEntered(MouseEvent e) {
				panel.setBackground(new Color(240, 240, 240));
			}
			
			public void mouseExited(MouseEvent e) {
				panel.setBackground(new Color(255, 255, 255));
			}
			
			public void mousePressed(MouseEvent e) {
				panel.setBackground(new Color(240, 240, 240));
			}
			
			public void mouseReleased(MouseEvent e) {
				panel.setBackground(new Color(240, 240, 240));
			}
		}
}
