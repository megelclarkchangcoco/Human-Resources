package AdminFrame;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.beans.Statement;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
//import javax.xml.crypto.Data;

import java.awt.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PayrollPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private int selectedRow;
	private JTable table;
	private JTextField salaryfield;
	private JTextField deductionfield;
	private JTextField overtimefield;
	private JTextField taxfield;
	private JTextField firstnamefield;
	private JTextField sssfield;
	private JTextField philhealthfield;
	private JTextField pagibigfield;
	private JTextField absentfield;
	private JTextField undertimefield;
	private JTextField leavefield;
	private JTextField totalworkhourfield;

	/**
	 * Create the panel.
	 */
	public PayrollPanel() {
		setLayout(null);
		setBounds(217,76,1217,688);
		setOpaque(false);
		
		JPanel bodypabel = new JPanel();
		bodypabel.setLayout(null);
		bodypabel.setBackground(Color.WHITE);
		bodypabel.setBounds(0, 0, 1217, 688);
		add(bodypabel);
		
		JLabel lbldashboard_1 = new JLabel("Payroll");
		lbldashboard_1.setForeground(new Color(55, 75, 86));
		lbldashboard_1.setFont(new Font("Inter", Font.BOLD, 38));
		lbldashboard_1.setBounds(35, 11, 343, 58);
		bodypabel.add(lbldashboard_1);
		
		JPanel tablepanel = new JPanel();
		tablepanel.setBorder(new LineBorder(new Color(41, 75, 86)));
		tablepanel.setBackground(new Color(255, 255, 255));
		tablepanel.setBounds(20, 80, 1187, 337);
		bodypabel.add(tablepanel);
		tablepanel.setLayout(null);

		// Initialize JTable
		table = new JTable();
		table.setShowGrid(false);
		table.setFont(new Font("Inter", Font.PLAIN, 12));
		table.setShowVerticalLines(false);
		table.setRowHeight(30);
		table.setModel(new DefaultTableModel(
		    new Object[][]{{}},
		    new String[] {
		        "Work ID", "Date","Time in", "Break in", "Break out", "Check out", "Overtime", "Undertime", "Absent","Total Leave", "Total Work Hour", "Firstname", "Lastname"
		    }
		)); 
//		// Select rows 9 to 50 (indices are zero-based)
//		int startRow = 8; // Row 9 (index 8)
//		int endRow = 49; // Row 50 (index 49)
//
//		// Ensure the indices are within the table's bounds
//		if (startRow >= 0 && endRow < table.getRowCount()) {
//		    table.setRowSelectionInterval(startRow, endRow);
//		} else {
//		    System.out.println("Invalid row indices specified.");
//		}
		// Populate JTable with data from "Work" table
		displaySQLdatawork();
		// Create a JScrollPane and add the JTable to it
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBackground(Color.WHITE);
		scrollPane.setOpaque(false);
		scrollPane.setBounds(0, 0, 1187, 337); // Adjust the size accordingly
		tablepanel.add(scrollPane); // Add the scroll pane to the panel

		
		JPanel payslippanel = new JPanel();
		payslippanel.setBorder(new LineBorder(new Color(41, 75, 86)));
		payslippanel.setBackground(new Color(255, 255, 255));
		payslippanel.setBounds(20, 428, 1187, 197);
		bodypabel.add(payslippanel);
		payslippanel.setLayout(null);
		
		JLabel salarylbl = new JLabel("Salary");
		salarylbl.setFont(new Font("Inter Medium", Font.PLAIN, 13));
		salarylbl.setBounds(21, 117, 76, 27);
		payslippanel.add(salarylbl);
		
		JLabel lblOvertime = new JLabel("Deduction");
		lblOvertime.setFont(new Font("Inter Medium", Font.PLAIN, 13));
		lblOvertime.setBounds(316, 114, 68, 27);
		payslippanel.add(lblOvertime);
		
		JLabel overtimelbl = new JLabel("Overtime");
		overtimelbl.setFont(new Font("Inter Medium", Font.PLAIN, 13));
		overtimelbl.setBounds(316, 151, 76, 25);
		payslippanel.add(overtimelbl);
		
		JLabel lbldashboard_1_1 = new JLabel("Payslip");
		lbldashboard_1_1.setForeground(new Color(55, 75, 86));
		lbldashboard_1_1.setFont(new Font("Inter", Font.BOLD, 38));
		lbldashboard_1_1.setBounds(507, 11, 146, 58);
		payslippanel.add(lbldashboard_1_1);
		
		JSeparator separator = new JSeparator();
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setBounds(394, 71, 1, 103);
		payslippanel.add(separator);
		
		salaryfield = new JTextField();
		salaryfield.setBackground(new Color(255, 255, 255));
		salaryfield.setColumns(10);
		salaryfield.setBounds(107, 116, 178, 27);
		payslippanel.add(salaryfield);
		
		deductionfield = new JTextField();
		deductionfield.setBackground(new Color(255, 255, 255));
		deductionfield.setColumns(10);
		deductionfield.setBounds(405, 115, 178, 27);
		payslippanel.add(deductionfield);
		
		overtimefield = new JTextField();
		overtimefield.setBackground(new Color(255, 255, 255));
		overtimefield.setColumns(10);
		overtimefield.setBounds(405, 149, 178, 27);
		payslippanel.add(overtimefield);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setOrientation(SwingConstants.VERTICAL);
		separator_1.setBounds(305, 76, 1, 100);
		payslippanel.add(separator_1);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setOrientation(SwingConstants.VERTICAL);
		separator_2.setBounds(95, 75, 2, 100);
		payslippanel.add(separator_2);
		
		JLabel lblFirstName = new JLabel("First Name");
		lblFirstName.setFont(new Font("Inter Medium", Font.PLAIN, 13));
		lblFirstName.setBounds(21, 75, 76, 27);
		payslippanel.add(lblFirstName);
		
		JLabel totaltaxlbl = new JLabel("Tax");
		totaltaxlbl.setFont(new Font("Inter Medium", Font.PLAIN, 13));
		totaltaxlbl.setBounds(18, 153, 76, 27);
		payslippanel.add(totaltaxlbl);
		
		taxfield = new JTextField();
		taxfield.setColumns(10);
		taxfield.setBackground(Color.WHITE);
		taxfield.setBounds(107, 154, 178, 27);
		payslippanel.add(taxfield);
		
		firstnamefield = new JTextField();
		firstnamefield.setColumns(10);
		firstnamefield.setBackground(Color.WHITE);
		firstnamefield.setBounds(107, 80, 178, 27);
		payslippanel.add(firstnamefield);
		
		JLabel lblPagIbig = new JLabel("Pag - ibig");
		lblPagIbig.setFont(new Font("Inter Medium", Font.PLAIN, 13));
		lblPagIbig.setBounds(913, 79, 76, 27);
		payslippanel.add(lblPagIbig);
		
		JLabel lblPhilhealth = new JLabel("Philhealth");
		lblPhilhealth.setFont(new Font("Inter Medium", Font.PLAIN, 13));
		lblPhilhealth.setBounds(913, 117, 76, 27);
		payslippanel.add(lblPhilhealth);
		
		JSeparator separator_3 = new JSeparator();
		separator_3.setOrientation(SwingConstants.VERTICAL);
		separator_3.setBounds(988, 76, 2, 103);
		payslippanel.add(separator_3);
		
		JLabel lblSss = new JLabel("SSS");
		lblSss.setFont(new Font("Inter Medium", Font.PLAIN, 13));
		lblSss.setBounds(913, 155, 68, 27);
		payslippanel.add(lblSss);
		
		sssfield = new JTextField();
		sssfield.setColumns(10);
		sssfield.setBackground(Color.WHITE);
		sssfield.setBounds(999, 158, 178, 27);
		payslippanel.add(sssfield);
		
		philhealthfield = new JTextField();
		philhealthfield.setColumns(10);
		philhealthfield.setBackground(Color.WHITE);
		philhealthfield.setBounds(999, 121, 178, 27);
		payslippanel.add(philhealthfield);
		
		pagibigfield = new JTextField();
		pagibigfield.setColumns(10);
		pagibigfield.setBackground(Color.WHITE);
		pagibigfield.setBounds(999, 83, 178, 27);
		payslippanel.add(pagibigfield);
		
		JSeparator separator_1_1 = new JSeparator();
		separator_1_1.setOrientation(SwingConstants.VERTICAL);
		separator_1_1.setBounds(593, 76, 2, 103);
		payslippanel.add(separator_1_1);
		
		JLabel absentlbl = new JLabel("Absent");
		absentlbl.setFont(new Font("Inter Medium", Font.PLAIN, 13));
		absentlbl.setBounds(605, 154, 76, 25);
		payslippanel.add(absentlbl);
		
		absentfield = new JTextField();
		absentfield.setColumns(10);
		absentfield.setBackground(Color.WHITE);
		absentfield.setBounds(694, 152, 178, 27);
		payslippanel.add(absentfield);
		
		JLabel leavelbl = new JLabel("Leave Pay");
		leavelbl.setFont(new Font("Inter Medium", Font.PLAIN, 13));
		leavelbl.setBounds(605, 117, 68, 27);
		payslippanel.add(leavelbl);
		
		JLabel undertimelbl = new JLabel("Undertime");
		undertimelbl.setFont(new Font("Inter Medium", Font.PLAIN, 13));
		undertimelbl.setBounds(605, 79, 76, 27);
		payslippanel.add(undertimelbl);
		
		JSeparator separator_4 = new JSeparator();
		separator_4.setOrientation(SwingConstants.VERTICAL);
		separator_4.setBounds(683, 74, 1, 103);
		payslippanel.add(separator_4);
		
		undertimefield = new JTextField();
		undertimefield.setColumns(10);
		undertimefield.setBackground(Color.WHITE);
		undertimefield.setBounds(694, 81, 178, 27);
		payslippanel.add(undertimefield);
		
		leavefield = new JTextField();
		leavefield.setColumns(10);
		leavefield.setBackground(Color.WHITE);
		leavefield.setBounds(694, 118, 178, 27);
		payslippanel.add(leavefield);
		
		JSeparator separator_1_1_1 = new JSeparator();
		separator_1_1_1.setOrientation(SwingConstants.VERTICAL);
		separator_1_1_1.setBounds(882, 79, 2, 103);
		payslippanel.add(separator_1_1_1);
		
		JLabel lblTotalHour = new JLabel("Total Hour");
		lblTotalHour.setFont(new Font("Inter Medium", Font.PLAIN, 13));
		lblTotalHour.setBounds(316, 80, 76, 27);
		payslippanel.add(lblTotalHour);
		
		totalworkhourfield = new JTextField();
		totalworkhourfield.setColumns(10);
		totalworkhourfield.setBackground(Color.WHITE);
		totalworkhourfield.setBounds(405, 83, 178, 27);
		payslippanel.add(totalworkhourfield);
		
		JPanel checkpanels = new JPanel();
		checkpanels.setBorder(new LineBorder(new Color(55, 75, 86)));
		checkpanels.addMouseListener(new PanelButtonMouseAdapter(checkpanels) {
			@Override
			public void mouseClicked(MouseEvent e) {
				calculateSalaryAndDeductions();

			}
		});
		checkpanels.setBackground(new Color(255, 255, 255));
		checkpanels.setBounds(322, 636, 157, 41);
		bodypabel.add(checkpanels);
		checkpanels.setLayout(null);
		
		JLabel lblcheck = new JLabel("Check");
		lblcheck.setFont(new Font("Inter Medium", Font.BOLD, 15));
		lblcheck.setBounds(45, 0, 99, 41);
		checkpanels.add(lblcheck);
		
		JPanel printpnale = new JPanel();
		printpnale.setBorder(new LineBorder(new Color(55, 75, 86)));
		printpnale.setBackground(new Color(255, 255, 255));
		printpnale.addMouseListener(new PanelButtonMouseAdapter(printpnale) {
			@Override
			public void mouseClicked(MouseEvent e) {
				// Check if a row is selected
		        if (table.getSelectedRow() != -1) {
		            // Get the selected row index
		            selectedRow = table.getSelectedRow();
		            
		            // Call methods to save salary and delete row
		            saveSalaryToDatabase();
		            deleteSelectedRowAndData(selectedRow);
		        } else {
		            JOptionPane.showMessageDialog(null, "Please select a row to delete.", "Error", JOptionPane.ERROR_MESSAGE);
		        }

			}
		});
		printpnale.setBounds(520, 636, 157, 41);
		bodypabel.add(printpnale);
		printpnale.setLayout(null);
		
		JLabel lblprint = new JLabel("Print");
		lblprint.setFont(new Font("Inter Medium", Font.BOLD, 15));
		lblprint.setBounds(51, 0, 83, 41);
		printpnale.add(lblprint);
		
		JPanel clearpanel = new JPanel();
		clearpanel.setBorder(new LineBorder(new Color(55, 75, 86)));
		clearpanel.addMouseListener(new PanelButtonMouseAdapter(clearpanel) {
			@Override
			public void mouseClicked(MouseEvent e) {
				clearText();
				
			}
		});
		clearpanel.setBackground(new Color(255, 255, 255));
		clearpanel.setBounds(726, 636, 157, 41);
		bodypabel.add(clearpanel);
		clearpanel.setLayout(null);
		
		JLabel lblClear = new JLabel("Clear");
		lblClear.setFont(new Font("Inter Medium", Font.BOLD, 15));
		lblClear.setBounds(55, 0, 72, 41);
		clearpanel.add(lblClear);
		
		
	}
	
	// method display Work and Leave Data in JTABLE
	private void displaySQLdatawork() {
	    try {
	        String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
	        Connection connection = DriverManager.getConnection(url);
	        
	        // Execute the first SQL query to fetch data from the Work table
	        String sql = "SELECT * FROM Work";
	        PreparedStatement statement = connection.prepareStatement(sql);
	        ResultSet resultSet = statement.executeQuery();
	        
	        DefaultTableModel tablemodel = new DefaultTableModel(new String[] {
	            "Work ID", "Date", "Time in", "Break in", "Break out", "Check out", "Overtime", "Undertime", "Absent","Total Leave", "Total Work Hour", "Firstname","Lastname"
	        }, 0);

	        // Process data from the Work table
	        while (resultSet.next()) {
	            int workID = resultSet.getInt("Work_id");
	            String date = resultSet.getString("w_date");
	            String timein = resultSet.getString("w_timein");
	            String breakin = resultSet.getString("w_breakin");
	            String breakout = resultSet.getString("w_breakout");
	            String timeout = resultSet.getString("w_timeout");
	            int overtime = resultSet.getInt("overtime");
	            int undertime = resultSet.getInt("undertime");
	            int totalofwork = resultSet.getInt("hoursdone");
	            int absent = resultSet.getInt("w_absent");
	            String totalofleave = "  ";
	            String fname = resultSet.getString("w_fname");
	            String lname = resultSet.getString("w_lname");

	            Object[] rowData = {workID, date, timein, breakin, breakout, timeout, overtime, undertime, absent,totalofleave, totalofwork, fname, lname};
	            tablemodel.addRow(rowData);
	        }

	        // Execute the second SQL query to fetch data from the Leave table with leave_status as 'Approved'
	        String sql2 = "SELECT * FROM Leave WHERE leave_status = 'Approved'";
	        PreparedStatement statement2 = connection.prepareStatement(sql2);
	        ResultSet resultSet2 = statement2.executeQuery();
	        
	        // Process data from the Leave table
	        while (resultSet2.next()) {
	            // Assuming leave-related columns from the Leave table
	            int leaveID = resultSet2.getInt("Leave_id");
	            int leaveTotalDays = resultSet2.getInt("leave_totalleaveday");
	            java.sql.Date date = resultSet2.getDate("leave_fromDate");
	            String leaveFname = resultSet2.getString("Leave_fname");
	            String leaveLname = resultSet2.getString("Leave_lname");
	            String spacing = " ";
	            
	            // Add leave-related data to the table model
	            Object[] leaveRowData = {leaveID, date, spacing, spacing,spacing,spacing,spacing,spacing,spacing,leaveTotalDays, spacing, leaveFname, leaveLname};
	            tablemodel.addRow(leaveRowData);
	        }
 
	        table.setModel(tablemodel);

	        // Create a TableCellRenderer to center-align the text
	        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
	        centerRenderer.setHorizontalAlignment(JLabel.CENTER); 

	        // Apply the renderer to all columns
	        for (int i = 0; i < table.getColumnCount(); i++) {
	            table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
	        }

	        resultSet.close();
	        statement.close();
	        resultSet2.close();
	        statement2.close();
	        connection.close();

	    } catch (Exception e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error: Failed to retrieve data from the database.", "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}

	private void calculateSalaryAndDeductions() {
	    try {
	        // Fetch work rate from SQL data
	        String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
	        Connection connection = DriverManager.getConnection(url);
	    
	     // Initialize variables to store total values 
	        int totalHours = 0;
	        int totalLeaveDays = 0; 
	        double totalSalary = 0; 
	        double totalOvertime = 0;
	        double totalAbsent = 0;
	        double totalUndertime = 0;
	        
	        // Get the selected rows 
	        

	        int[] selectedRows = table.getSelectedRows();
	        if (selectedRows.length == 0) {
	            JOptionPane.showMessageDialog(null, "Please select at least one row.", "Error", JOptionPane.ERROR_MESSAGE);
	            return;
	        }

	        
	        
	        for (int selectedRow : selectedRows) {
	            // Assuming the employee ID is stored in column index 0
	            int employeeID = Integer.parseInt(table.getValueAt(selectedRow, 0).toString());

	            // Fetch work rate from the "Employee" table
	            String sql = "SELECT e_workrate FROM Employee WHERE e_id = ?";
	            PreparedStatement statement = connection.prepareStatement(sql);
	            statement.setInt(1, employeeID);
	            ResultSet resultSet = statement.executeQuery();
	            
	            
	            // Check if the work rate exists for the employee
	            if (resultSet.next()) {
	            	
	                double workRate = resultSet.getDouble("e_workrate");

	             // Retrieve other necessary values from the table
	                String hoursDoneStr = table.getValueAt(selectedRow, 10) != null ? table.getValueAt(selectedRow, 10).toString().trim() : "";
	                String overtimeStr = table.getValueAt(selectedRow, 6) != null ? table.getValueAt(selectedRow, 6).toString().trim() : "";
	                String undertimeStr = table.getValueAt(selectedRow, 7) != null ? table.getValueAt(selectedRow, 7).toString().trim() : "";
	                String absentStr = table.getValueAt(selectedRow, 8) != null ? table.getValueAt(selectedRow, 8).toString().trim() : "";
	                String leaveStr = table.getValueAt(selectedRow, 9) != null ? table.getValueAt(selectedRow, 9).toString().trim() : "";
	                

	                int hoursDone = hoursDoneStr.isEmpty() ? 0 : Integer.parseInt(hoursDoneStr);
	                int overtime = overtimeStr.isEmpty() ? 0 : Integer.parseInt(overtimeStr);
	                int undertime = undertimeStr.isEmpty() ? 0 : Integer.parseInt(undertimeStr);
	                int absent = absentStr.isEmpty() ? 0 : Integer.parseInt(absentStr);
	                int leave = leaveStr.isEmpty() ? 0 : Integer.parseInt(leaveStr);

	                // Perform salary and deduction calculations
	                double salary = hoursDone * workRate;
	                double salary2 = overtime * workRate;
	                double deduction = undertime * workRate;

	                // Deduct the absent rate if the employee is absent
	                if (absent > 0) {
	                    // Assuming 1 day of absent = 8 hours of work
	                    double absentDeduction = absent * (workRate * 8);
	                    totalAbsent += absentDeduction;
	                } else {
	                    totalSalary += salary;
	                    totalOvertime += salary2;
	                }

	                // Calculate leave pay if the employee is on leave
	                if (leave > 0) {
	                    double leavePay = leave * (workRate * 8); // Assuming 1 day of leave = 8 hours of work
	                    totalLeaveDays += leave;
	                    totalSalary += leavePay;
	                } else {
	                    totalSalary += salary2;
	                    totalUndertime += deduction;
	                }
	                // Update total hours
	                totalHours += hoursDone + overtime;
	            } else {
	                // If work rate not found, skip this employee
	                continue;
	            }

	            resultSet.close();
	            statement.close();
	        }
	        // Calculate deductions
	        double pagibig = totalSalary * 0.03;
	        double sss = totalSalary * 0.045;
	        double philhealth = totalSalary * 0.05;
	        double totalTax = pagibig + sss + philhealth;

	        // Calculate the total salary after deductions
	        double netSalary = totalSalary - totalAbsent - totalUndertime - pagibig - sss - philhealth;
	        double totalDeduction = totalAbsent + totalUndertime + pagibig + sss + philhealth;
	        String firstName = table.getValueAt(selectedRows[0], 11).toString();
	        String lastName = table.getValueAt(selectedRows[0], 12).toString();


	        // Update text panes with calculated values
	        // Initialize text fields if necessary
	        firstnamefield.setText(table.getValueAt(selectedRows[0], 11) + " " + table.getValueAt(selectedRows[0], 12));
	        salaryfield.setText(String.valueOf(netSalary));
	        totalworkhourfield.setText(String.valueOf(totalHours));
	        leavefield.setText(String.valueOf(totalLeaveDays));
	        overtimefield.setText(String.valueOf(totalOvertime));
	        absentfield.setText(String.valueOf(totalAbsent));
	        undertimefield.setText(String.valueOf(totalUndertime));
	        deductionfield.setText(String.valueOf(totalDeduction));
	        pagibigfield.setText(String.valueOf(pagibig));
	        sssfield.setText(String.valueOf(sss));
	        philhealthfield.setText(String.valueOf(philhealth));
	        taxfield.setText(String.valueOf(totalTax)); 

	        connection.close();

	    } catch (SQLException e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error: Failed to retrieve data from the database.", "Error", JOptionPane.ERROR_MESSAGE);
	    } catch (NumberFormatException e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Invalid input format. Please enter numeric values for hours, overtime, undertime, absent, and leave fields.", "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}

	
	private void saveSalaryToDatabase() {
	    // Get the total salary from the salaryfield
	    String salaryText = salaryfield.getText().trim();

	    // Check if salary field is empty
	    if (salaryText.isEmpty()) {
	        JOptionPane.showMessageDialog(null, "Please enter a valid salary.", "Error", JOptionPane.ERROR_MESSAGE);
	        return;
	    }

	    Connection connection = null;
	    try {
	        // Connect to the database
	        String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
	        connection = DriverManager.getConnection(url);

	        // Get the selected rows
	        int[] selectedRows = table.getSelectedRows();

	        // Initialize a set to store unique combinations of first name and last name
	        Set<String> uniqueNames = new HashSet<>();

	        // Iterate through the selected rows
	        for (int selectedRow : selectedRows) {
	            // Get the leave value from the selected row
	            String leaveStr = table.getValueAt(selectedRow, 9).toString().trim();
	            int leave = leaveStr.isEmpty() ? 0 : Integer.parseInt(leaveStr);

	            // Get the first name and last name from the selected row
	            String firstName = table.getValueAt(selectedRow, 11).toString();
	            String lastName = table.getValueAt(selectedRow, 12).toString();
	            String fullName = firstName + " " + lastName;

	            // Prepare the SQL statement to update the total salary for employees with the same first name and last name
	            String updateSalaryQuery = "UPDATE Employee SET e_salary = ? WHERE e_fname = ? AND e_lname = ?";
	            String updateLeaveQuery = "UPDATE Employee SET e_leave = e_leave ";

	            // Increment or decrement e_leave based on the leave value
	            if (leave == 0) {
	                updateLeaveQuery += "+ 1";
	            } else {
	                updateLeaveQuery += "- 1";
	            }
	            updateLeaveQuery += " WHERE e_fname = ? AND e_lname = ?";

	            // Prepare the statement for updating salary
	            PreparedStatement updateSalaryStatement = connection.prepareStatement(updateSalaryQuery);
	            updateSalaryStatement.setDouble(1, Double.parseDouble(salaryText));
	            updateSalaryStatement.setString(2, firstName);
	            updateSalaryStatement.setString(3, lastName);

	            // Prepare the statement for updating leave
	            PreparedStatement updateLeaveStatement = connection.prepareStatement(updateLeaveQuery);
	            updateLeaveStatement.setString(1, firstName);
	            updateLeaveStatement.setString(2, lastName);

	            // Execute the update statements
	            updateSalaryStatement.executeUpdate();
	            updateLeaveStatement.executeUpdate();

	            // Add the combination of first name and last name to the set to avoid duplicate updates
	            uniqueNames.add(fullName);

	            // Close the statements
	            updateSalaryStatement.close();
	            updateLeaveStatement.close();
	        }

	        // Remove selected rows from the table
	        DefaultTableModel model = (DefaultTableModel) table.getModel();
	        for (int i = selectedRows.length - 1; i >= 0; i--) {
	            model.removeRow(selectedRows[i]);
	        }

	        JOptionPane.showMessageDialog(null, "Total salary saved to database. e_leave updated accordingly.", "Success", JOptionPane.INFORMATION_MESSAGE);
	    } catch (NumberFormatException ex) {
	        JOptionPane.showMessageDialog(null, "Please enter a valid salary.", "Error", JOptionPane.ERROR_MESSAGE);
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error saving total salary to database: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    } finally {
	        if (connection != null) {
	            try {
	                connection.close();
	            } catch (SQLException ex) {
	                ex.printStackTrace();
	            }
	        }
	    }
	}


	private void deleteSelectedRowAndData(int selectedRow) { 
	    // Delete the selected row from the JTable
	    DefaultTableModel model = (DefaultTableModel) table.getModel();
	    
	    // Check if the selectedRow index is valid
	    if (selectedRow >= 0 && selectedRow < model.getRowCount()) {
	        // Get the value of the "Total Leave" column
	        String totalLeaveStr = table.getValueAt(selectedRow, 9).toString().trim();

	        // Check if the row corresponds to leave data
	        if (!totalLeaveStr.isEmpty()) {
	            try {
	                String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
	                Connection connection = DriverManager.getConnection(url);

	                // Assuming leave ID is stored in column index 0 for leave table
	                int leaveID = Integer.parseInt(table.getValueAt(selectedRow, 0).toString());

	                // Prepare the SQL statement to update the leave_totalleaveday column to null
	                String updateQuery = "UPDATE Leave SET leave_totalleaveday = NULL WHERE leave_id = ?";
	                PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
	                updateStatement.setInt(1, leaveID);

	                // Execute the update statement for leave data
	                updateStatement.executeUpdate();

	                // Close resources
	                updateStatement.close();
	                connection.close();

	                // Remove the selected row from the table model
	                model.removeRow(selectedRow);

	                // Inform the user about the successful deletion
	                JOptionPane.showMessageDialog(null, "Row deleted from the table and leave_totalleaveday column updated.", "Success", JOptionPane.INFORMATION_MESSAGE);

	            } catch (SQLException ex) {
	                ex.printStackTrace();
	                JOptionPane.showMessageDialog(null, "Error updating leave_totalleaveday column in the database: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	            }
	        } else {
	            JOptionPane.showMessageDialog(null, "Please select a row with leave data.", "Error", JOptionPane.ERROR_MESSAGE);
	        }
	    } else {
	        JOptionPane.showMessageDialog(null, "Invalid row index.", "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}

	
	// method for clear all text
	private void clearText() {
		// Clear all text fields
		firstnamefield.setText("");
		salaryfield.setText("");
		totalworkhourfield.setText("");
		leavefield.setText("");
		overtimefield.setText("");
		absentfield.setText("");
		undertimefield.setText("");
		deductionfield.setText("");
		pagibigfield.setText("");
		sssfield.setText("");
		philhealthfield.setText("");
		taxfield.setText("");

	}
	
	 private class PanelButtonMouseAdapter extends MouseAdapter{
			JPanel panel;
			
			public PanelButtonMouseAdapter(JPanel panel) {
				this.panel = panel;
			}
			
			public void mouseEntered(MouseEvent e) {
				panel.setBackground(new Color(240, 240, 240));
			}
			
			public void mouseExited(MouseEvent e) {
				panel.setBackground(new Color(255, 255, 255));
			}
			
			public void mousePressed(MouseEvent e) {
				panel.setBackground(new Color(240, 240, 240));
			}
			
			public void mouseReleased(MouseEvent e) {
				panel.setBackground(new Color(240, 240, 240));
			}
		}
}
