package AdminFrame;
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextPane;

public class sad extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JPanel panel;
    private int panelCount = 0;
    private JTextPane textPane;
    private boolean isEditable = true;
    private Connection connection;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    sad frame = new sad();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } 
        }); 
    }

    /**
     * Create the frame.
     */
    public sad() { 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1026, 762);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JButton addButton = new JButton("Add Panel");
        addButton.setBounds(41, 10, 120, 30);
        contentPane.add(addButton); 

        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(255, 255, 255));
        panel.setBounds(128, 129, 797, 552);
        contentPane.add(panel);

        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addPanel();
            }
        });
        
        
        connectToDatabase(); // Connect to the database
        loadPanelData(); // Load panel data when the frame is initialized
    }

    private void addPanel() {
        if (panelCount < 5) { // Limit addition to 5 panels
            adjustPanelPositions(); // Move existing panels down
            
            JPanel newPanel = new JPanel();
            newPanel.setLayout(null);

            // New panel position
            int yPos = 69;
            newPanel.setBounds(41, yPos, 461, 101);
            newPanel.setBackground(Color.WHITE);

            JTextPane newTextPane = new JTextPane();
            newTextPane.setBounds(41, 10, 178, 32);
            newTextPane.setForeground(Color.WHITE);
            newTextPane.setBackground(Color.BLACK);
            newPanel.add(newTextPane);

            JButton newSaveButton = new JButton("Save");
            newSaveButton.setBounds(41, 50, 120, 30);
            newPanel.add(newSaveButton);

            JButton newEditButton = new JButton("Edit");
            newEditButton.setBounds(180, 50, 120, 30);
            newPanel.add(newEditButton);

            JButton newDeleteButton = new JButton("Delete");
            newDeleteButton.setBounds(320, 50, 120, 30);
            newPanel.add(newDeleteButton);

            newSaveButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    String text = newTextPane.getText().trim();
                    if (text.isEmpty()) {
                        JOptionPane.showMessageDialog(sad.this, "Empty field", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        newTextPane.setEditable(false);
                        JOptionPane.showMessageDialog(sad.this, "Text saved successfully");
                        savePanelData(text); // Save panel data to database
                    }
                }
            });

            newEditButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    newTextPane.setEditable(true);
                }
            });

            newDeleteButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    panel.remove(newPanel);
                    panel.revalidate();
                    panel.repaint();
                    panelCount--;
                    adjustPanelPositions();
                    deletePanelData(newTextPane.getText()); // Delete panel data from database
                }
            });

            panel.add(newPanel);
            panel.revalidate();
            panel.repaint();
            panelCount++;
        } else {
            JOptionPane.showMessageDialog(sad.this, "Maximum panel limit reached", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void adjustPanelPositions() {
        Component[] components = panel.getComponents();
        int yPos = 69;
        for (int i = 0; i < components.length; i++) {
            if (components[i] instanceof JPanel) {
                JPanel existingPanel = (JPanel) components[i];
                existingPanel.setBounds(41, yPos, 461, 101);
                yPos += 150; // Increment yPos for the next panel
            }
        }
    }



    // Connect to the database
    private void connectToDatabase() {
        String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
        try {
            connection = DriverManager.getConnection(url);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Save panel data to database
    private void savePanelData(String text) {
        String query = "INSERT INTO jobposting(jobtitle) VALUES (?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, text);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete panel data from database
    private void deletePanelData(String text) {
        String query = "DELETE FROM jobposting WHERE jobtitle = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, text);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Load panel data from database
    private void loadPanelData() {
        String query = "SELECT jobtitle FROM jobposting";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                String text = resultSet.getString("jobtitle");
                addPanel(); // Add panel with loaded text
                JTextPane textPane = (JTextPane) ((JPanel) panel.getComponent(panel.getComponentCount() - 1)).getComponent(0);
                textPane.setText(text);
                textPane.setEditable(false); // Make text pane not editable
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
