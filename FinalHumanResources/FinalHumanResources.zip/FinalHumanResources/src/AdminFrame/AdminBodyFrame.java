package AdminFrame;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.Timer;
import javax.swing.border.LineBorder;

public class AdminBodyFrame extends JPanel {
	
	private ImageIcon employeeinfoicon2 = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\employees (1).png").getImage().getScaledInstance(87, 87, Image.SCALE_DEFAULT));
	private ImageIcon leaverequesticon2 = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\daily-calendar (2).png").getImage().getScaledInstance(87, 87, Image.SCALE_DEFAULT));
	private ImageIcon payrollicon2 = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\wallet-arrow.png").getImage().getScaledInstance(87, 87, Image.SCALE_DEFAULT));
	private ImageIcon intreviewicon2 = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\boss.png").getImage().getScaledInstance(87, 87, Image.SCALE_DEFAULT));
	private ImageIcon trainingicon2 = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\leadership-alt.png").getImage().getScaledInstance(87, 87, Image.SCALE_DEFAULT));
	private ImageIcon trackingicon2 = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\overview (1).png").getImage().getScaledInstance(87, 87, Image.SCALE_DEFAULT));

	private JLabel countelbl, countelbl2, countelbl3;
    private JLabel profilelbl, lblAdmin, lblfname;
	private static final long serialVersionUID = 1L;
	private JLabel lblrealtime, countelbl4,countelbl5;
    private JPanel bodyPanel;  

	/**
	 * Create the panel.
	 */
	public AdminBodyFrame() {
		setLayout(null); 
		setBounds(217,76,1217,688); 
		setOpaque(false);
		
		JPanel bodypabel = new JPanel();
		bodypabel.setLayout(null);
		bodypabel.setBackground(Color.WHITE);
		bodypabel.setBounds(0, 0, 1217, 688);
		add(bodypabel);
		
		JPanel smallbodypanel = new JPanel();
		smallbodypanel.setLayout(null);
		smallbodypanel.setOpaque(false);
		smallbodypanel.setBackground(Color.WHITE);
		smallbodypanel.setBounds(41, 61, 1149, 616);
		bodypabel.add(smallbodypanel);
		
		JPanel employeepanelcount = new JPanel();
		employeepanelcount.setLayout(null);
		employeepanelcount.setBorder(new LineBorder(new Color(55, 72, 86)));
		employeepanelcount.setBackground(Color.WHITE);
		employeepanelcount.setBounds(10, 75, 327, 109);
		smallbodypanel.add(employeepanelcount);
		
		JLabel employeecountlbl = new JLabel("");
		employeecountlbl.setIcon(employeeinfoicon2);
		employeecountlbl.setBounds(10, 11, 87, 87);
		employeepanelcount.add(employeecountlbl);
		
		JLabel lblTotalOfEmployee = new JLabel("Total Employee");
		lblTotalOfEmployee.setForeground(new Color(55, 75, 86));
		lblTotalOfEmployee.setFont(new Font("Inter", Font.BOLD, 20));
		lblTotalOfEmployee.setBounds(107, 0, 210, 58);
		employeepanelcount.add(lblTotalOfEmployee);
		
		 countelbl = new JLabel("");
		countelbl.setForeground(new Color(55, 75, 86));
		countelbl.setFont(new Font("Inter", Font.BOLD, 38));
		countelbl.setBounds(107, 40, 158, 58);
		employeepanelcount.add(countelbl);
		
		lblrealtime = new JLabel("");
		lblrealtime.setForeground(new Color(55, 75, 86));
		lblrealtime.setFont(new Font("Inter", Font.BOLD, 20));
		lblrealtime.setBounds(1020, 0, 129, 58);
		smallbodypanel.add(lblrealtime);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(10, 54, 1139, 2);
		smallbodypanel.add(separator_2);
		
		JPanel leaverequestcounttotal = new JPanel();
		leaverequestcounttotal.setLayout(null);
		leaverequestcounttotal.setBorder(new LineBorder(new Color(55, 72, 86)));
		leaverequestcounttotal.setBackground(Color.WHITE);
		leaverequestcounttotal.setBounds(422, 75, 327, 109);
		smallbodypanel.add(leaverequestcounttotal);
		
		JLabel leaverequestcountlbl = new JLabel("");
		leaverequestcountlbl.setIcon(leaverequesticon2);
		leaverequestcountlbl.setBounds(10, 11, 87, 87);
		leaverequestcounttotal.add(leaverequestcountlbl);
		
		JLabel leaverequestlbl = new JLabel("Leave Request");
		leaverequestlbl.setForeground(new Color(55, 75, 86));
		leaverequestlbl.setFont(new Font("Inter", Font.BOLD, 20));
		leaverequestlbl.setBounds(107, 0, 210, 58);
		leaverequestcounttotal.add(leaverequestlbl);
		
		 countelbl2 = new JLabel("");
		countelbl2.setForeground(new Color(55, 75, 86));
		countelbl2.setFont(new Font("Inter", Font.BOLD, 38));
		countelbl2.setBounds(107, 40, 158, 58);
		leaverequestcounttotal.add(countelbl2);
		
		JPanel interviewcountpanel = new JPanel();
		interviewcountpanel.setLayout(null);
		interviewcountpanel.setBorder(new LineBorder(new Color(55, 72, 86)));
		interviewcountpanel.setBackground(Color.WHITE);
		interviewcountpanel.setBounds(422, 231, 327, 109);
		smallbodypanel.add(interviewcountpanel);
		
		JLabel interviewcountlbl = new JLabel("");
		interviewcountlbl.setIcon(intreviewicon2	);
		interviewcountlbl.setBounds(10, 11, 87, 87);
		interviewcountpanel.add(interviewcountlbl);
		
		JLabel lblInterview = new JLabel("Interview");
		lblInterview.setForeground(new Color(55, 75, 86));
		lblInterview.setFont(new Font("Inter", Font.BOLD, 20));
		lblInterview.setBounds(107, 0, 210, 58);
		interviewcountpanel.add(lblInterview);
		
		 countelbl3 = new JLabel("");
		countelbl3.setForeground(new Color(55, 75, 86));
		countelbl3.setFont(new Font("Inter", Font.BOLD, 38));
		countelbl3.setBounds(107, 40, 158, 58);
		interviewcountpanel.add(countelbl3);
		
		JPanel Applicant = new JPanel();
		Applicant.setLayout(null);
		Applicant.setBorder(new LineBorder(new Color(55, 72, 86)));
		Applicant.setBackground(Color.WHITE);
		Applicant.setBounds(812, 231, 327, 109);
		smallbodypanel.add(Applicant);
		
		JLabel applicantcountlbl = new JLabel("");
		applicantcountlbl.setIcon(trackingicon2);
		applicantcountlbl.setBounds(10, 11, 87, 87);
		Applicant.add(applicantcountlbl);
		
		JLabel lblApplicant = new JLabel("Applicant");
		lblApplicant.setForeground(new Color(55, 75, 86));
		lblApplicant.setFont(new Font("Inter", Font.BOLD, 20));
		lblApplicant.setBounds(107, 0, 210, 58);
		Applicant.add(lblApplicant);
		
	    countelbl4 = new JLabel("");
		countelbl4.setForeground(new Color(55, 75, 86));
		countelbl4.setFont(new Font("Inter", Font.BOLD, 38));
		countelbl4.setBounds(107, 40, 158, 58);
		Applicant.add(countelbl4);
		
		JPanel trainingcountpanel = new JPanel();
		trainingcountpanel.setLayout(null);
		trainingcountpanel.setBorder(new LineBorder(new Color(55, 72, 86)));
		trainingcountpanel.setBackground(Color.WHITE);
		trainingcountpanel.setBounds(10, 231, 327, 109);
		smallbodypanel.add(trainingcountpanel);
		
		JLabel trainingcountlbl = new JLabel("");
		trainingcountlbl.setIcon(trainingicon2);
		trainingcountlbl.setBounds(10, 11, 87, 87);
		trainingcountpanel.add(trainingcountlbl);
		
		JLabel lblTraining = new JLabel("Training");
		lblTraining.setForeground(new Color(55, 75, 86));
		lblTraining.setFont(new Font("Inter", Font.BOLD, 20));
		lblTraining.setBounds(107, 0, 210, 58);
		trainingcountpanel.add(lblTraining);
		
		countelbl5 = new JLabel("");
		countelbl5.setForeground(new Color(55, 75, 86));
		countelbl5.setFont(new Font("Inter", Font.BOLD, 38));
		countelbl5.setBounds(107, 40, 158, 58);
		trainingcountpanel.add(countelbl5);
		
		JPanel payrollcountpanels = new JPanel();
		payrollcountpanels.setLayout(null);
		payrollcountpanels.setBorder(new LineBorder(new Color(55, 72, 86)));
		payrollcountpanels.setBackground(Color.WHITE);
		payrollcountpanels.setBounds(812, 75, 327, 109);
		smallbodypanel.add(payrollcountpanels);
		
		JLabel payrollcountlbl = new JLabel("");
		payrollcountlbl.setIcon(payrollicon2);
		payrollcountlbl.setBounds(10, 11, 87, 87);
		payrollcountpanels.add(payrollcountlbl);
		
		JLabel Lblpayroll = new JLabel("Payroll");
		Lblpayroll.setForeground(new Color(55, 75, 86));
		Lblpayroll.setFont(new Font("Inter", Font.BOLD, 20));
		Lblpayroll.setBounds(107, 0, 210, 58);
		payrollcountpanels.add(Lblpayroll);
		
		JLabel lblrealdate = new JLabel("2024-02-29");
		lblrealdate.setForeground(new Color(55, 75, 86));
		lblrealdate.setFont(new Font("Inter", Font.BOLD, 20));
		lblrealdate.setBounds(20, 0, 136, 58);
		smallbodypanel.add(lblrealdate);
		
		JLabel lbldashboard_1 = new JLabel("Dashboard");
		lbldashboard_1.setForeground(new Color(55, 75, 86));
		lbldashboard_1.setFont(new Font("Inter", Font.BOLD, 38));
		lbldashboard_1.setBounds(35, 11, 343, 58);
		bodypabel.add(lbldashboard_1);
		countData();
		updateTime();
	} 
	 // method for real time 
 	private void updateTime() {
 	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
 	    String currentTime = LocalTime.now().format(formatter);  
 	   lblrealtime.setText(currentTime);
 	}
	
	// countLeaveRequest method remains the same as you provided 
    private void countData() {
        String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";

        try (Connection connection = DriverManager.getConnection(url)) {
        	// Define sql query to count total of employee 
            String sqlemp ="SELECT COUNT(*) AS e_id FROM Employee";
            // Define SQL query to count leave requests
            String sqlleave = "SELECT COUNT(*) AS leave_count FROM Leave";
            
            String sqlTraining = "SELECT COUNT(*) AS training_id FROM Training";
            
            String sqlTracking = "SELECT COUNT(*) AS tracking_id FROM Tracking";
            
            String sqlInterview = "SELECT COUNT(*) AS interview_id FROM Interview";
            
            try (PreparedStatement stmt = connection.prepareStatement(sqlemp);
                    ResultSet rs = stmt.executeQuery()) {
                   // Retrieve and display the count leave request
                   if (rs.next()) {
                       int employeeCount = rs.getInt("e_id");
                       countelbl.setText(String.valueOf(employeeCount)); // Convert leaveCount to String
                   }
            	
            }
            // Prepare the statement
            try (PreparedStatement stmt2 = connection.prepareStatement(sqlleave);
                 ResultSet rs2 = stmt2.executeQuery()) {
                // Retrieve and display the count leave request
                if (rs2.next()) {
                    int leaveCount = rs2.getInt("leave_count");
                    countelbl2.setText(String.valueOf(leaveCount)); // Convert leaveCount to String
                }
            }
            
            try(PreparedStatement stmt3 = connection.prepareStatement(sqlTraining);
            	ResultSet rs3 = stmt3.executeQuery()){
            	
            	if(rs3.next()) {
            		int trainingCount = rs3.getInt("training_id");
            		countelbl5.setText(String.valueOf(trainingCount));
            	}
            }
            
            try(PreparedStatement stmt4 = connection.prepareStatement(sqlTracking);
            	ResultSet rs4 =  stmt4.executeQuery()){
            	
            	if(rs4.next()) {
            		int trackingCount = rs4.getInt("tracking_id");
            		countelbl4.setText(String.valueOf(trackingCount)); // Convert trackingCount to String
            	}
            	
            try(PreparedStatement stmt5 = connection.prepareStatement(sqlInterview);
                 ResultSet rs5 =  stmt5.executeQuery()){
                     	
                  if(rs5.next()) {
                     int trackingCount = rs5.getInt("interview_id");
                     countelbl3.setText(String.valueOf(trackingCount)); // Convert trackingCount to String
                  }
            		
            	}
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle any SQL exceptions
        } catch (Exception e) {
            e.printStackTrace();
            // Handle any other exceptions
        }
    }
}
