package AdminFrame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;

public class developmentPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTable table;
	private JTextPane fullnamepane, idpane, emailpane, designationpane;
	private JLabel lblprofile;
	private JTextField goalsfield;
	private JTextField feedbackfield;
	private JLabel lbldisplay ;
	private JTextField areasofimprovementsfield;


	/**
	 * Create the panel.
	 */
	public developmentPanel() { 
		setLayout(null);
		setBounds(217,76,1217,688);
		setOpaque(false);
		
		JPanel bodypanel = new JPanel(); 
		bodypanel.setBackground(new Color(255, 255, 255));
		bodypanel.setBounds(0,0,1217,688);
		add(bodypanel);
		bodypanel.setLayout(null);
		  
		JLabel lblemployeedata = new JLabel("Employee Data");
		lblemployeedata.setBounds(35, 11, 343, 58);
		lblemployeedata.setForeground(new Color(55, 75, 86));
		lblemployeedata.setFont(new Font("Inter", Font.BOLD, 38));
		bodypanel.add(lblemployeedata);
		
		JPanel tablepanel = new JPanel();
		tablepanel.setBounds(35, 80, 525, 525);
		tablepanel.setBackground(new Color(255, 255, 255));
		bodypanel.add(tablepanel);
		tablepanel.setLayout(new BorderLayout()); // Use BorderLayout for proper component placement

		// Create a JScrollPane and add the JTable to it
		JScrollPane scrollPane = new JScrollPane(); 
		scrollPane.setBackground(Color.WHITE);
		scrollPane.setOpaque(false);
		scrollPane.setBounds(0, 0, 525, 525);
		tablepanel.add(scrollPane, BorderLayout.CENTER);

		table = new JTable();
		table.setShowGrid(false);
		table.setFont(new Font("Inter", Font.PLAIN, 12));
		table.setShowVerticalLines(false);
		table.setRowHeight(30);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				
			},
			new String[] {
				"  Employee ID", "  Lastname", "  Firstname", "  Designation"
			}
		));
		table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
		    @Override
		    public void valueChanged(ListSelectionEvent e) {
		        if (!e.getValueIsAdjusting()) {
		            // Check if any row is selected
		            if (table.getSelectedRow() != -1) {
		                // Call the method to view data when a row is selected
		            	
		                viewSQLdata();
		                loadProfileIcon();
		                
		            }
		        }
		    }
		});
		// Assuming your table has already been configured
		scrollPane.setViewportView(table); // Set the JTable as the view of the scroll pane
		fetchDatainTable();
		
		JSeparator separator = new JSeparator();
		separator.setBounds(573, 39, 24, 638);
		separator.setOrientation(SwingConstants.VERTICAL);
		bodypanel.add(separator);
		
		JPanel viewpanel = new JPanel();
		viewpanel.setBounds(35, 616, 147, 39);
		viewpanel.addMouseListener(new PanelButtonMouseAdapter(viewpanel) {
			@Override
			public void mouseClicked(MouseEvent e) {
				viewSQLdata();
				loadProfileIcon();
			}
		});
		viewpanel.setBorder(new LineBorder(new Color(41, 75, 86)));
		viewpanel.setBackground(new Color(255, 255, 255));
		bodypanel.add(viewpanel);
		viewpanel.setLayout(null);
		
		JLabel viewlbl = new JLabel("View");
		viewlbl.setForeground(new Color(41, 75, 86));
		viewlbl.setFont(new Font("Inter", Font.BOLD, 16));
		viewlbl.setBounds(46, 11, 76, 17);
		viewpanel.add(viewlbl);
		
		JPanel updatepanel = new JPanel();
		updatepanel.setBounds(604, 616, 147, 39);
		updatepanel.addMouseListener(new PanelButtonMouseAdapter(updatepanel) {
			@Override
			public void mouseClicked(MouseEvent e) {
				updateColumnData();
				
			}
		});
		updatepanel.setBorder(new LineBorder(new Color(41, 75, 86)));
		updatepanel.setBackground(new Color(255, 255, 255));
		bodypanel.add(updatepanel);
		updatepanel.setLayout(null);
		
		JLabel lblUpdate = new JLabel("Update");
		lblUpdate.setForeground(new Color(41, 75, 86));
		lblUpdate.setFont(new Font("Inter", Font.BOLD, 16));
		lblUpdate.setBounds(42, 11, 76, 17);
		updatepanel.add(lblUpdate);
		
		JPanel deletepanel = new JPanel();
		deletepanel.setBounds(945, 616, 147, 39);
		deletepanel.addMouseListener(new PanelButtonMouseAdapter(deletepanel) {
			@Override
			public void mouseClicked(MouseEvent e) {
				clearData();
			}
		});
		deletepanel.setBorder(new LineBorder(new Color(41, 75, 86)));
		deletepanel.setBackground(new Color(255, 255, 255));
		bodypanel.add(deletepanel);
		deletepanel.setLayout(null);
		
		JLabel lblDelete = new JLabel("Clear");
		lblDelete.setForeground(new Color(41, 75, 86));
		lblDelete.setFont(new Font("Inter", Font.BOLD, 16));
		lblDelete.setBounds(43, 11, 76, 17);
		deletepanel.add(lblDelete);
		
		 lblprofile = new JLabel("");
		 lblprofile.setBounds(607, 43, 113, 107);
		bodypanel.add(lblprofile);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(607, 161, 532, 2);
		bodypanel.add(separator_1);
		
		 idpane = new JTextPane();
		 idpane.setBounds(817, 80, 330, 26);
		 idpane.setEditable(false);
		idpane.setFont(new Font("Inter", Font.BOLD, 16));
		bodypanel.add(idpane);
		
		 emailpane = new JTextPane();
		 emailpane.setBounds(817, 104, 330, 26);
		 emailpane.setEditable(false);
		emailpane.setFont(new Font("Inter", Font.BOLD, 16));
		bodypanel.add(emailpane);
		
		JLabel lblNewLabel_3_1_1_2_1 = new JLabel("Email                 :");
		lblNewLabel_3_1_1_2_1.setBounds(730, 104, 102, 26);
		lblNewLabel_3_1_1_2_1.setFont(new Font("Inter", Font.PLAIN, 12));
		bodypanel.add(lblNewLabel_3_1_1_2_1);
		
		JLabel lblNewLabel_3_1_1_1_1 = new JLabel("ID                       :");
		lblNewLabel_3_1_1_1_1.setBounds(730, 80, 102, 26);
		lblNewLabel_3_1_1_1_1.setFont(new Font("Inter", Font.PLAIN, 12));
		bodypanel.add(lblNewLabel_3_1_1_1_1);
		
		JLabel lblNewLabel_3_1_1_3_1 = new JLabel("Designation  :");
		lblNewLabel_3_1_1_3_1.setBounds(730, 129, 102, 26);
		lblNewLabel_3_1_1_3_1.setFont(new Font("Inter", Font.PLAIN, 12));
		bodypanel.add(lblNewLabel_3_1_1_3_1);
		
		 designationpane = new JTextPane();
		 designationpane.setBounds(817, 129, 330, 26);
		 designationpane.setEditable(false);
		designationpane.setFont(new Font("Inter", Font.BOLD, 16));
		bodypanel.add(designationpane);
		
		 fullnamepane = new JTextPane();
		 fullnamepane.setBounds(817, 54, 330, 26);
		 fullnamepane.setEditable(false);
		fullnamepane.setFont(new Font("Inter", Font.BOLD, 16));
		bodypanel.add(fullnamepane);
		
		JLabel lblNewLabel_3_1_1_1_2 = new JLabel("Full Name        :");
		lblNewLabel_3_1_1_1_2.setBounds(730, 54, 102, 26);
		lblNewLabel_3_1_1_1_2.setFont(new Font("Inter", Font.PLAIN, 12));
		bodypanel.add(lblNewLabel_3_1_1_1_2);
		
		JLabel lblgoals = new JLabel("Goals");
		lblgoals.setForeground(new Color(55, 75, 86));
		lblgoals.setFont(new Font("Inter", Font.BOLD, 20));
		lblgoals.setBounds(607, 174, 102, 58);
		bodypanel.add(lblgoals);
		
		JLabel lblachievements = new JLabel("Achievements");
		lblachievements.setForeground(new Color(55, 75, 86));
		lblachievements.setFont(new Font("Inter", Font.BOLD, 20));
		lblachievements.setBounds(604, 417, 147, 58);
		bodypanel.add(lblachievements);
		
		JLabel lblfeedback = new JLabel("Feedback");
		lblfeedback.setForeground(new Color(55, 75, 86));
		lblfeedback.setFont(new Font("Inter", Font.BOLD, 20));
		lblfeedback.setBounds(607, 347, 158, 39);
		bodypanel.add(lblfeedback);
		
		goalsfield = new JTextField();
		goalsfield.setBounds(607, 219, 373, 39);
		bodypanel.add(goalsfield);
		goalsfield.setColumns(10);
		
		feedbackfield = new JTextField();
		feedbackfield.setColumns(10);
		feedbackfield.setBounds(607, 383, 373, 39);
		bodypanel.add(feedbackfield);
		
		JPanel achivementspanel = new JPanel();
		achivementspanel.setLayout(null);
		achivementspanel.setBorder(new LineBorder(new Color(41, 75, 86)));
		achivementspanel.setBackground(Color.WHITE);
		achivementspanel.setBounds(781, 616, 147, 39);
		achivementspanel.addMouseListener(new PanelButtonMouseAdapter(achivementspanel) {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                openFileChooser();
            }
        });

		bodypanel.add(achivementspanel);
		
		JLabel achievementslbl = new JLabel("Achievements");
		achievementslbl.setForeground(new Color(41, 75, 86));
		achievementslbl.setFont(new Font("Inter", Font.BOLD, 16));
		achievementslbl.setBounds(10, 11, 127, 17);
		achivementspanel.add(achievementslbl);
		
		 lbldisplay = new JLabel("");
		lbldisplay.setBounds(607, 467, 215, 127);
		bodypanel.add(lbldisplay);
		
		JLabel lblImprovements = new JLabel("Improvements");
		lblImprovements.setForeground(new Color(55, 75, 86));
		lblImprovements.setFont(new Font("Inter", Font.BOLD, 20));
		lblImprovements.setBounds(607, 257, 193, 49);
		bodypanel.add(lblImprovements);
		
		areasofimprovementsfield = new JTextField();
		areasofimprovementsfield.setColumns(10);
		areasofimprovementsfield.setBounds(607, 304, 373, 39);
		bodypanel.add(areasofimprovementsfield);

	}
	// method for display sql table data in jtable
	private void fetchDatainTable() {
		// Assuming this code is within a method
		try {
		    String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
		    Connection connection = DriverManager.getConnection(url);

		    String sql = "SELECT * FROM Employee"; // Adjust SQL query according to your table name
		    PreparedStatement statement = connection.prepareStatement(sql);
		    ResultSet resultSet = statement.executeQuery();

		    // Create a DefaultTableModel with columns "Employee ID", "Lastname", "Firstname", "Designation"
		    DefaultTableModel tableModel = new DefaultTableModel(
		        new String[] {"Employee ID", "Lastname", "Firstname", "Designation"}, 0);

		    // Populate table model with data from result set
		    while (resultSet.next()) {
		        int employeeID = resultSet.getInt("e_id"); // Adjust column name as per your table
		        String lastName = resultSet.getString("e_lname");
		        String firstName = resultSet.getString("e_fname");
		        String designation = resultSet.getString("e_designation");

		        Object[] rowData = {employeeID, lastName, firstName, designation};
		        tableModel.addRow(rowData);
		    }

		    // Set the table model to your JTable
		    table.setModel(tableModel);

		    // Close the result set and statement 
		    resultSet.close();
		    statement.close();
		    connection.close();
		} catch (Exception e) {
		    e.printStackTrace();
		    JOptionPane.showMessageDialog(null, "Error: Failed to retrieve data from the database. ", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}

	// Method to view data from the selected row in the table
	private void viewSQLdata() {
	    int selectedRow = table.getSelectedRow();
	    if (selectedRow != -1) { // If a row is selected
	        try {
	            // Load the JDBC driver class
	            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

	            // Define the JDBC URL
	            String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";

	            // Establish the database connection
	            try (Connection connection = DriverManager.getConnection(url)) {
	                // Get the employee ID from the selected row as an Object
	                Object employeeIDObject = table.getValueAt(selectedRow, 0);

	                if (employeeIDObject instanceof Integer) { // Check if the employee ID is an Integer
	                    int employeeID = (int) employeeIDObject; // Cast the Object to an int

	                    String sql = "SELECT e.e_id, e.e_lname, e.e_fname, e.e_emailaddress, e.e_designation, e.e_goals, p.Feedback, p.Areas_of_Improvements, p.Achievements FROM Employee e JOIN Performance p ON e.e_id = p.performance_id WHERE e.e_id = ?";
	                    try (PreparedStatement statement = connection.prepareStatement(sql)) {
	                        // Set the employee ID as the parameter for the SQL query
	                        statement.setInt(1, employeeID);

	                        // Execute the query
	                        try (ResultSet resultSet = statement.executeQuery()) {
	                            if (resultSet.next()) {
	                                // Retrieve and display data
	                                int id = resultSet.getInt("e_id");
	                                String lastName = resultSet.getString("e_lname");
	                                String firstName = resultSet.getString("e_fname");
	                                String email = resultSet.getString("e_emailaddress");
	                                String designation = resultSet.getString("e_designation");
	                                String goals = resultSet.getString("e_goals");
	                                String feedback = resultSet.getString("Feedback");
	                                String areasimprove = resultSet.getString("Areas_of_Improvements");


	                                idpane.setText(String.valueOf(id));
	                                fullnamepane.setText(firstName + " " + lastName);
	                                emailpane.setText(email);
	                                designationpane.setText(designation);
	                                feedbackfield.setText(feedback);
	                                areasofimprovementsfield.setText("");
	                                goalsfield.setText(goals);
	                            } else {
	                                System.out.println("No data found for employee ID: " + employeeID);
	                            }
	                        }
	                    }
	                } else {
	                    System.out.println("Employee ID is not an Integer.");
	                }
	            }
	        } catch (ClassNotFoundException e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(null, "Error: JDBC Driver not found.", "Error", JOptionPane.ERROR_MESSAGE);
	        } catch (SQLException e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(null, "Error: Failed to execute SQL query.", "Error", JOptionPane.ERROR_MESSAGE);
	        }
	    } else {
	        System.out.println("No row selected.");
	    }
	}



    // Method to update data in the database
    private void updateData() {
    	try {
            // Load the JDBC driver class
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            // Define the JDBC URL
            String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";

            // Establish the database connection
            try (Connection connection = DriverManager.getConnection(url)) {
                // Get the employee ID from some source, e.g., idpane.getText() assuming it holds the ID
                int employeeID = Integer.parseInt(idpane.getText());

                String sql = "UPDATE Employee SET e_goals = ?, Feedback = ?, Achievements = ? WHERE e_id = ?";
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    // Set parameters
                    statement.setString(1, goalsfield.getText());
                    statement.setString(2, feedbackfield.getText()); 
                    // Assuming you have a method to convert image to byte array
                    byte[] imageBytes = convertImageToBytes(lbldisplay.getIcon());
                    statement.setBytes(3, imageBytes);
                    statement.setInt(4, employeeID);

                    // Execute update
                    int rowsAffected = statement.executeUpdate();
                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(null, "Data updated successfully.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Failed to update data.");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: Failed to update data in the database.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Method to convert image to byte array
    private byte[] convertImageToBytes(Icon icon) {
        // Convert ImageIcon to byte array
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            BufferedImage bi = new BufferedImage(icon.getIconWidth(), icon.getIconHeight(), BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d = bi.createGraphics();
            g2d.drawImage(((ImageIcon) icon).getImage(), 0, 0, null);
            g2d.dispose();
            ImageIO.write(bi, "jpg", bos);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bos.toByteArray();
    }
    
	// Method to delete data from the selected row in the table and the database
	private void deleteSQLdata() { 
		idpane.setText("");
		fullnamepane.setText("");
		emailpane.setText("");
		designationpane.setText("");
		feedbackfield.setText("");
		goalsfield.setText("");
		lbldisplay.setText("");

	  
	}
	
	 // method for retrive image from sql
	private void loadProfileIcon() {
	    int selectedRow = table.getSelectedRow();
	    if (selectedRow != -1) { // If a row is selected
	        try {
	            // Load the JDBC driver class
	            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

	            // Define the JDBC URL
	            String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";

	            // Establish the database connection
	            try (Connection connection = DriverManager.getConnection(url)) {
	                // Prepare the SQL statement to retrieve the profile image based on the employee ID of the selected row
	                String sql = "SELECT e_profile FROM Employee WHERE e_id = ?";
	                try (PreparedStatement statement = connection.prepareStatement(sql)) {
	                    // Get the employee ID of the selected row
	                    int employeeID = (int) table.getValueAt(selectedRow, 0);
	                    // Set the employee ID as the parameter for the SQL query
	                    statement.setInt(1, employeeID);

	                    // Execute the query
	                    try (ResultSet resultSet = statement.executeQuery()) {
	                        if (resultSet.next()) { 
	                            // Retrieve and display the profile image
	                            byte[] imageData = resultSet.getBytes("e_profile");
	                            if (imageData != null && imageData.length > 0) {
	                                try (ByteArrayInputStream bis = new ByteArrayInputStream(imageData)) {
	                                    BufferedImage bufferedImage = ImageIO.read(bis);
	                                    if (bufferedImage != null) {
	                                        Image scaledImage = bufferedImage.getScaledInstance(lblprofile.getWidth(), lblprofile.getHeight(), Image.SCALE_SMOOTH);
	                                        lblprofile.setIcon(new ImageIcon(scaledImage));
	                                    } else {
	                                        System.out.println("Failed to read image data from the database.");
	                                    }
	                                }
	                            } else {
	                                System.out.println("Image data retrieved from the database is null or empty.");
	                            }
	                        } else {
	                            System.out.println("No image data found for the specified employee ID.");
	                        }
	                    }
	                }
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	
	} 
	
	// Method to open file chooser and display selected file content
    private void openFileChooser() {
    	  JFileChooser fileChooser = new JFileChooser();
	        int returnValue = fileChooser.showOpenDialog(null);
	        if (returnValue == JFileChooser.APPROVE_OPTION) {
	            File selectedFile = fileChooser.getSelectedFile();
	            // Display the selected file in showStandardPictureLbl
	            ImageIcon imageIcon = new ImageIcon(
	                    new ImageIcon(selectedFile.getAbsolutePath())
	                            .getImage()
	                            .getScaledInstance(215, 127, Image.SCALE_DEFAULT)
	            );
	            lbldisplay.setIcon(imageIcon);
	        }
    }
    // method for clear fields
    private void clearData() {
    
    idpane.setText("");
    fullnamepane.setText("");
    emailpane.setText("");
    designationpane.setText("");
    feedbackfield.setText(""); 
    goalsfield.setText("");
    lbldisplay.setText(null);
    }
     
    private void updateColumnData() {
        try {
            // Load the JDBC driver class
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            // Define the JDBC URL
            String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";

            // Establish the database connection
            try (Connection connection = DriverManager.getConnection(url)) {
                // Get the employee ID from some source, e.g., idpane.getText() assuming it holds the ID
                int employeeID = Integer.parseInt(idpane.getText());

                // Retrieve data from fields
                String goals = goalsfield.getText();
                String improvements = areasofimprovementsfield.getText();
                String feedback = feedbackfield.getText();
 
                // Prepare statement to update Employee table
                String updateEmployeeSql = "UPDATE Employee SET e_goals = ? WHERE e_id = ?";
                try (PreparedStatement employeeStatement = connection.prepareStatement(updateEmployeeSql)) {
                    employeeStatement.setString(1, goals);
                    employeeStatement.setInt(2, employeeID);
                    // Execute update for Employee table
                    employeeStatement.executeUpdate();
                }

                // Prepare statement to update Performance table
                String updatePerformanceSql = "UPDATE Performance SET Feedback = ?, Areas_of_Improvements = ?, Achievements = ? WHERE performance_id = ?";
                try (PreparedStatement performanceStatement = connection.prepareStatement(updatePerformanceSql)) {
                    performanceStatement.setString(1, feedback);
                    performanceStatement.setString(2, improvements);
                    if (lbldisplay.getIcon() != null) {
                        // Convert image icon to byte array
                        byte[] imageBytes = convertImageToBytes((ImageIcon) lbldisplay.getIcon());
                        performanceStatement.setBytes(3, imageBytes);
                    } else {
                        performanceStatement.setNull(3, Types.BINARY); // Set Achievements to NULL
                    }
                    performanceStatement.setInt(4, employeeID);
                    // Execute update for Performance table
                    performanceStatement.executeUpdate();
                }
    
                JOptionPane.showMessageDialog(null, "Data updated successfully.");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: Failed to update data in the database.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private class PanelButtonMouseAdapter extends MouseAdapter{
  		JPanel panel;
  		
  		public PanelButtonMouseAdapter(JPanel panel) {
  			this.panel = panel;
  		}
  		
  		public void mouseEntered(MouseEvent e) {
  			panel.setBackground(new Color(240, 240, 240));
  		}
  		
  		public void mouseExited(MouseEvent e) {
  			panel.setBackground(new Color(255, 255, 255));
  		}
  		
  		public void mousePressed(MouseEvent e) {
  			panel.setBackground(new Color(240, 240, 240));
  		}
  		
  		public void mouseReleased(MouseEvent e) {
  			panel.setBackground(new Color(240, 240, 240));
  		}
  	}
	

}
