package AdminFrame;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Dimension;
//Import necessary packages
import java.awt.event.MouseAdapter; 
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.beans.Statement;
import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;
import java.awt.Font;
import java.awt.Image;

import javax.swing.border.MatteBorder;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.border.LineBorder;

public class AdminFrame extends JFrame {
	
	private ImageIcon logoicon = new ImageIcon(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\loginframeicon\\\\metrologo.png").getImage().getScaledInstance(258, 76, Image.SCALE_DEFAULT));

	
	private ImageIcon rigth = new ImageIcon(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\adminicon\\\\angle-small-right.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon down = new ImageIcon(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\adminicon\\\\angle-small-down.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));

	private ImageIcon employeeinfoicon = new ImageIcon(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\adminicon\\\\employees-woman-man.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon leaverequesticon = new ImageIcon(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\adminicon\\\\calendar-clock (2).png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon payrollicon = new ImageIcon(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\adminicon\\\\payroll-calendar.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	
	private ImageIcon goalsicon = new ImageIcon(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\adminicon\\\\chart-histogram.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon achivementsicon = new ImageIcon(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\adminicon\\\\trophy.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon feedbackicon = new ImageIcon(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\adminicon\\\\calendar-lines-pen.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	
	private ImageIcon trainingicon = new ImageIcon(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\adminicon\\\\calendar-lines-pen.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	
	private ImageIcon interviewicon = new ImageIcon(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\adminicon\\\\government-user.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon jobpostingicon = new ImageIcon(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\adminicon\\\\overview.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon processicon = new ImageIcon(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\adminicon\\\\priority-importance.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon trackingicon = new ImageIcon(new ImageIcon("C:\\\\Users\\\\MOMSIE BETSKIE\\\\eclipse-workspace\\\\FinalHumanResources\\\\assets\\\\adminicon\\\\track.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));

	private ImageIcon employeeinfoicon2 = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\employees (1).png").getImage().getScaledInstance(87, 87, Image.SCALE_DEFAULT));
	private ImageIcon leaverequesticon2 = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\daily-calendar (2).png").getImage().getScaledInstance(87, 87, Image.SCALE_DEFAULT));
	private ImageIcon payrollicon2 = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\wallet-arrow.png").getImage().getScaledInstance(87, 87, Image.SCALE_DEFAULT));
	private ImageIcon intreviewicon2 = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\boss.png").getImage().getScaledInstance(87, 87, Image.SCALE_DEFAULT));
	private ImageIcon trainingicon2 = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\leadership-alt.png").getImage().getScaledInstance(87, 87, Image.SCALE_DEFAULT));
	private ImageIcon trackingicon2 = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\overview (1).png").getImage().getScaledInstance(87, 87, Image.SCALE_DEFAULT));

	
	 
    private static final long serialVersionUID = 1L;

    private JPanel contentPane;
    private JPanel EmployeeinfoPanel, DevelopmentPanel, TtrainingPanel, RecruitmentPanel, TrackingPanel, signoutPanel;
    private JLabel arrowrigthlnl, arrowdownlbl, arrowrigthlnl_1, arrowdownlbl_1, arrowrigthlnl_1_1, arrowdownlbl_1_1, arrowrigthlnl_1_1_1, arrowdownlbl_1_1_1, arrowrigthlnl_1_1_1_1, arrowdownlbl_1_1_1_1;
    private JLabel  lblrealtime, lblrealdate;
    
    private JLabel countelbl, countelbl2;
    private JLabel profilelbl, lblAdmin, lblfname; 
    
    
    public static EmployeeDataPanel employeedatapanel;
     public static  AdminBodyFrame adminbodypanel ;
     public static LeaveRequestPanel leaverequestpanel;
     public static PayrollPanel payrollpanel;
     public static developmentPanel developmentpanel;
     public static TrainingInfoPanel traininginfopanel;
     public static applicantTrackingPanel applicantTracking;
     public static InterviewPanel interviewpanel;
     public static jobpanel jobpostingpanel;
     public static JPanel selectedPanel;
        /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    AdminFrame frame = new AdminFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**    
     * Create the frame.
     */
    public AdminFrame() {
    	  
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1450, 803);
        setTitle("Admin"); 
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        
     // create an instance panel class
        adminbodypanel = new AdminBodyFrame();
    	employeedatapanel = new EmployeeDataPanel();
    	leaverequestpanel = new LeaveRequestPanel();
    	payrollpanel = new PayrollPanel();
    	developmentpanel = new developmentPanel();
    	traininginfopanel = new TrainingInfoPanel();
    	applicantTracking = new applicantTrackingPanel();
    	interviewpanel = new InterviewPanel();
    	jobpostingpanel = new jobpanel();
    	
    	
    	// set the bounds of the pane
    	adminbodypanel.setBounds(217,76,1217,688);
    	employeedatapanel.setBounds(217,76,1217,688);
    	leaverequestpanel.setBounds(217,76,1217,688);
    	payrollpanel.setBounds(217,76,1217,688);
    	developmentpanel.setBounds(217,76,1217,688);
    	traininginfopanel.setBounds(217,76,1217,688);
    	applicantTracking.setBounds(217, 76, 1217, 688);
    	interviewpanel.setBounds(217, 76, 1217, 688);
    	jobpostingpanel.setBounds(217,76,1217,688);
    	//add the all panel instance to the content pane of the admin frame
    	contentPane.add(adminbodypanel);
    	contentPane.add(employeedatapanel);
    	contentPane.add(leaverequestpanel);
    	contentPane.add(payrollpanel);
    	contentPane.add(developmentpanel);
    	contentPane.add(traininginfopanel);
    	contentPane.add(applicantTracking);
    	contentPane.add(interviewpanel);
    	contentPane.add(jobpostingpanel);
    	
    	// Call revalidate() and repaint to update the frame
    	contentPane.revalidate();
    	contentPane.repaint();
        
        JPanel headpanel = new JPanel();
        headpanel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
        headpanel.setBackground(new Color(255, 255, 255));
        headpanel.setBounds(217, 0, 1217, 76);
        contentPane.add(headpanel);
        headpanel.setLayout(null);
        
        JLabel lbllogo = new JLabel("");
        lbllogo.setIcon(logoicon);
        lbllogo.setBounds(478, 0, 258, 76); 
        headpanel.add(lbllogo);
        
        

        JPanel leftPanel = new JPanel();
        leftPanel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
        leftPanel.setBackground(new Color(255, 255, 255));
        leftPanel.setBounds(0, 0, 218, 764);
        contentPane.add(leftPanel);
        leftPanel.setLayout(null);
        
        
        JPanel profilepanel = new JPanel();
        profilepanel.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(41, 75, 141)));
        profilepanel.setBackground(new Color(255, 255, 255));
        profilepanel.setBounds(10, 53, 198, 93);
        leftPanel.add(profilepanel);
        profilepanel.setLayout(null);
        
         profilelbl = new JLabel("");
        profilelbl.setBounds(10, 11, 66, 57);
        profilepanel.add(profilelbl);
        
         lblfname = new JLabel(""); 
        lblfname.setFont(new Font("Inter", Font.PLAIN, 14));
        lblfname.setForeground(new Color(55, 75, 86));
        lblfname.setBounds(84, 11, 41, 29);
        profilepanel.add(lblfname);
        
         lblAdmin = new JLabel(""); 
        lblAdmin.setForeground(new Color(35, 35, 35));
        lblAdmin.setFont(new Font("Inter", Font.PLAIN, 14));
        lblAdmin.setBounds(121, 11, 87, 29); 
        profilepanel.add(lblAdmin);
        
        JLabel onlineiconlbl = new JLabel("");
        onlineiconlbl.setBounds(86, 39, 20, 20); 
        profilepanel.add(onlineiconlbl);
        
        JLabel lblOnline = new JLabel("Online");
        lblOnline.setForeground(new Color(55, 75, 86));
        lblOnline.setBounds(121, 39, 41, 20);
        profilepanel.add(lblOnline);
        
        JLabel titlelb = new JLabel("Administrator");
        titlelb.setForeground(new Color(55, 75, 86));
        titlelb.setBounds(49, 11, 144, 31);
        leftPanel.add(titlelb);
        titlelb.setFont(new Font("Inter", Font.BOLD, 18));
        
        JLabel lblLinks = new JLabel("Links");
        lblLinks.setForeground(new Color(55, 75, 86));
        lblLinks.setFont(new Font("Inter", Font.BOLD, 18));
        lblLinks.setBounds(10, 194, 144, 31); 
        leftPanel.add(lblLinks);
        
        EmployeeinfoPanel = new JPanel();
        EmployeeinfoPanel.addMouseListener(new PanelButtonMouseAdapter2(EmployeeinfoPanel) {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (EmployeeinfoPanel.getHeight() == 48) {
                    // Expand the panel
                    EmployeeinfoPanel.setSize(new Dimension(198, 198));
                    // Move the DashboardPanel below the expanded EmployeeinfoPanel
                    DevelopmentPanel.setLocation(DevelopmentPanel.getX(), EmployeeinfoPanel.getY() + EmployeeinfoPanel.getHeight() + 1);
                    TtrainingPanel.setLocation(TtrainingPanel.getX(), DevelopmentPanel.getY() + DevelopmentPanel.getHeight() + 1);
                    RecruitmentPanel.setLocation(RecruitmentPanel.getX(), TtrainingPanel.getY() + TtrainingPanel.getHeight() + 1);
                    signoutPanel.setLocation(signoutPanel.getX(), RecruitmentPanel.getY() + RecruitmentPanel.getHeight() + 1);

                    arrowrigthlnl.setIcon(rigth);
                    arrowdownlbl.setIcon(down);
                    arrowrigthlnl.setVisible(false);
                    arrowdownlbl.setVisible(true);

                    
                } else {
                    // Collapse the panel
                    EmployeeinfoPanel.setSize(new Dimension(198, 48));
                    // Move the DashboardPanel back to its original position
                    DevelopmentPanel.setLocation(DevelopmentPanel.getX(), EmployeeinfoPanel.getY() + EmployeeinfoPanel.getHeight() + 1);
                    TtrainingPanel.setLocation(TtrainingPanel.getX(), DevelopmentPanel.getY() + DevelopmentPanel.getHeight() + 1);
                    RecruitmentPanel.setLocation(RecruitmentPanel.getX(), TtrainingPanel.getY() + TtrainingPanel.getHeight() + 1);
                    signoutPanel.setLocation(signoutPanel.getX(), RecruitmentPanel.getY() + RecruitmentPanel.getHeight() + 1);

                    arrowrigthlnl.setIcon(rigth);
                    arrowdownlbl.setIcon(down);
                    arrowrigthlnl.setVisible(true);
                    arrowdownlbl.setVisible(false);

                }
            }
        });
        EmployeeinfoPanel.setLayout(null);
        EmployeeinfoPanel.setBorder(new MatteBorder(2, 0, 2, 0, (Color) new Color(41, 75, 141)));
        EmployeeinfoPanel.setBackground(Color.WHITE);
        EmployeeinfoPanel.setBounds(10, 224, 198, 48);
        leftPanel.add(EmployeeinfoPanel);
        
         arrowrigthlnl = new JLabel("");
        arrowrigthlnl.setIcon(rigth);
        arrowrigthlnl.setBounds(168, 22, 20, 20);
        EmployeeinfoPanel.add(arrowrigthlnl);
        
         arrowdownlbl = new JLabel("");
        arrowdownlbl.setBounds(168, 22, 20, 20);
        EmployeeinfoPanel.add(arrowdownlbl);
        
        JLabel lblEmployeeInfo = new JLabel("Employee Info");
        lblEmployeeInfo.setForeground(new Color(55, 75, 86));
        lblEmployeeInfo.setFont(new Font("Inter", Font.BOLD, 18));
        lblEmployeeInfo.setBounds(0, 11, 144, 31);
        EmployeeinfoPanel.add(lblEmployeeInfo);
        
        JSeparator separator = new JSeparator();
        separator.setBackground(new Color(41, 75, 141));
        separator.setOrientation(SwingConstants.VERTICAL);
        separator.setBounds(34, 50, 11, 122);
        EmployeeinfoPanel.add(separator);
        
        JPanel employeeinfospanel = new JPanel();
        employeeinfospanel.addMouseListener(new PanelButtonMouseAdapter(employeeinfospanel) {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		menuClicked(employeeinfospanel);
        		
        		employeedatapanel.setVisible(true);
        		adminbodypanel.setVisible(false);
        		leaverequestpanel.setVisible(false);
        		payrollpanel.setVisible(false);
        		developmentpanel.setVisible(false);
        		traininginfopanel.setVisible(false);
        		applicantTracking.setVisible(false);
        		interviewpanel.setVisible(false);
        		jobpostingpanel.setVisible(false);
        	}
        });
        employeeinfospanel.setBackground(new Color(255, 255, 255));
        employeeinfospanel.setBounds(48, 50, 150, 38);
        EmployeeinfoPanel.add(employeeinfospanel);
        employeeinfospanel.setLayout(null);
        
        JLabel emlbl = new JLabel("  Employee Data");
        emlbl.setIcon(employeeinfoicon);
        emlbl.setFont(new Font("Inter", Font.PLAIN, 13));
        emlbl.setBounds(10, 0, 140, 38);
        employeeinfospanel.add(emlbl);
        
        JPanel leaverequest = new JPanel();
        leaverequest.addMouseListener(new PanelButtonMouseAdapter(leaverequest) {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		employeedatapanel.setVisible(false);
        		adminbodypanel.setVisible(false);
        		leaverequestpanel.setVisible(true);
        		payrollpanel.setVisible(false);
        		developmentpanel.setVisible(false);
        		traininginfopanel.setVisible(false);
        		applicantTracking.setVisible(false);
        		interviewpanel.setVisible(false);
        		jobpostingpanel.setVisible(false);


        	}
        });
        leaverequest.setBackground(new Color(255, 255, 255));
        leaverequest.setBounds(48, 88, 150, 38);
        EmployeeinfoPanel.add(leaverequest);
        leaverequest.setLayout(null);
        
        JLabel lrlbl = new JLabel("  Leave Request");
        lrlbl.setIcon(leaverequesticon);
        lrlbl.setFont(new Font("Inter", Font.PLAIN, 13));
        lrlbl.setBounds(10, 0, 130, 38);
        leaverequest.add(lrlbl);
        
        JPanel payroll = new JPanel();
        payroll.addMouseListener(new PanelButtonMouseAdapter(payroll) {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		menuClicked(payroll);
        		
        		employeedatapanel.setVisible(false);
        		adminbodypanel.setVisible(false);
        		leaverequestpanel.setVisible(false);
        		payrollpanel.setVisible(true);
        		developmentpanel.setVisible(false);
        		traininginfopanel.setVisible(false);
        		applicantTracking.setVisible(false);
        		interviewpanel.setVisible(false);
        		jobpostingpanel.setVisible(false);


        		
        	}
        });
        payroll.setBackground(new Color(255, 255, 255));
        payroll.setBounds(48, 124, 150, 38);
        EmployeeinfoPanel.add(payroll);
        payroll.setLayout(null);
        
        JLabel lblNewLabel_1_2 = new JLabel("  Payroll");
        lblNewLabel_1_2.setIcon(payrollicon);
        lblNewLabel_1_2.setFont(new Font("Inter", Font.PLAIN, 13));
        lblNewLabel_1_2.setBounds(10, 0, 140, 38);
        payroll.add(lblNewLabel_1_2);
        //============= to do development panel ===========
        DevelopmentPanel = new JPanel();
        DevelopmentPanel.setLayout(null);
        DevelopmentPanel.addMouseListener(new PanelButtonMouseAdapter2(DevelopmentPanel) {
            @Override
            public void mouseClicked(MouseEvent e) {
            	menuClicked(DevelopmentPanel);
                if (DevelopmentPanel.getHeight() == 48) {
                    // Expand the panel
                    DevelopmentPanel.setSize(new Dimension(198, 198));
                    // Move the TtrainingPanel below the expanded DevelopmentPanel
                    TtrainingPanel.setLocation(TtrainingPanel.getX(), DevelopmentPanel.getY() + DevelopmentPanel.getHeight() + 1);
                    RecruitmentPanel.setLocation(RecruitmentPanel.getX(), TtrainingPanel.getY() + TtrainingPanel.getHeight() + 1);
                    signoutPanel.setLocation(signoutPanel.getX(), RecruitmentPanel.getY() + RecruitmentPanel.getHeight() + 1);

                    
                    arrowrigthlnl_1.setIcon(rigth);
                    arrowdownlbl_1.setIcon(down);
                    arrowrigthlnl_1.setVisible(false);
                    arrowdownlbl_1.setVisible(true);
                    
                    employeedatapanel.setVisible(false);
            		adminbodypanel.setVisible(false);
            		leaverequestpanel.setVisible(false);
            		payrollpanel.setVisible(false);
            		developmentpanel.setVisible(true);
                } else {
                    // Collapse the panel
                    DevelopmentPanel.setSize(new Dimension(198, 48));
                    // Move the TtrainingPanel back to its original position
                    TtrainingPanel.setLocation(TtrainingPanel.getX(), DevelopmentPanel.getY() + DevelopmentPanel.getHeight() + 1);
                    RecruitmentPanel.setLocation(RecruitmentPanel.getX(), TtrainingPanel.getY() + TtrainingPanel.getHeight() + 1);
                    signoutPanel.setLocation(signoutPanel.getX(), RecruitmentPanel.getY() + RecruitmentPanel.getHeight() + 1);

                    arrowrigthlnl_1.setIcon(rigth);
                    arrowdownlbl_1.setIcon(down);
                    arrowrigthlnl_1.setVisible(true);
                    arrowdownlbl_1.setVisible(false);
                }
            }
        });
        DevelopmentPanel.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(41, 75, 141)));
        DevelopmentPanel.setBackground(Color.WHITE);
        DevelopmentPanel.setBounds(10, 271, 198, 48);
        leftPanel.add(DevelopmentPanel);
        
         arrowrigthlnl_1 = new JLabel("");
        arrowrigthlnl_1.setIcon(rigth);
        arrowrigthlnl_1.setBounds(168, 22, 20, 20);
        DevelopmentPanel.add(arrowrigthlnl_1);
        
         arrowdownlbl_1 = new JLabel("");
        arrowdownlbl_1.setBounds(168, 22, 20, 20);
        DevelopmentPanel.add(arrowdownlbl_1);
        
        JLabel Developmentlbl = new JLabel("Development");
        Developmentlbl.setForeground(new Color(55, 75, 86));
        Developmentlbl.setFont(new Font("Inter", Font.BOLD, 18));
        Developmentlbl.setBounds(0, 11, 144, 31);
        DevelopmentPanel.add(Developmentlbl);
        
        JSeparator separator_1 = new JSeparator();
        separator_1.setOrientation(SwingConstants.VERTICAL);
        separator_1.setBackground(new Color(41, 75, 141));
        separator_1.setBounds(34, 54, 11, 118);
        DevelopmentPanel.add(separator_1);
        
        JPanel achivementspanel = new JPanel();
        achivementspanel.addMouseListener(new PanelButtonMouseAdapter(achivementspanel) {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        	}
        });
        achivementspanel.setLayout(null);
        achivementspanel.setBackground(Color.WHITE);
        achivementspanel.setBounds(48, 50, 150, 38);
        DevelopmentPanel.add(achivementspanel);
        
        JLabel lblAchivements = new JLabel("Achivements");
        lblAchivements.setIcon(achivementsicon);
        lblAchivements.setFont(new Font("Inter", Font.PLAIN, 13));
        lblAchivements.setBounds(10, 11, 109, 14);
        achivementspanel.add(lblAchivements);
        
        JPanel GoalsPanel = new JPanel();
        GoalsPanel.addMouseListener(new PanelButtonMouseAdapter(GoalsPanel) {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        	}
        });
        GoalsPanel.setLayout(null);
        GoalsPanel.setBackground(Color.WHITE);
        GoalsPanel.setBounds(48, 88, 150, 38);
        DevelopmentPanel.add(GoalsPanel);
        
        JLabel lblGoals = new JLabel("Goals");
        lblGoals.setIcon(goalsicon);
        lblGoals.setFont(new Font("Inter", Font.PLAIN, 13));
        lblGoals.setBounds(10, 11, 109, 14);
        GoalsPanel.add(lblGoals);
        
        JPanel FeedbackPanel = new JPanel();
        FeedbackPanel.addMouseListener(new PanelButtonMouseAdapter(FeedbackPanel) {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        	}
        });
        FeedbackPanel.setLayout(null);
        FeedbackPanel.setBackground(Color.WHITE);
        FeedbackPanel.setBounds(48, 125, 150, 38);
        DevelopmentPanel.add(FeedbackPanel);
        
        JLabel lblNewLabel_1_2_1 = new JLabel("Feedback");
        lblNewLabel_1_2_1.setIcon(feedbackicon);
        lblNewLabel_1_2_1.setFont(new Font("Inter", Font.PLAIN, 13));
        lblNewLabel_1_2_1.setBounds(10, 11, 109, 14);
        FeedbackPanel.add(lblNewLabel_1_2_1);
        // ============= to do Trainingpanel ====================
        TtrainingPanel = new JPanel();
        TtrainingPanel.addMouseListener(new PanelButtonMouseAdapter2(TtrainingPanel) {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		if (TtrainingPanel.getHeight() == 48) {
                    // Expand the panel
        			TtrainingPanel.setSize(new Dimension(198, 103));
                    // Move the TtrainingPanel below the expanded DevelopmentPanel
                    RecruitmentPanel.setLocation(RecruitmentPanel.getX(), TtrainingPanel.getY() + TtrainingPanel.getHeight() + 1);
                    signoutPanel.setLocation(signoutPanel.getX(), RecruitmentPanel.getY() + RecruitmentPanel.getHeight() + 1);

                    
                    arrowrigthlnl_1_1.setIcon(rigth);
                    arrowdownlbl_1_1.setIcon(down);
                    arrowrigthlnl_1_1.setVisible(false);
                    arrowdownlbl_1_1.setVisible(true);
                } else {
                    // Collapse the panel
                	TtrainingPanel.setSize(new Dimension(198, 48));
                    // Move the TtrainingPanel back to its original position
                    RecruitmentPanel.setLocation(RecruitmentPanel.getX(), TtrainingPanel.getY() + TtrainingPanel.getHeight() + 1);
                    signoutPanel.setLocation(signoutPanel.getX(), RecruitmentPanel.getY() + RecruitmentPanel.getHeight() + 1);
                    
                    arrowrigthlnl_1_1.setIcon(rigth);
                    arrowdownlbl_1_1.setIcon(down);
                    arrowrigthlnl_1_1.setVisible(true);
                    arrowdownlbl_1_1.setVisible(false);
                }
        	}
        });
        TtrainingPanel.setLayout(null);
        TtrainingPanel.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(41, 75, 141)));
        TtrainingPanel.setBackground(Color.WHITE);
        TtrainingPanel.setBounds(10, 319, 198, 48);
        leftPanel.add(TtrainingPanel);
        
        arrowrigthlnl_1_1 = new JLabel("");
        arrowrigthlnl_1_1.setIcon(rigth);
        arrowrigthlnl_1_1.setBounds(168, 22, 20, 20);
        TtrainingPanel.add(arrowrigthlnl_1_1);
        
        arrowdownlbl_1_1 = new JLabel("");
        arrowdownlbl_1_1.setBounds(168, 22, 20, 20);
        TtrainingPanel.add(arrowdownlbl_1_1);
        
        JLabel lbltraining = new JLabel("Training");
        lbltraining.setForeground(new Color(55, 75, 86));
        lbltraining.setFont(new Font("Inter", Font.BOLD, 18));
        lbltraining.setBounds(0, 11, 144, 31);
        TtrainingPanel.add(lbltraining);
        
        JSeparator separator_1_1 = new JSeparator();
        separator_1_1.setOrientation(SwingConstants.VERTICAL);
        separator_1_1.setBackground(new Color(41, 75, 141));
        separator_1_1.setBounds(34, 54, 11, 38);
        TtrainingPanel.add(separator_1_1);
        
        JPanel trainingpanels = new JPanel();
        trainingpanels.addMouseListener(new PanelButtonMouseAdapter(trainingpanels) {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		menuClicked(trainingpanels);
        		employeedatapanel.setVisible(false);
        		adminbodypanel.setVisible(false);
        		leaverequestpanel.setVisible(false);
        		payrollpanel.setVisible(false);
        		developmentpanel.setVisible(false);
        		traininginfopanel.setVisible(true);
        		applicantTracking.setVisible(false);
        		interviewpanel.setVisible(false);
        		jobpostingpanel.setVisible(false);


        	} 
        });
        trainingpanels.setLayout(null);
        trainingpanels.setBackground(Color.WHITE);
        trainingpanels.setBounds(48, 50, 150, 38);
        TtrainingPanel.add(trainingpanels);
        
        JLabel lbltrainings = new JLabel("Training Info");
        lbltrainings.setIcon(trainingicon);
        lbltrainings.setFont(new Font("Inter", Font.PLAIN, 13));
        lbltrainings.setBounds(10, 0, 109, 38);
        trainingpanels.add(lbltrainings);
        // ========== to do Recruitmentpanel
        RecruitmentPanel = new JPanel(); 
        RecruitmentPanel.addMouseListener(new PanelButtonMouseAdapter2(RecruitmentPanel) {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		if (RecruitmentPanel.getHeight() == 48) {
                    // Expand the panel
        			RecruitmentPanel.setSize(new Dimension(198, 231));
        			
        			signoutPanel.setLocation(signoutPanel.getX(), RecruitmentPanel.getY() + RecruitmentPanel.getHeight() + 1);
        			 arrowrigthlnl_1_1_1.setIcon(rigth);
                     arrowdownlbl_1_1_1.setIcon(down);
                     arrowrigthlnl_1_1_1.setVisible(false);
                     arrowdownlbl_1_1_1.setVisible(true);

                } else {
                    // Collapse the panel
                	RecruitmentPanel.setSize(new Dimension(198, 48));
                	
                	signoutPanel.setLocation(signoutPanel.getX(), RecruitmentPanel.getY() + RecruitmentPanel.getHeight() + 1);
                	arrowrigthlnl_1_1_1.setIcon(rigth);
                	 arrowdownlbl_1_1_1.setIcon(down);
                	 arrowrigthlnl_1_1_1.setVisible(false);
                     arrowdownlbl_1_1_1.setVisible(true);
                }
        	}
        });
        RecruitmentPanel.setLayout(null);
        RecruitmentPanel.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(41, 75, 141)));
        RecruitmentPanel.setBackground(Color.WHITE);
        RecruitmentPanel.setBounds(10, 367, 198, 48);
        leftPanel.add(RecruitmentPanel);
        
         arrowrigthlnl_1_1_1 = new JLabel("");
         arrowrigthlnl_1_1_1.setIcon(rigth);
        arrowrigthlnl_1_1_1.setBounds(168, 22, 20, 20);
        RecruitmentPanel.add(arrowrigthlnl_1_1_1);
        
         arrowdownlbl_1_1_1 = new JLabel("");
        arrowdownlbl_1_1_1.setBounds(168, 22, 20, 20);
        RecruitmentPanel.add(arrowdownlbl_1_1_1);
        
        JLabel lblRecruitment = new JLabel("Recruitment");
        lblRecruitment.setForeground(new Color(55, 75, 86));
        lblRecruitment.setFont(new Font("Inter", Font.BOLD, 18));
        lblRecruitment.setBounds(0, 11, 144, 31);
        RecruitmentPanel.add(lblRecruitment);
        
        JSeparator separator_1_1_1 = new JSeparator();
        separator_1_1_1.setOrientation(SwingConstants.VERTICAL);
        separator_1_1_1.setBackground(new Color(41, 75, 141));
        separator_1_1_1.setBounds(34, 54, 11, 108);
        RecruitmentPanel.add(separator_1_1_1);
        
        JPanel interviewpanels = new JPanel();
        interviewpanels.addMouseListener(new PanelButtonMouseAdapter(interviewpanels) {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		menuClicked(interviewpanels);
        		applicantTracking.setVisible(false);
         		adminbodypanel.setVisible(false);
        		employeedatapanel.setVisible(false);
        		payrollpanel.setVisible(false);
        		adminbodypanel.setVisible(false);
         		leaverequestpanel.setVisible(false);
         		developmentpanel.setVisible(false);
         		traininginfopanel.setVisible(false);
        		interviewpanel.setVisible(true);
        		jobpostingpanel.setVisible(false);


        	}
        });
        interviewpanels.setLayout(null);
        interviewpanels.setBackground(Color.WHITE);
        interviewpanels.setBounds(48, 50, 150, 38);
        RecruitmentPanel.add(interviewpanels);
        
        JLabel lblinterview = new JLabel("Interview");
        lblinterview.setIcon(interviewicon);
        lblinterview.setFont(new Font("Inter", Font.PLAIN, 13));
        lblinterview.setBounds(10, 0, 109, 38);
        interviewpanels.add(lblinterview);
        
 
        //============= to do tracking
         TrackingPanel = new JPanel();
         TrackingPanel.addMouseListener(new PanelButtonMouseAdapter(TrackingPanel) {
         	@Override
         	public void mouseClicked(MouseEvent e) {
         		menuClicked(TrackingPanel);
         		applicantTracking.setVisible(true);
         		adminbodypanel.setVisible(false);
        		employeedatapanel.setVisible(false);
        		payrollpanel.setVisible(false);
        		adminbodypanel.setVisible(false);
         		leaverequestpanel.setVisible(false);
         		developmentpanel.setVisible(false);
         		traininginfopanel.setVisible(false);
        		interviewpanel.setVisible(false);
        		jobpostingpanel.setVisible(false);


         	}
         });
        TrackingPanel.setLayout(null);
        TrackingPanel.setBackground(Color.WHITE);
        TrackingPanel.setBounds(48, 86, 150, 38);
        RecruitmentPanel.add(TrackingPanel);
        
        JLabel lbltracking = new JLabel("Tracking");
        lbltracking.setIcon(trackingicon);
        lbltracking.setFont(new Font("Inter", Font.PLAIN, 13));
        lbltracking.setBounds(10, 0, 109, 38);
        TrackingPanel.add(lbltracking);
        
        JPanel Jobpostingpanel = new JPanel();
        Jobpostingpanel.setBounds(48, 124, 150, 38);
        RecruitmentPanel.add(Jobpostingpanel);
        Jobpostingpanel.addMouseListener(new PanelButtonMouseAdapter(Jobpostingpanel) {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		menuClicked(Jobpostingpanel);
        		jobpostingpanel.setVisible(true);
        		adminbodypanel.setVisible(false);
        		employeedatapanel.setVisible(false);
        		payrollpanel.setVisible(false);
         		leaverequestpanel.setVisible(false);
         		developmentpanel.setVisible(false);
         		traininginfopanel.setVisible(false);
         		applicantTracking.setVisible(false);
        		interviewpanel.setVisible(false);

        	}
        });
        Jobpostingpanel.setLayout(null);
        Jobpostingpanel.setBackground(Color.WHITE);
        
        JLabel lbljobs = new JLabel("Job Posting");
        lbljobs.setIcon(jobpostingicon);
        lbljobs.setFont(new Font("Inter", Font.PLAIN, 13));
        lbljobs.setBounds(10, 0, 109, 38);
        Jobpostingpanel.add(lbljobs);
        
        signoutPanel = new JPanel();
        signoutPanel.addMouseListener(new PanelButtonMouseAdapter(signoutPanel) {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		int option = JOptionPane.showConfirmDialog(null, "Do you want to sign out?", "Sign Out", JOptionPane.YES_NO_OPTION);
        	    if (option == JOptionPane.YES_OPTION) {
        	        // Dispose
        	        dispose(); // Assuming 'dispose' is a method to handle sign out
        	    } 
        	}
        });
        signoutPanel.setLayout(null);
        signoutPanel.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(41, 75, 141)));
        signoutPanel.setBackground(Color.WHITE);
        signoutPanel.setBounds(10, 414, 198, 48);
        leftPanel.add(signoutPanel);
        
         arrowrigthlnl_1_1_1_1 = new JLabel("");
         arrowrigthlnl_1_1_1_1.setIcon(rigth);
        arrowrigthlnl_1_1_1_1.setBounds(168, 22, 20, 20);
        signoutPanel.add(arrowrigthlnl_1_1_1_1);
        
        
        JLabel lblsignoutslbl = new JLabel("Sign Out");
        lblsignoutslbl.setForeground(new Color(55, 75, 86));
        lblsignoutslbl.setFont(new Font("Inter", Font.BOLD, 18));
        lblsignoutslbl.setBounds(0, 11, 144, 31);
        signoutPanel.add(lblsignoutslbl);
        
        JSeparator separator_1_1_1_1 = new JSeparator();
        separator_1_1_1_1.setOrientation(SwingConstants.VERTICAL);
        separator_1_1_1_1.setBackground(new Color(41, 75, 141));
        separator_1_1_1_1.setBounds(34, 50, 11, 38);
        signoutPanel.add(separator_1_1_1_1);
        
        JPanel signoutspanel = new JPanel();
        signoutspanel.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		
        	}
        });
        signoutspanel.setLayout(null);
        signoutspanel.setBackground(Color.WHITE);
        signoutspanel.setBounds(48, 50, 150, 38);
        signoutPanel.add(signoutspanel);
        
        JLabel lblsignout = new JLabel("Sign Out");
        lblsignout.setFont(new Font("Inter", Font.PLAIN, 13));
        lblsignout.setBounds(10, 0, 109, 38);
        signoutspanel.add(lblsignout);
        
        JPanel DashboardPanel = new JPanel();
        DashboardPanel.addMouseListener(new PanelButtonMouseAdapter(DashboardPanel) {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		menuClicked(DashboardPanel);
        		adminbodypanel.setVisible(true);
        		employeedatapanel.setVisible(false);
        		payrollpanel.setVisible(false);
         		leaverequestpanel.setVisible(false);
         		developmentpanel.setVisible(false);
         		traininginfopanel.setVisible(false);
         		applicantTracking.setVisible(false);
        		interviewpanel.setVisible(false);
        		jobpostingpanel.setVisible(false);


        		
        	}
        });
        DashboardPanel.setLayout(null);
        DashboardPanel.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(41, 75, 141)));
        DashboardPanel.setBackground(Color.WHITE);
        DashboardPanel.setBounds(10, 147, 198, 48);
        leftPanel.add(DashboardPanel);
        
        JLabel arrowrigthlnl_1_1_1_1_1 = new JLabel("");
        arrowrigthlnl_1_1_1_1_1.setBounds(168, 22, 20, 20);
        DashboardPanel.add(arrowrigthlnl_1_1_1_1_1);
        
        JLabel lbldashboard = new JLabel("Dashboard");
        lbldashboard.setForeground(new Color(55, 75, 86));
        lbldashboard.setFont(new Font("Inter", Font.BOLD, 18));
        lbldashboard.setBounds(0, 11, 144, 31); 
        DashboardPanel.add(lbldashboard);

        
        
      
        loadProfileIcon();
        fetchDataAndUpdateLabels("Verstappen", "Max");
        

       
    }

    
 // method for retrive image from sql
    private void loadProfileIcon() {

        try {
            // Load the JDBC driver class
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            // Define the JDBC URL
            String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";

            // Establish the database connection
            try (Connection connection = DriverManager.getConnection(url)) {
                // Prepare the SQL statement
                String sql = "SELECT hr_profile FROM HR WHERE hr_id = ?;";
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setInt(1, 1); // Assuming the ID of the image you want to retrieve is 1

                    // Execute the query
                    try (ResultSet resultSet = statement.executeQuery()) {
                        if (resultSet.next()) { 
                            // Retrieve the image data from the result set
                            byte[] imageData = resultSet.getBytes("hr_profile");

                            if (imageData != null && imageData.length > 0) { // Check if image data is not null or empty
                                // Convert the byte array to a BufferedImage
                                try (ByteArrayInputStream bis = new ByteArrayInputStream(imageData)) {
                                    BufferedImage bufferedImage = ImageIO.read(bis);

                                    if (bufferedImage != null) { // Check if BufferedImage was successfully created
                                        // Resize the image to fit the JLabel
                                        Image scaledImage = bufferedImage.getScaledInstance(profilelbl.getWidth(), profilelbl.getHeight(), Image.SCALE_SMOOTH);

                                        // Set the scaled image to the JLabel
                                        profilelbl.setIcon(new ImageIcon(scaledImage));
//                                        System.out.println("Image data retrieved from the databas");
                                    } else {
                                        System.out.println("Failed to read image data from the database.");
                                    }
                                }
                            } else {
                                System.out.println("Image data retrieved from the database is null or empty.");
                            }
                        } else {
                            System.out.println("No image data found for the specified employee ID.");
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
// 	method for displaying sql data in labels
    private void fetchDataAndUpdateLabels(String hr_lastname, String hr_firstname ) {
    	
    	try {
            String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
            Connection connection = DriverManager.getConnection(url);
            
            String query = "SELECT * FROM HR WHERE hr_lastname = ? AND hr_firstname = ?;";
            try(PreparedStatement pstmt = connection.prepareStatement(query)){
            	pstmt.setString(1, "Verstappen");
            	pstmt.setString(2, "Max");
            	
            	ResultSet result = pstmt.executeQuery();
            	
            	if(result.next()){
            		lblAdmin.setText(result.getString("hr_lastname"));
            		lblfname.setText(result.getString("hr_firstname"));
            		
            	}
            }
    	}catch(SQLException e) {
    		
    	}
    	
    }
    
    
 // method for real time 
 	private void updateTime() {
 	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
 	    String currentTime = LocalTime.now().format(formatter);  
 	   lblrealtime.setText(currentTime);
 	}
    
 	private void menuClicked(JPanel selectedPanel) {
 		adminbodypanel.setVisible(false);
 		employeedatapanel.setVisible(false);
 		leaverequestpanel.setVisible(false);
 		payrollpanel.setVisible(false);
 		developmentpanel.setVisible(false);
 		traininginfopanel.setVisible(false);
 		applicantTracking.setVisible(false); 
		interviewpanel.setVisible(false);
		jobpostingpanel.setVisible(false);

 		selectedPanel.setVisible(true);
 		 
 		this.selectedPanel = selectedPanel;
 	}
 	
    private class PanelButtonMouseAdapter extends MouseAdapter{
		JPanel panel;
		
		public PanelButtonMouseAdapter(JPanel panel) {
			this.panel = panel;
		}
		
		public void mouseEntered(MouseEvent e) {
			panel.setBackground(new Color(41, 75, 141));
		}
		
		public void mouseExited(MouseEvent e) {
			panel.setBackground(new Color(255, 255, 255));
		}
		
		public void mousePressed(MouseEvent e) {
			panel.setBackground(new Color(41, 75, 141));
		}
		
		public void mouseReleased(MouseEvent e) {
			panel.setBackground(new Color(41, 75, 141));
		}
	}
    
    private class PanelButtonMouseAdapter2 extends MouseAdapter{
		JPanel panel;
		
		public PanelButtonMouseAdapter2(JPanel panel) {
			this.panel = panel;
		}
		
		public void mouseEntered(MouseEvent e) {
			panel.setBackground(new Color(240, 240, 240));
		}
		
		public void mouseExited(MouseEvent e) {
			panel.setBackground(new Color(255, 255, 255));
		}
		
		public void mousePressed(MouseEvent e) {
			panel.setBackground(new Color(240, 240, 240));
		}
		
		public void mouseReleased(MouseEvent e) {
			panel.setBackground(new Color(240, 240, 240));
		}
	}
}
