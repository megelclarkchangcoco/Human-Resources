package AdminFrame;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.border.LineBorder;
import javax.swing.JTextPane;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;




public class try2 extends JFrame {

	private ImageIcon add = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\plus (1).png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon post = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\plus-small.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon edit = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\file-edit.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
	private ImageIcon trash = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\trash (1).png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));

	private ImageIcon logo = new ImageIcon(new ImageIcon("C:\\Users\\MOMSIE BETSKIE\\eclipse-workspace\\FinalHumanResources\\assets\\adminicon\\wew.jpg").getImage().getScaledInstance(62, 52, Image.SCALE_DEFAULT));
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPanel scrollContent;
    private int panelCount = 0;
    private Connection connection;



	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					try2 frame = new try2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public try2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(217,76,1229,688);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel bodypanel = new JPanel(); 
		bodypanel.setBackground(new Color(255, 255, 255));
		bodypanel.setBounds(0,0,1217,688);
		getContentPane().add(bodypanel);
		bodypanel.setLayout(null);
		
		 // Create the scroll pane and set its bounds
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(0, 0, 1217, 655); // Adjusted the size to fit within the bounds of bodyPanel
        bodypanel.add(scrollPane);
        
        // Create the panel to hold the content to be scrolled
        scrollContent = new JPanel();
        scrollContent.setBackground(Color.WHITE);
        scrollContent.setPreferredSize(new Dimension(1000, 1500)); // Set a preferred size for scrolling
        scrollPane.setViewportView(scrollContent);
        scrollContent.setLayout(null);
        
        
        JButton btnNewButton = new JButton("add");
        btnNewButton.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		addNewPanel();
        	}
        });
        btnNewButton.setBounds(974, 80, 89, 23);
        scrollContent.add(btnNewButton);
        connectToDatabase();
        loadPanelData();
//        JPanel newPanel = new JPanel();
//        newPanel.setLayout(null);
//        newPanel.setBorder(new LineBorder(new Color(192, 192, 192)));
//        newPanel.setBackground(Color.WHITE);
//        newPanel.setBounds(67, 114, 1105, 128);
//        scrollContent.add(newPanel);
//        
//        JTextPane txtpnTitle = new JTextPane();
//        txtpnTitle.setText("Job Title");
//        txtpnTitle.setFont(new Font("Inter Medium", Font.PLAIN, 18));
//        txtpnTitle.setBounds(10, 11, 256, 29);
//        newPanel.add(txtpnTitle);
//        
//        JTextPane txtpnLocation = new JTextPane();
//        txtpnLocation.setText("Location");
//        txtpnLocation.setOpaque(false);
//        txtpnLocation.setFont(new Font("Inter Medium", Font.PLAIN, 14));
//        txtpnLocation.setBounds(75, 42, 191, 52);
//        newPanel.add(txtpnLocation);
//        
//        JLabel lbllogo = new JLabel("");
//        lbllogo.setBounds(10, 42, 62, 52);
//        newPanel.add(lbllogo);
//        
//        JTextPane jobdescriptionpane = new JTextPane();
//        jobdescriptionpane.setText("Description");
//        jobdescriptionpane.setOpaque(false);
//        jobdescriptionpane.setFont(new Font("Inter Medium", Font.PLAIN, 12));
//        jobdescriptionpane.setBounds(10, 100, 1085, 272);
//        newPanel.add(jobdescriptionpane);
//        
//        JPanel editpanels = new JPanel();
//        editpanels.setLayout(null);
//        editpanels.setBorder(new LineBorder(new Color(192, 192, 192)));
//        editpanels.setBackground(Color.WHITE);
//        editpanels.setBounds(1015, 11, 35, 29);
//        newPanel.add(editpanels);
//        
//        JLabel editlbl = new JLabel("");
//        editlbl.setBounds(10, 0, 25, 29);
//        editpanels.add(editlbl);
//        
//        JPanel postpanel = new JPanel();
//        postpanel.setLayout(null);
//        postpanel.setBorder(new LineBorder(new Color(192, 192, 192)));
//        postpanel.setBackground(Color.WHITE);
//        postpanel.setBounds(923, 11, 82, 29);
//        newPanel.add(postpanel);
//        
//        JLabel lblpost = new JLabel("post");
//        lblpost.setFont(new Font("Inter Medium", Font.PLAIN, 14));
//        lblpost.setBounds(10, 0, 62, 29);
//        postpanel.add(lblpost);
//        
//        JPanel deletepanel = new JPanel();
//        deletepanel.setLayout(null);
//        deletepanel.setBorder(new LineBorder(new Color(192, 192, 192)));
//        deletepanel.setBackground(Color.WHITE);
//        deletepanel.setBounds(1060, 11, 35, 29);
//        newPanel.add(deletepanel);
//        
//        JLabel deletelbl = new JLabel("");
//        deletelbl.setBounds(10, 0, 25, 29);
//        deletepanel.add(deletelbl);
//        newPanel.setLayout(null);
	}
	// Define a method to add a new panel
	private void addNewPanel() {
		if (panelCount < 5) { // Limit addition to 5 panels
            adjustPanelPositions(); // Move existing panels 

	    JPanel newPanel = new JPanel();
	    newPanel.setLayout(null);
	    newPanel.setBorder(new LineBorder(new Color(192, 192, 192)));
	    newPanel.setBackground(Color.WHITE);
	    newPanel.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		if (newPanel.getHeight() == 128) {
        			newPanel.setSize(new Dimension(1105, 383));
                } else {
                	newPanel.setSize(new Dimension(1105, 128));
                }
        	}
        });
	    newPanel.setBounds(67, 114, 1105, 128);
	    scrollContent.add(newPanel);

	    JTextPane txtpnTitle = new JTextPane();
	    txtpnTitle.setText("Job Title");
	    txtpnTitle.setFont(new Font("Inter Medium", Font.PLAIN, 18));
	    txtpnTitle.setBounds(10, 11, 256, 29);
	    newPanel.add(txtpnTitle);

	    JTextPane txtpnLocation = new JTextPane();
	    txtpnLocation.setText("Location");
	    txtpnLocation.setOpaque(false);
	    txtpnLocation.setFont(new Font("Inter Medium", Font.PLAIN, 14));
	    txtpnLocation.setBounds(75, 42, 191, 52);
	    newPanel.add(txtpnLocation);

	    JLabel lbllogo = new JLabel("");
	    lbllogo.setBounds(10, 42, 62, 52);
	    newPanel.add(lbllogo);

	    JTextPane jobdescriptionpane = new JTextPane();
	    jobdescriptionpane.setText("Description");
	    jobdescriptionpane.setOpaque(false);
	    jobdescriptionpane.setFont(new Font("Inter Medium", Font.PLAIN, 12));
	    jobdescriptionpane.setBounds(10, 100, 1085, 272);
	    newPanel.add(jobdescriptionpane);

	    JPanel editpanels = new JPanel();
	    editpanels.setLayout(null);
	    editpanels.setBorder(new LineBorder(new Color(192, 192, 192)));
	    editpanels.setBackground(Color.WHITE);
	    editpanels.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		txtpnTitle.setEditable(true);
            	txtpnLocation.setEditable(true);
            	jobdescriptionpane.setEditable(true);
        	}
        });
	    editpanels.setBounds(1015, 11, 35, 29);
	    newPanel.add(editpanels);

	    JLabel editlbl = new JLabel("");
	    editlbl.setBounds(10, 0, 25, 29);
	    editpanels.add(editlbl);

	    JPanel postpanel = new JPanel();
	    postpanel.setLayout(null);
	    postpanel.setBorder(new LineBorder(new Color(192, 192, 192)));
	    postpanel.setBackground(Color.WHITE);
	    postpanel.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
                String title = txtpnTitle.getText().trim();
                String loc = txtpnLocation.getText().trim();
                String des = jobdescriptionpane.getText().trim();
        		if (title.isEmpty()) {
                    JOptionPane.showMessageDialog(try2.this, "Empty Job Title field", "Error", JOptionPane.ERROR_MESSAGE);
                }
        		if (loc.isEmpty()) {
                    JOptionPane.showMessageDialog(try2.this, "Empty Job Location field", "Error", JOptionPane.ERROR_MESSAGE);
                } 
        		if (des.isEmpty()) {
                    JOptionPane.showMessageDialog(try2.this, "Empty Job Description field", "Error", JOptionPane.ERROR_MESSAGE);
                } 
        		else {
                	txtpnTitle.setEditable(false);
                	txtpnLocation.setEditable(false);
                	jobdescriptionpane.setEditable(false);
                    JOptionPane.showMessageDialog(try2.this, "Text saved successfully");
                    savePanelData(title, loc, des); // Save panel data to database
                }
        	}
        });
	    
        	
	    postpanel.setBounds(923, 11, 82, 29);
	    newPanel.add(postpanel);

	    JLabel lblpost = new JLabel("post");
	    lblpost.setFont(new Font("Inter Medium", Font.PLAIN, 14));
	    lblpost.setBounds(10, 0, 62, 29);
	    postpanel.add(lblpost);

	    JPanel deletepanel = new JPanel();
	    deletepanel.setLayout(null);
	    deletepanel.setBorder(new LineBorder(new Color(192, 192, 192)));
	    deletepanel.setBackground(Color.WHITE);
	    deletepanel.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		scrollContent.remove(newPanel);
        		scrollContent.revalidate();
        		scrollContent.repaint();
                 panelCount--;
                 adjustPanelPositions();
                 deletePanelData(txtpnTitle.getText(), txtpnLocation.getText(), jobdescriptionpane.getText()); // Delete panel data from database

        	}
        });
	    deletepanel.setBounds(1060, 11, 35, 29);
	    newPanel.add(deletepanel);

	    JLabel deletelbl = new JLabel("");
	    deletelbl.setBounds(10, 0, 25, 29);
	    deletepanel.add(deletelbl);
	    newPanel.setLayout(null);
	    
	    scrollContent.revalidate();
	    scrollContent.repaint();
	    
	    scrollContent.add(newPanel);
		scrollContent.revalidate();
		scrollContent.repaint();
        panelCount++;
	} else {
        JOptionPane.showMessageDialog(try2.this, "Maximum panel limit reached", "Error", JOptionPane.ERROR_MESSAGE);
    	}
	}
	 private void adjustPanelPositions() {
	        Component[] components = scrollContent.getComponents();
	        int yPos = 114;
	        for (int i = 0; i < components.length; i++) {
	            if (components[i] instanceof JPanel) {
	                JPanel existingPanel = (JPanel) components[i];
//	                setBounds(23, 114, 1105, 128);
	                existingPanel.setBounds(67, yPos, 1105, 128);
	                yPos += 150; // Increment yPos for the next panel
	            }
	        }
	    }
	 // Connect to the database
	    private void connectToDatabase() {
	        String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;databaseName=casethreedatabase;integratedSecurity=true;encrypt=false;";
	        try {
	            connection = DriverManager.getConnection(url);
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    // Save panel data to database
	    private void savePanelData(String jobtile, String location, String description) {
	        String query = "INSERT INTO jobposting(jobtitle, joblocation, jobdescription) VALUES (?,?,?)";
	        try (PreparedStatement statement = connection.prepareStatement(query)) {
	            statement.setString(1, jobtile);
	            statement.setString(2, location);
	            statement.setString(3, description);
	            statement.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    
	    // Delete panel data from database
	    private void deletePanelData(String jobtile, String location, String description) {
	        String query = "DELETE FROM jobposting WHERE jobtitle = ? AND joblocation = ? AND jobdescription = ?";
	        try (PreparedStatement statement = connection.prepareStatement(query)) {
	            statement.setString(1, jobtile);
	            statement.setString(2, location);
	            statement.setString(3, description);
	            statement.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    // Load panel data from database
	    private void loadPanelData() {
	        String query = "SELECT jobtitle, joblocation, jobdescription FROM jobposting";
	        try (PreparedStatement statement = connection.prepareStatement(query)) {
	            ResultSet resultSet = statement.executeQuery();
	            while (resultSet.next()) {
	                String text = resultSet.getString("jobtitle");
	                String text2 = resultSet.getString("joblocation");
	                String text3 = resultSet.getString("jobdescription");
	                addNewPanel(); // Add panel with loaded text
	                JTextPane textPane = (JTextPane) ((JPanel) scrollContent.getComponent(scrollContent.getComponentCount() - 1)).getComponent(0);
	                JTextPane textPane2 = (JTextPane) ((JPanel) scrollContent.getComponent(scrollContent.getComponentCount() - 1)).getComponent(0);
	                JTextPane textPane3 = (JTextPane) ((JPanel) scrollContent.getComponent(scrollContent.getComponentCount() - 1)).getComponent(0);

	                textPane.setText(text);
	                textPane.setEditable(false); // Make text pane not editable
	                textPane2.setText(text2);
	                textPane2.setEditable(false); // Make text pane not editable
	                textPane3.setText(text3);
	                textPane3.setEditable(false); // Make text pane not editable
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
}
