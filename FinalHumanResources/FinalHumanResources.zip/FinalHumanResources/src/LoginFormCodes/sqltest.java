package LoginFormCodes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class sqltest {
	public static void main(String[] args) {
		
		
		String url = "jdbc:sqlserver://LAPTOP-C5593DBG\\SQLEXPRESS;Database=Dota2Hero;IntegratedSecurity=true;encrypt=false";
		
		
		try {
			
			try(Connection connection = DriverManager.getConnection(url);){
				System.out.println("Connection Sucess!");
			}
			}catch(SQLException e) {
				System.out.println("Connection Fail!");
				e.printStackTrace();
		}
		
		
		
	}
}
